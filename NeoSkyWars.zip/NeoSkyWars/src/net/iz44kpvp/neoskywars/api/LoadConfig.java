package net.iz44kpvp.neoskywars.api;

import java.io.File;
import java.util.UUID;

import org.bukkit.configuration.file.YamlConfiguration;

import net.iz44kpvp.neoskywars.Main;

public class LoadConfig
{
    private YamlConfiguration config;
    public boolean problem;
    
    @SuppressWarnings("deprecation")
	public LoadConfig(final Main skyAuthPlugin) {
        this.config = null;
        this.problem = false;
        try {
            final File file = new File(skyAuthPlugin.getDataFolder(), "stats.yml");
            if (!file.exists()) {
                file.getParentFile().mkdir();
                file.createNewFile();
                this.config = YamlConfiguration.loadConfiguration(file);
                final YamlConfiguration configYml = YamlConfiguration.loadConfiguration(skyAuthPlugin.getResource("stats.yml"));
                for (final String key : configYml.getKeys(false)) {
                    this.config.set(key, configYml.get(key));
                }
                this.config.save(file);
            }
            else {
                this.config = YamlConfiguration.loadConfiguration(file);
            }
        }
        catch (Exception e) {
            this.problem = true;
        }
    }
    
    public void createAccount(final UUID uuid, final String name, final int point, final int kills, final int deaths, final int wins) {
        this.config.set("users." + uuid.toString() + ".name", (Object)name);
        this.config.set("users." + uuid.toString() + ".coins", (Object)point);
        this.config.set("users." + uuid.toString() + ".kills", (Object)kills);
        this.config.set("users." + uuid.toString() + ".deaths", (Object)deaths);
        this.config.set("users." + uuid.toString() + ".wins", (Object)wins);
        try {
            this.config.save(new File(Main.getInstance().getDataFolder(), "stats.yml"));
        }
        catch (Exception ex) {}
    }
    
    public void setValueString(final String into, final UUID where, final String value) {
        this.config.set("users." + where.toString() + "." + into, (Object)value);
        try {
            this.config.save(new File(Main.getInstance().getDataFolder(), "stats.yml"));
        }
        catch (Exception ex) {}
    }
    
    public void setValue(final String into, final UUID where, final Object value) {
        this.config.set("users." + where.toString() + "." + into, value);
        try {
            this.config.save(new File(Main.getInstance().getDataFolder(), "stats.yml"));
        }
        catch (Exception ex) {}
    }
    
    public void setValueInt(final String into, final UUID where, final int value) {
        this.config.set("users." + where.toString() + "." + into, (Object)value);
        try {
            this.config.save(new File(Main.getInstance().getDataFolder(), "stats.yml"));
        }
        catch (Exception ex) {}
    }
    
    public String getValueString(final String into, final UUID where) {
        return this.config.getString("users." + where.toString() + "." + into);
    }
    
    public Object getValue(final String into, final UUID where) {
        return this.config.get("users." + where.toString() + "." + into);
    }
    
    public int getValueInt(final String into, final UUID where) {
        return this.config.getInt("users." + where.toString() + "." + into);
    }
    
    public YamlConfiguration getConfig() {
        return this.config;
    }
}
