package net.iz44kpvp.neoskywars.api;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import net.iz44kpvp.neoskywars.Main;

public class Mysql
{
    public boolean problem;
    private String url_base;
    private String host;
    private String name;
    private String username;
    private String password;
    private String table;
    private Connection connection;
    
    public Mysql(final Main skyAuthPlugin) {
        this.problem = false;
        try {
            if (skyAuthPlugin.getConfig().getBoolean("Settings.sql.active")) {
                this.connection("jdbc:mysql://", skyAuthPlugin.getConfig().getString("Settings.sql.host"), skyAuthPlugin.getConfig().getString("Settings.sql.name"), skyAuthPlugin.getConfig().getString("Settings.sql.user"), skyAuthPlugin.getConfig().getString("Settings.sql.password"), skyAuthPlugin.getConfig().getString("Settings.sql.table"));
                Main.getInstance().useConfig = true;
            }
            else {
                Main.getInstance().useConfig = false;
            }
        }
        catch (Exception e) {
            this.problem = true;
        }
    }
    
    public void connection(final String url_base, final String host, final String name, final String username, final String password, final String table) {
        this.url_base = url_base;
        this.host = host;
        this.name = name;
        this.username = username;
        this.password = password;
        this.table = table;
        if (!this.isConnected()) {
            try {
                this.connection = DriverManager.getConnection(String.valueOf(this.url_base) + this.host + "/" + this.name, this.username, this.password);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        this.createTable();
    }
    
    public void deconnection() {
        if (this.isConnected()) {
            try {
                this.connection.close();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public boolean isConnected() {
        try {
            if (this.connection == null || this.connection.isClosed() || !this.connection.isValid(5)) {
                return false;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }
    
    public Connection getConnection() {
        return this.connection;
    }
    
    public boolean tableExists() {
        try {
            final DatabaseMetaData dbmd = this.getConnection().getMetaData();
            final ResultSet rs = dbmd.getTables(null, null, this.table, null);
            return rs.getRow() == 1;
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public void createTable() {
        try {
            this.getConnection().createStatement().execute("CREATE TABLE IF NOT EXISTS " + this.table + " (uuid VARCHAR(255), name VARCHAR(32), kills INTEGER, deaths INTEGER, wins INTEGER, coins INTEGER, souls INTEGER, games INTEGER)");
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void createAccount(final UUID user, final String name) {
        try {
            final PreparedStatement sts = this.getConnection().prepareStatement("SELECT name FROM " + this.table + " WHERE uuid = ?");
            sts.setString(1, user.toString());
            final ResultSet rs = sts.executeQuery();
            if (!rs.next()) {
                sts.close();
                final PreparedStatement sts2 = this.getConnection().prepareStatement("INSERT INTO " + this.table + "(uuid, name, kills, deaths, wins, coins, souls, games) VALUES (?, ?, 0, 0, 0, 0, 0, 0)");
                sts2.setString(1, user.toString());
                sts2.setString(2, name);
                sts2.executeUpdate();
                sts2.close();
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void setValueInt(final String into, final int value, final UUID where) {
        try {
            final PreparedStatement sts = this.getConnection().prepareStatement("UPDATE " + this.table + " SET " + into + " = ? WHERE uuid = ?");
            sts.setInt(1, value);
            sts.setString(2, where.toString());
            sts.executeUpdate();
            sts.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void setValueString(final String into, final String value, final UUID where) {
        try {
            final PreparedStatement sts = this.getConnection().prepareStatement("UPDATE " + this.table + " SET " + into + " = ? WHERE uuid = ?");
            sts.setString(1, value);
            sts.setString(2, where.toString());
            sts.executeUpdate();
            sts.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public Integer getValueInt(final String into, final UUID where) {
        int value = 0;
        try {
            final PreparedStatement sts = this.getConnection().prepareStatement("SELECT " + into + " FROM " + this.table + " WHERE uuid = ?");
            sts.setString(1, where.toString());
            final ResultSet rs = sts.executeQuery();
            if (!rs.next()) {
                return value;
            }
            value = rs.getInt(into);
            sts.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return value;
    }
    
    public String getValueString(final String into, final UUID where) {
        String value = null;
        try {
            final PreparedStatement sts = this.getConnection().prepareStatement("SELECT " + into + " FROM " + this.table + " WHERE uuid = ?");
            sts.setString(1, where.toString());
            final ResultSet rs = sts.executeQuery();
            if (!rs.next()) {
                return value;
            }
            value = rs.getString(into);
            sts.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return value;
    }
}
