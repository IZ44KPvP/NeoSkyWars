package net.iz44kpvp.neoskywars.api;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.utils.ColoredTexts;


@SuppressWarnings({"all"})
public class Messages implements ColoredTexts
{
	private static transient Messages instance;
      public List<String> SCOREBOARD_LOBBY;
      public List<String> SCOREBOARD_ROOM;
      public List<String> SCOREBOARD_WAIT;
	  public String CHAT_FORMAT;
	  public String CHAT_SKYWARS_SPECT_FORMAT;
	  public String PARTY_CHAT_FORMAT;
	  public String SPECTATOR_INV_TITLE;
	  public String SKYWARS_SUBTITLE_CHEST_REFILLED;
	  public String NOT_HAVE_PERMISSION;
	  public String COMMAND_NOT_FOUND;
	  public String SW_SIGN_NOT_HAVEROOM_AVAIBLE;
	  public String SKYWARS_ALREADY_INGAME;
	  public String SKYWARS_FULL;
	  public String YOU_ALREADY_IN_GAME;
	  public String SKYWARS_PLAYER_JOIN;
	  public String SKYWARS_STARTING;
	  public List<String> SKYWARS_START_INFO;
	  public String SKYWARS_STARTED;
	  public String SKYWARS_TEAM_NOT_ALLOWED;
	  public String SKYWARS_KITSELECTED;
	  public String SKYWARS_TITLE_STARTING;
	  public String SKYWARS_TITLE_ON_JOIN;
	  public String SKYWARS_SUBTITLE_ON_JOIN;
	  public String SKYWARS_TITLE_MEGA_ON_JOIN;
	  public String SKYWARS_SUBTITLE_MEGA_ON_JOIN;
	  public String SKYWARS_SUBTITLE_STARTING;
	  public String SKYWARS_TITLE_STARTED_INSANEMODE;
	  public String SKYWARS_TITLE_DEAD;
	  public String SKYWARS_SUBTITLE_DEAD;
	  public List<String> SKYWARS_PLAYERS_MESSAGE_WIN;
	  public List<String> SKYWARS_TEAM_PLAYERS_MESSAGE_WIN;
	  public String SKYWARS_PLAYERS_TITLE_WIN;
	  public String SKYWARS_PLAYERS_SUBTITLE_WIN;
	  public String SKYWARS_TEAM_PLAYERS_TITLE_WIN;
	  public String SKYWARS_TEAM_PLAYERS_SUBTITLE_WIN;
	  public String SKYWARS_PLAYER_WIN_TITLE;
	  public String SKYWARS_PLAYER_WIN_SUBTITLE;
	  public String SW_BEDQUIT_DISPLAY;
	  public String SW_SPECT_COMPASS_DISPLAY;
	  public String SW_KITSELECTOR_DISPLAY;
	  public String SW_OPTIONS_DISPLAY;
	  public String INV_KITSELECTOR_TITLE;
	  public String SW_PAPER_PLAY_AGAIN_DISPLAY;
	  public String COMMAND_SW_INCORRECT_ARGS;
	  public String COMMAND_SW_NOTFOUND;
	  public String COMMAND_SWDM_SUCESS;
	  public String COMMAND_SWCHEST_NOTCHEST;
	  public String COMMAND_SWCHEST_SUCESS;
	  public String MESSAGE_COMING_SOON;
	  public String RESTANT_PLAYERS;
	  public String SW_PLAYER_DEATH_BY_PLAYER;
	  public String SW_PLAYER_DEATH_BY_PLAYER_ARROW;
	  public String SW_PLAYER_DEATH_BY_PLAYER_ON_VOID;
	  public String SW_PLAYER_DEATH_BY_VOID;
	  public String SW_PLAYER_DEATH_BY_EXPLOSION;
	  public String SW_PLAYER_DEATH_BY_SUICIDE;
	  public String SW_PLAYER_DEATH_BY_FALL;
	  public String SW_PLAYER_DEATH_BY_LAVA;
	  public String SW_PLAYER_DEATH_BY_SUFFOCATION;
	  public String SW_PLAYER_DEATH_BY_FALLING_BLOCK;
	  public String SW_PLAYER_DEATH_DROWNING;
	  public String SW_PLAYER_DEATH_BY_LIGHTNING;
	  public String SW_PLAYER_DEATH_BY_POISON;
	  public String SW_PLAYER_DEATH_BY_MAGIC;
	  public String SW_PLAYER_DEATH_BY_ENTITY;
	  public String SW_PLAYER_DEATH_BY_OUTHER;
	  public String SKYWARS_BORDER_ULTRAPASSED;
	  public String INV_CAGES_TITLE;
	  public String SKYWARS_CAGE_CHANGED;
	  public String ONLY_VIPS_CAN_ACESS;
	  public List<String> SKYWARS_PLAYER_DEATHMATCH;
	  public String SKYWARS_CAGES_ONLY_FOR_SOLO_MODE;
	  public String PARTY_YOU_IS_NOT_LEADER;
	  public String KIT_PURSHASED;
	  public String KIT_NOT_ENOUGHT_MONEY;
	  public String KIT_ALREADY_PURSHASED;
	  public String SKYWARS_CONECTING;
	  public String PLAYER_JOINED_SKYWARS_LOBBY;
	  public String PLAYER_LEFT_SKYWARS_LOBBY;
	  public List<String> SKYWARS_REWARDS;
	  public List<String> PARTY_COMMAND;
	  public String SPECT_TELEPORTED;
	  public String NPC_ARENAS_DISPLAY;
	  public String NPC_PLAY_DISPLAY;
	  public String PARTY_INCORRECT_ARGS;
	  public String PARTY_INVITED;
	  public String PARTY_NEW_INVITE;
	  public String PARTY_CHAT_CLICK;
	  public String PARTY_CHAT_CLICK_LORE;
	  public String PARTY_IS_ALREADY_INVITED;
      public String PARTY_IS_ALREADY_IN_PARTY;
      public String PARTY_IS_OFFLINE;
      public String PARTY_HAS_JOINED;
      public String PARTY_PLAYER_JOINED;
      public String PARTY_NOT_HAVE_INVITE;
      public String PARTY_YOU_IS_ALREADY_IN_PARTY;
      public String PARTY_INVITER_IS_OFFLINE;
      public String PARTY_KICKED_PLAYER;
      public String PARTY_KICKED_BY;
      public String PARTY_MEMBER_KICKED;
      public String PARTY_NEED_PLAYERS;
      public String PARTY_CANT_REMOVE_YOURSELF;
      public String PARTY_PLAYER_NOT_IS_IN_YOUR_PARTY;
      public String PARTY_REMOVED_PLAYER_OFFLINE;
      public String PARTY_ONLY_LEADER;
      public String PARTY_YOU_IS_NOT_IN_PARTY;
      public String PARTY_YOU_HAS_LEFT;
      public List<String> PARTY_DISBANDED;
      public String PARTY_DISBANDED_OTHER_REASON;
      public String PARTY_PLAYER_LEFT;
      public String PARTY_YOU_NOT_HAVE_PARTY;
      public String PARTY_JOINED_CHAT;
      public String PARTY_LEAVED_CHAT;
      public String PARTY_DISBANDED_LEADER_HAS_LEFT;
      public String PARTY_DISBANDED_PLAYER_HAS_LEFT;
      public String PARTY_DELETED;
      public String PARTY_REQUEST_EXPIRED;
      public String CHAT_PLAY_AGAIN;
      public String CHAT_PLAY_AGAIN_LORE;
      public List<String> SKYWARS_1_PLAYERS_MESSAGE_WIN;
      public List<String> SKYWARS_3_PLAYERS_MESSAGE_WIN;
      public String SKYWARS_MEGA_PLAYERS_TITLE_WIN;
      public List<String> SKYWARS_4_PLAYERS_MESSAGE_WIN;
      public List<String> SKYWARS_5_PLAYERS_MESSAGE_WIN;

	public transient boolean problemTranslation;
	public transient boolean modified;
	public transient boolean saveConfig;
    private transient YamlConfiguration config;
    private transient File configFile;
	
	
	

    static {
        Messages.instance = new Messages();
    }
    
    public Messages() {
    	SCOREBOARD_LOBBY = Arrays.asList(new String[] { "", "�eStatistics:", "  Kills: �a<kills>", "  Deaths: �a<deaths>", "", "�eMatchs:", "  Games: �a<games>", "  Wins: �a<wins>", "", "�eOthers:", "  Souls: �a<souls>", "  Coins: �a<coins>", "  Online: �a<players>", "", "�ewww.example.com" });
    	SCOREBOARD_ROOM = Arrays.asList(new String[] { "�7<type> <date>", "", "Next Event:", "Refill: �a<fill>", "", "Players left: �a<players>", "", "Kills: �a<kills>", "", "Map: �a<map>", "Mode: �a<mode>", "", "�ewww.example.com" });
    	SCOREBOARD_WAIT = Arrays.asList(new String[] { "", "Players: �a<players>", "", "Starting in �a<time>s", "", "Server: �a<server>", "", "�ewww.example.com" });
        CHAT_FORMAT = "�a<player> � �7<message>";
        CHAT_SKYWARS_SPECT_FORMAT = "�7[�eSPECT�7] <player> ��7 <message>";
        PARTY_CHAT_FORMAT = "�7[�eParty�7] �a<player> �7� �f <message>";
        SKYWARS_SUBTITLE_CHEST_REFILLED = "�eThe chest now have new Items!";
        SPECTATOR_INV_TITLE = "�aPlayers";
        NOT_HAVE_PERMISSION = "�cYou dont have permission";
        COMMAND_NOT_FOUND = "�cCommand not found";
        SW_SIGN_NOT_HAVEROOM_AVAIBLE = "�cSorry, there are no SkyWars rooms at the moment.";
        SKYWARS_ALREADY_INGAME = "�cThis match is already in play.";
        YOU_ALREADY_IN_GAME = "�cAre you already in a game";
        SKYWARS_FULL = "�cSkyWars Full";
        SKYWARS_PLAYER_JOIN = "�a<player> �ehas joined �7(�b<players>�e)!";
        SKYWARS_STARTING = "�aThe SkyWars will start in <time> second(s)";
        SKYWARS_START_INFO = Arrays.asList(new String[] {"�a�l�m---------------------------------------------", "�f�lSkyWars", "", "�e�lGather resources and equipment on your island", "�e�lin order to eliminate every other player", "�e�lGo to the center island for special chests", "�e�lwith special items!", "", "�a�l�m---------------------------------------------"});
        SKYWARS_STARTED = "�c�lCages Opened! �eFight!";
        SKYWARS_TEAM_NOT_ALLOWED = "�c�lTeaming is not Allowed in Solo Mode!";
        SKYWARS_KITSELECTED = "�aYou selected the kit <kit>";
        SKYWARS_TITLE_STARTING = "�c�l<time>";
        SKYWARS_TITLE_ON_JOIN = "�e�lSkyWars";
        SKYWARS_SUBTITLE_ON_JOIN = "�a<mode> Mode";
        SKYWARS_TITLE_MEGA_ON_JOIN = "�e�lSkyWars";
        SKYWARS_SUBTITLE_MEGA_ON_JOIN = "�aMega Mode";
        SKYWARS_SUBTITLE_STARTING = "�ePrepare to fight!";
        SKYWARS_TITLE_STARTED_INSANEMODE = "�c�lINSANE MODE";
        SKYWARS_TITLE_DEAD = "�cYou died";
        SKYWARS_SUBTITLE_DEAD = "�7Now you are specting.";
        SKYWARS_PLAYERS_TITLE_WIN = "�6�lGAME END";
        SKYWARS_PLAYERS_MESSAGE_WIN = Arrays.asList("�a�l�m---------------------------------------------", "�f�lSkyWars", "", "�eWinner �7- <player>", "", "�a�l�m---------------------------------------------");
        SKYWARS_TEAM_PLAYERS_MESSAGE_WIN = Arrays.asList("�a�l�m---------------------------------------------", "�f�lSkyWars", "", "�eWinner 1 �7- <player>", "�eWinner 2 �7- <player2>", "", "�a�l�m---------------------------------------------");
        SKYWARS_PLAYERS_SUBTITLE_WIN = "�7<player> �aIs The Winner";
        SKYWARS_TEAM_PLAYERS_TITLE_WIN = "�6�lGAME END";
        SKYWARS_TEAM_PLAYERS_SUBTITLE_WIN = "�7<player> and <secondplayer> �ais The Winners";
        SKYWARS_PLAYER_WIN_TITLE = "�6VICTORY!";
        SKYWARS_PLAYER_WIN_SUBTITLE = "�7you were the last man/team standing!";
        SW_BEDQUIT_DISPLAY = "�cLeft �7(Right Click)";
        SW_SPECT_COMPASS_DISPLAY = "�cTeleport �7(Right Click)";
        SW_KITSELECTOR_DISPLAY = "�aKit Selector �7(Right Click)";
        SW_OPTIONS_DISPLAY = "�c�lSKYWARS OPTIONS �7(Right Click)";
        INV_KITSELECTOR_TITLE = "�aKit Selector";
        SW_PAPER_PLAY_AGAIN_DISPLAY = "�aPlay Again �7(Right Click)";
        COMMAND_SW_INCORRECT_ARGS = "�cInvalid command";
        COMMAND_SW_NOTFOUND = "�cThis world does not have a skywars arena registered";
        COMMAND_SWDM_SUCESS = "�aDeathMatch set!";
        COMMAND_SWCHEST_NOTCHEST = "�cThis Block Is Not A Chest";
        COMMAND_SWCHEST_SUCESS = "�aChest Added";
        MESSAGE_COMING_SOON = "�cIn developement... Avaliable Coming Soon";
        RESTANT_PLAYERS = "�eThere are <players> players remaining";
        SW_PLAYER_DEATH_BY_PLAYER = "�7<player> �ehas killed by �7<killer>";
        SW_PLAYER_DEATH_BY_PLAYER_ARROW = "�7<player> �ehas shot and killed by �7<killer>";
        SW_PLAYER_DEATH_BY_PLAYER_ON_VOID = "�7<player> �ehas fell into the void with the help of �7<killer>";
        SW_PLAYER_DEATH_BY_VOID = "�7<player> �ehas fell into the void";
        SW_PLAYER_DEATH_BY_EXPLOSION = "�7<player> �eHas Exploded";
        SW_PLAYER_DEATH_BY_SUICIDE = "�7<player> �ehas suicided";
        SW_PLAYER_DEATH_BY_FALL = "�7<player> �efell from a high place";
        SW_PLAYER_DEATH_BY_LAVA = "�7<player> �edied in a lava";
        SW_PLAYER_DEATH_BY_SUFFOCATION = "�7<player> �ehas suffocated";
        SW_PLAYER_DEATH_BY_FALLING_BLOCK = "�7<player> �eWas killed by a falling block";
        SW_PLAYER_DEATH_DROWNING = "�7<player> �edrowned";
        SW_PLAYER_DEATH_BY_LIGHTNING = "�7<player> �ewas killed by lightning";
        SW_PLAYER_DEATH_BY_POISON = "�7<player> �ewas poisoned dead";
        SW_PLAYER_DEATH_BY_MAGIC = "�7<player> �ewas killed by magic";
        SW_PLAYER_DEATH_BY_ENTITY = "�7<player> �ehas killed by Monster";
        SW_PLAYER_DEATH_BY_OUTHER = "�7<player> �edied in an unknown way";
        SKYWARS_BORDER_ULTRAPASSED = "�cYou crossed the border of the map.";
        INV_CAGES_TITLE = "�4�lSKYWARS CAGES";
        SKYWARS_CAGE_CHANGED = "�a�lYou have changed the skywars cage.";
        ONLY_VIPS_CAN_ACESS = "�c�lOnly VIPS can use this feature to use please donate in www.example.com";
        SKYWARS_PLAYER_DEATHMATCH = Arrays.asList(new String[] {"", "�a�lAll SkyWars Players Are Teleported to DeathMatch", "�a�lFight, Alive and Win the Game", "�e�lGOOD LUCK"});
        SKYWARS_CAGES_ONLY_FOR_SOLO_MODE = "�cThis Feature is avaliable only for Solo Mode!.";
        PARTY_YOU_IS_NOT_LEADER = "�cYou is not The Party Leader";
        KIT_PURSHASED = "�aYou have purshased the kit <kit>";
        KIT_NOT_ENOUGHT_MONEY = "�cYou not have suficient money to buy this Kit";
        KIT_ALREADY_PURSHASED = "�cYou is already pushased this Kit <kit>.";
        SKYWARS_CONECTING = "�aSending you to <skywars>...";
        PLAYER_JOINED_SKYWARS_LOBBY = "�a�lYou have teleported to SkyWars Server";
        PLAYER_LEFT_SKYWARS_LOBBY = "�c�lYou have Leaved of SkyWars Server";
        SKYWARS_REWARDS = Arrays.asList(new String[]{"�a�l�m---------------------------------------------", "�f�l                      Reward Summary", "", "�6                    You earned a total of <coins> Coins", "�9                 You earned a total of <souls> Souls", "", "�a�l�m---------------------------------------------"});
        PARTY_COMMAND = Arrays.asList(new String[]{"�a�m--------------------------------------------", "�a/party invite <player> �7- Invite one Player To Join your Party"
        		, "�a/party accept <player> �7- Accept Party Invite�s", "�a/party kick <player> �7- Remove Player Of Your Party"
        		, "�a/party chat �7 - Join/Leave The Party Chat!", "�a/party list �7- Get Players Members on Your Party"
        		, "�a/party leave �7- Leave of Your Party", "�a�m--------------------------------------------"});
        SPECT_TELEPORTED = "�eTeleported to <player>";
        NPC_ARENAS_DISPLAY = "�e�lARENAS";
        NPC_PLAY_DISPLAY = "�e�lPLAY NOW";
        PARTY_INCORRECT_ARGS = "�cYour Command Args is Invalid Try use /party to see all Args";
        PARTY_INVITED = "�eYou invited the player �b <invited> �efor your Party!";
        PARTY_NEW_INVITE = "�eThe Player �b<inviter> �ehas invited your to Join your Party.";
        PARTY_CHAT_CLICK = "�e�lClick Here to Accept";
        PARTY_CHAT_CLICK_LORE = "�a�lAccept <inviter> Invite�s";
        PARTY_IS_ALREADY_INVITED = "�eThe Player <invited> is Already been invited to this party!";
        PARTY_IS_ALREADY_IN_PARTY = "�cThe Player �b<invited>�c is already in a party.!";
        PARTY_IS_OFFLINE = "�cThe Player <invited> is Offline.";
        PARTY_HAS_JOINED = "�eYou have join the Party of �b<inviter>";
        PARTY_PLAYER_JOINED = "�eThe Player �b<player> �ehas joined party with invite from �b<inviter>";
        PARTY_NOT_HAVE_INVITE = "�cThe Player �b<player>�c is not invited you!";
        PARTY_YOU_IS_ALREADY_IN_PARTY = "�cAre you already in party!";
        PARTY_INVITER_IS_OFFLINE = "�cThe Player <inviter> is OffLine Now!";
        PARTY_KICKED_PLAYER = "�eYou have removed the player �b<player> �eof you Party!";
        PARTY_KICKED_BY = "�eThe Leader �7<player>�e has Removed you of your Party!";
        PARTY_MEMBER_KICKED = "�eThe Leader �b<leader> �ehas Removed �b<player> �eFrom your Party!";
        PARTY_NEED_PLAYERS = "�cYour Party has disbanded due for Need more Players!";
        PARTY_CANT_REMOVE_YOURSELF = "�cYou can not remove yourself!";
        PARTY_PLAYER_NOT_IS_IN_YOUR_PARTY = "�cThe Player �b<player> �eIs not in your party!";
        PARTY_REMOVED_PLAYER_OFFLINE = "�cThe Player �b<player>�c Is offline now!";
        PARTY_ONLY_LEADER = "�cOnly the leader �b<player> �eyou can do it!";
        PARTY_YOU_IS_NOT_IN_PARTY = "�cYou are not in any party!";
        PARTY_YOU_HAS_LEFT = "�eYou left the player's party. �b<player>";
        PARTY_DISBANDED = Arrays.asList(new String[]{"�eThe Player �b<player> �ehas Left of Your party!", "�eYour Party has Disbanded!"});
        PARTY_DISBANDED_OTHER_REASON = "�eYour Party has Disbanded";
        PARTY_PLAYER_LEFT = "�eThe Player �b<player> �ehas Left of Your Party!";
        PARTY_YOU_NOT_HAVE_PARTY = "�cYou are not in any party!";
        PARTY_JOINED_CHAT = "�aYou have Joined The Party Chat!";
        PARTY_LEAVED_CHAT = "�cYou have Leaved The Party Chat!";
        PARTY_DISBANDED_LEADER_HAS_LEFT = "�6�lPARTY: �eYour party has ben disbanded due for Party Leader has Left of Server";
        PARTY_DISBANDED_PLAYER_HAS_LEFT = "�6�lPARTY: �eYour party has ben disbanded due for �b<player> �eHas Left of Server";
        PARTY_DELETED = "�6�lPARTY: �b<player> �eHas Deleted Party!";
        PARTY_REQUEST_EXPIRED = "�6�lPARTY: �eThe party request of �b<player> �ehas Expired.";
        CHAT_PLAY_AGAIN = "Do you want to play again? �aClick Here To Play Again";
        CHAT_PLAY_AGAIN_LORE = "�eClick to send you to other SkyWars Arena";
        SKYWARS_MEGA_PLAYERS_TITLE_WIN = "�6GAME END";
        SKYWARS_1_PLAYERS_MESSAGE_WIN = Arrays.asList("�a�l�m---------------------------------------------", "�f�lSkyWars", "", "�eWinner �7- <player>", "", "�a�l�m---------------------------------------------");
        SKYWARS_3_PLAYERS_MESSAGE_WIN = Arrays.asList("�a�l�m---------------------------------------------", "�f�lSkyWars", "", "�eWinner 1 �7- <player>", "�eWinner 2 �7- <player2>","�eWinner 3 �7- <player3>" , "", "�a�l�m---------------------------------------------");
        SKYWARS_4_PLAYERS_MESSAGE_WIN = Arrays.asList("�a�l�m---------------------------------------------", "�f�lSkyWars", "", "�eWinner 1 �7- <player>", "�eWinner 2 �7- <player2>","�eWinner 3 �7- <player3>","�eWinner 4 �7- <player4>" , "", "�a�l�m---------------------------------------------");
        SKYWARS_5_PLAYERS_MESSAGE_WIN = Arrays.asList("�a�l�m---------------------------------------------", "�f�lSkyWars", "", "�eWinner 1 �7- <player>", "�eWinner 2 �7- <player2>","�eWinner 3 �7- <player3>","�eWinner 4 �7- <player4>", "�eWinner 5 �7- <player5>", "", "�a�l�m---------------------------------------------");
        
        modified = false;
        saveConfig = false;
        problemTranslation = false;
    }
    
    public static Messages getInstance() {
        return Messages.instance;
    }
    
    public void setup() {
    	
    	
        configFile = new File(Main.getInstance().getDataFolder(), "messages.yml");
        config = new YamlConfiguration();
        try {
            load();
            loadConfig();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void load() throws Exception {
        try {
            if (!configFile.exists()) {
                save();
            }
            config.load(configFile);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    protected void copiarConfig(InputStream i, File config) {
        try {
            int len;
            FileOutputStream out = new FileOutputStream(config);
            byte[] buf = new byte[710];
            while ((len = i.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            out.close();
            i.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
	public void loadConfig() {
        try {
            Main.getInstance().consoleSender.sendMessage(green + "Loading messages..." + reset);
            try {
            	
                
                Field[] declaredFields;
                for (int length = (declaredFields = getClass().getDeclaredFields()).length, k = 0; k < length; ++k) {
                    final Field field = declaredFields[k];
                    if (!Modifier.isTransient(field.getModifiers())) {
                        try {
                            Object value = config.get(field.getName());
                            if (value == null) {
                                value = field.get(this);
                                if (value instanceof String[]) {
                                    final String[] strings = (String[])value;
                                    final String[] newStrings = new String[strings.length];
                                    for (int i = 0; i < strings.length; ++i) {
                                        newStrings[i] = strings[i].replace("\n", "\\n").replace("�", "&");
                                    }
                                    config.set(field.getName(), (Object)newStrings);
                                }
                                else if (value instanceof String) {
                                    config.set(field.getName(), (Object)String.valueOf(value).replace("\n", "\\n").replace("�", "&"));
                                }
                                else {
                                    final List<String> a = new ArrayList<String>();
                                    final List<String> list = (List<String>)value;
                                    for (final String str : list) {
                                        a.add(str.replace("�", "&"));
                                    }
                                    config.set(field.getName(), (Object)a);
                                }
                                modified = true;
                            }
                            else if (field.getType().isArray() && value.getClass() == ArrayList.class) {
                                final List<Object> array = (List<Object>)value;
                                value = array.toArray(new String[array.size()]);
                            }
                            if (value instanceof String) {
                                value = ChatColor.translateAlternateColorCodes('&', String.valueOf(value)).replace("\\n", "\n");
                            }
                            if (value instanceof String[]) {
                                final String[] strings = (String[])value;
                                for (int j = 0; j < strings.length; ++j) {
                                    strings[j] = ChatColor.translateAlternateColorCodes('&', strings[j]).replace("\\n", "\n");
                                }
                                value = strings;
                            }
                            if (field.getType().getSimpleName().equals("float") && value.getClass() == Double.class) {
                                field.set(this, (float)(double)value);
                            }
                            else {
                                field.set(this, value);
                            }
                        }
                        catch (Exception e) {
                            problemTranslation = true;
                            e.printStackTrace();
                        }
                    }
                }
                if (modified) {
                    saveConfig = true;
                }
            }
            catch (Exception e2) {
                problemTranslation = true;
                e2.printStackTrace();
            }
            if (saveConfig) {
                save();
            }
        }
        catch (Exception e3) {
            e3.printStackTrace();
        }
    }
    
    public void save() {
        try {
            if (!configFile.exists()) {
                configFile.getParentFile().mkdirs();
                configFile.createNewFile();
            }
            config.save(configFile);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public FileConfiguration getConfig() {
        return (FileConfiguration)config;
    }
}
