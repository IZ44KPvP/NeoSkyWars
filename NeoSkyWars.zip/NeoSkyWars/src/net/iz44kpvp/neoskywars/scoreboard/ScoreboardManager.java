package net.iz44kpvp.neoskywars.scoreboard;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.player.SkyPlayer;
import net.iz44kpvp.neoskywars.player.storage.Stats;
import net.iz44kpvp.neoskywars.scoreboard.animated.AnimationType;
import net.iz44kpvp.neoskywars.skywars.SkyWars;
import net.iz44kpvp.neoskywars.skywars.SkyWars.ChestType;

public class ScoreboardManager
{
    private static List<SkyBoard> scoreboards;
    
    static {
        ScoreboardManager.scoreboards = new ArrayList<SkyBoard>();
    }
    
    public static void iniciarScoreboardSkywars(final Player p, final SkyWars sw) {
        ScoreboardManager.scoreboards.add(new SkyBoard(p) {
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
            Date date = new Date();
            
            @Override
            public void scoreboardUpdate() {
                int score = 1;
                int players = 0;
                SkyPlayer[] players2;
                for (int length = (players2 = sw.getPlayers()).length, i = 0; i < length; ++i) {
                    final SkyPlayer swp = players2[i];
                    if (swp.isAlive()) {
                        ++players;
                    }
                }
                
                String mode = null;
                
                if(sw.getChestType() == ChestType.NORMAL){
                	mode = "�1Normal";
                }else if(sw.getChestType() == ChestType.INSANE){
                	mode = "�cInsane";
                }else if(sw.getChestType() == ChestType.MEGA){
                	mode = "�aMega";
                }
                
                for (String line : Messages.getInstance().SCOREBOARD_ROOM) {
                    line = ChatColor.translateAlternateColorCodes('&', line);
                    SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
                    this.setOrUpdateLine(line.replace("<players>", String.valueOf(players)).replace("<date>", new StringBuilder().append(this.dateFormat.format(this.date)).toString()).replace("<type>", String.valueOf(sw.getMode().toString().substring(0, 1).toUpperCase()) + sw.getMode().toString().substring(1).toLowerCase()).replace("<fill>", new StringBuilder().append(new SimpleDateFormat("mm:ss").format(new Date(Math.round(sw.getRefill()) * 1000))).toString()).replace("<mode>", mode).replace("<kills>", String.valueOf(sw.getKills(p))).replace("<spects>", String.valueOf(sw.getSpects())).replace("<map>", sw.getID()), score);
                    ++score;
                }
            }
        }.activeScoreboard());
        AnimationType type = null;
        final Long ticksToUpdate = Main.getInstance().getConfig().getLong("Update_Animation_Time");
        final String title = Main.getInstance().getConfig().getString("Scoreboard_Title");
        final String[] a = title.split(" ")[0].split(",");
        final String[] b = title.split(" ");
        if (a[0].equalsIgnoreCase("highligth=true") && a.length == 3 && b.length == 2) {
            type = AnimationType.HIGHLIGHTED;
            getScoreboard(p).activeAnimation(type, ChatColor.translateAlternateColorCodes('&', b[1].replaceAll("_", " ")), ticksToUpdate, a[1], a[2]);
        }
        else if (a[0].equalsIgnoreCase("scroller=true") && a.length == 2 && b.length == 2) {
            type = AnimationType.SCROLLED;
            getScoreboard(p).activeAnimation(type, ChatColor.translateAlternateColorCodes('&', b[1].replaceAll("_", " ")), ticksToUpdate, null, null);
        }
        else {
            type = AnimationType.NONE;
            getScoreboard(p).activeAnimation(type, ChatColor.translateAlternateColorCodes('&', b[1].replaceAll("_", " ")), ticksToUpdate, null, null);
        }
    }

    public static void iniciarScoreboardWait(final Player p, final SkyWars sw) {
        ScoreboardManager.scoreboards.add(new SkyBoard(p) {
            @Override
            public void scoreboardUpdate() {
                int score = 1;
                int players = 0;
                SkyPlayer[] players2;
                for (int length = (players2 = sw.getPlayers()).length, i = 0; i < length; ++i) {
                    final SkyPlayer swp = players2[i];
                    if (swp.isAlive()) {
                        ++players;
                    }
                }
                for (String line : Messages.getInstance().SCOREBOARD_WAIT) {
                    line = ChatColor.translateAlternateColorCodes('&', line);
                     int start;
                     try{
                    	 start = sw.getCountdown().getTime();
                     }catch(Exception e){
                    	 start = 15;
                     }
                   
                    this.setOrUpdateLine(line.replace("<players>", String.valueOf(players + "/" + sw.getMaxPlayers())).replace("<time>", "" + start).replace("<server>", Main.getPlugin().getConfig().getString("Server")).replace("<map>", sw.getID()), score);
                    ++score;
                }
            }
        }.activeScoreboard());
        AnimationType type = null;
        final Long ticksToUpdate = Main.getInstance().getConfig().getLong("Update_Animation_Time");
        final String title = Main.getInstance().getConfig().getString("Scoreboard_Title");
        final String[] a = title.split(" ")[0].split(",");
        final String[] b = title.split(" ");
        if (a[0].equalsIgnoreCase("highligth=true") && a.length == 3 && b.length == 2) {
            type = AnimationType.HIGHLIGHTED;
            getScoreboard(p).activeAnimation(type, ChatColor.translateAlternateColorCodes('&', b[1].replaceAll("_", " ")), ticksToUpdate, a[1], a[2]);
        }
        else if (a[0].equalsIgnoreCase("scroller=true") && a.length == 2 && b.length == 2) {
            type = AnimationType.SCROLLED;
            getScoreboard(p).activeAnimation(type, ChatColor.translateAlternateColorCodes('&', b[1].replaceAll("_", " ")), ticksToUpdate, null, null);
        }
        else {
            type = AnimationType.NONE;
            getScoreboard(p).activeAnimation(type, ChatColor.translateAlternateColorCodes('&', b[1].replaceAll("_", " ")), ticksToUpdate, null, null);
        }
    }
    
    public static void iniciarScoreboardLobby(final Player p) {
        ScoreboardManager.scoreboards.add(new SkyBoard(p) {
            @Override
            public void scoreboardUpdate() {
                int score = 1;
                for (String line : Messages.getInstance().SCOREBOARD_LOBBY) {
                    line = ChatColor.translateAlternateColorCodes('&', line);
                    this.setOrUpdateLine(line.replace("<players>", Bukkit.getOnlinePlayers().size() + "/" + Bukkit.getMaxPlayers()).replace("<souls>", String.valueOf(Stats.getSouls(p))).replace("<coins>", String.valueOf(Stats.getCoins(p))).replace("<wins>", String.valueOf(Stats.getWins(p))).replace("<player>", p.getName()).replace("<games>", String.valueOf(Stats.getGames(p))).replace("<kills>", String.valueOf(Stats.getKills(p))).replace("<deaths>", String.valueOf(Stats.getDeaths(p))), score);
                    ++score;
                }
            }
        }.activeScoreboard());
        AnimationType type = null;
        final Long ticksToUpdate = Main.getInstance().getConfig().getLong("Update_Animation_Time");
        final String title = Main.getInstance().getConfig().getString("Scoreboard_Title");
        final String[] a = title.split(" ")[0].split(",");
        final String[] b = title.split(" ");
        if (a[0].equalsIgnoreCase("highligth=true") && a.length == 3 && b.length == 2) {
            type = AnimationType.HIGHLIGHTED;
            getScoreboard(p).activeAnimation(type, ChatColor.translateAlternateColorCodes('&', b[1].replaceAll("_", " ")), ticksToUpdate, a[1], a[2]);
        }
        else if (a[0].equalsIgnoreCase("scroller=true") && a.length == 2 && b.length == 2) {
            type = AnimationType.SCROLLED;
            getScoreboard(p).activeAnimation(type, ChatColor.translateAlternateColorCodes('&', b[1].replaceAll("_", " ")), ticksToUpdate, null, null);
        }
        else {
            type = AnimationType.NONE;
            getScoreboard(p).activeAnimation(type, ChatColor.translateAlternateColorCodes('&', b[1].replaceAll("_", " ")), ticksToUpdate, null, null);
        }
    }
    
    public static SkyBoard getScoreboard(final Player p) {
        for (final SkyBoard sb : ScoreboardManager.scoreboards) {
            if (sb.getPlayer().equals(p)) {
                return sb;
            }
        }
        return null;
    }
    
    public static void removeScoreboard(final SkyBoard skyboard) {
        ScoreboardManager.scoreboards.remove(skyboard.deactiveScoreboard());
    }
}
