package net.iz44kpvp.neoskywars.scoreboard;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import com.google.common.base.Splitter;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.scoreboard.animated.AnimationType;
import net.iz44kpvp.neoskywars.scoreboard.animated.HighlightedString;
import net.iz44kpvp.neoskywars.scoreboard.animated.ScrollableString;


@SuppressWarnings("all")
public abstract class SkyBoard
{
    private Player player;
    private int currentColor;
    private String[] colors;
    private Scoreboard theScoreboard;
    private Objective scoreboardObjective;
    private boolean isActived;
    private BukkitTask scoreboardTask;
    private BukkitTask scoreboardAnimationTask;
    private HashMap<String, Integer> line;
    
    public SkyBoard(final Player p) {
        this.colors = new String[] { "a", "b", "c", "d", "e", "f", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
        this.line = new HashMap<String, Integer>();
        this.player = p;
        this.currentColor = 0;
        this.isActived = false;
        this.scoreboardTask = null;
        this.theScoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        this.scoreboardObjective = this.getTheScoreboard().registerNewObjective("board", "dummy");
        this.getScoreboardObjective().setDisplayName("");
        this.getScoreboardObjective().setDisplaySlot(DisplaySlot.SIDEBAR);
    }
    
    public SkyBoard activeScoreboard() {
        if (this.isActived()) {
            return this;
        }
        this.isActived = true;
        this.player.setScoreboard(this.theScoreboard);
        this.scoreboardTask = new BukkitRunnable() {
            public void run() {
                SkyBoard.access$0(SkyBoard.this, 0);
                SkyBoard.this.scoreboardUpdate();
            }
        }.runTaskTimer((Plugin)Main.getInstance(), 0L, 20L);
        return this;
    }
    
    public SkyBoard deactiveScoreboard() {
        if (!this.isActived()) {
            return this;
        }
        this.isActived = false;
        if (this.player.isOnline()) {
            this.player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
        }
        this.getScoreboardTask().cancel();
        this.scoreboardTask = null;
        if (this.getScoreboardAnimationTask() != null) {
            this.getScoreboardAnimationTask().cancel();
        }
        this.scoreboardAnimationTask = null;
        return this;
    }
    
    public SkyBoard activeAnimation(final AnimationType type, final String title, final long ticksToUpdate, final String normalFormat, final String highlightFormat) {
        if (type == null) {
            return this;
        }
        if (this.getScoreboardAnimationTask() != null) {
            this.getScoreboardAnimationTask().cancel();
        }
        if (type.equals(AnimationType.HIGHLIGHTED)) {
            this.scoreboardAnimationTask = new BukkitRunnable() {
                HighlightedString animated = new HighlightedString(title, normalFormat, highlightFormat);
                
                public void run() {
                    final String finalTitle = SkyBoard.format(this.animated.next());
                    if (!SkyBoard.this.getScoreboardObjective().getDisplayName().equals(finalTitle)) {
                        SkyBoard.this.getScoreboardObjective().setDisplayName(SkyBoard.format(finalTitle));
                    }
                }
            }.runTaskTimer((Plugin)Main.getInstance(), 0L, ticksToUpdate);
            return this;
        }
        if (type.equals(AnimationType.SCROLLED)) {
            this.scoreboardAnimationTask = new BukkitRunnable() {
                ScrollableString animated = new ScrollableString(SkyBoard.format(toString()), "&6&l", 16, toString().length());
                
                public void run() {
                    SkyBoard.this.getScoreboardObjective().setDisplayName(this.animated.next());
                }
            }.runTaskTimer((Plugin)Main.getInstance(), 0L, ticksToUpdate);
            return this;
        }
        this.getScoreboardObjective().setDisplayName(ChatColor.translateAlternateColorCodes('&', title));
        return this;
    }
    
    public abstract void scoreboardUpdate();
    
    public SkyBoard setOrUpdateLine(final String textForLine, final int lineNumber) {
        final Iterator<String> itr = Splitter.fixedLength(16).split((CharSequence)textForLine).iterator();
        if (textForLine.length() > 32) {
            Team t = this.getTheScoreboard().getTeam("line-" + lineNumber);
            if (t == null) {
                t = this.getTheScoreboard().registerNewTeam("line-" + lineNumber);
            }
            t.setPrefix((String)itr.next());
            final FakePlayer fp = new FakePlayer(((ChatColor.getLastColors(t.getPrefix()) != null) ? ChatColor.getLastColors(t.getPrefix()) : ChatColor.RESET) + itr.next());
            if (t.getPlayers().size() > 0 && !t.getPlayers().contains(fp)) {
                t.getPlayers().clear();
            }
            if (!t.hasPlayer((OfflinePlayer)fp)) {
                t.addPlayer((OfflinePlayer)fp);
            }
            t.setSuffix(((ChatColor.getLastColors(fp.getName()) != null) ? ChatColor.getLastColors(fp.getName()) : ChatColor.RESET) + itr.next());
            for (final String str : this.getTheScoreboard().getEntries()) {
                if (str.equals(fp.getName())) {
                    this.getTheScoreboard().resetScores((OfflinePlayer)fp);
                }
            }
            this.getScoreboardObjective().getScore((OfflinePlayer)fp).setScore(lineNumber);
            return this;
        }
        final String prefix = itr.next();
        final String color = "�" + this.getColors()[this.currentColor++] + "�r";
        final FakePlayer fp2 = new FakePlayer(color);
        Team t2 = this.getTheScoreboard().getTeam("line-" + lineNumber);
        if (t2 == null) {
            t2 = this.getTheScoreboard().registerNewTeam("line-" + lineNumber);
        }
        if (!t2.hasPlayer((OfflinePlayer)fp2)) {
            t2.addPlayer((OfflinePlayer)fp2);
        }
        t2.setPrefix(prefix);
        if (textForLine.length() > 16) {
            t2.setSuffix(((ChatColor.getLastColors(prefix) != null) ? ChatColor.getLastColors(prefix) : ChatColor.RESET) + itr.next());
        }
        else {
            t2.setSuffix("");
        }
        this.getScoreboardObjective().getScore((OfflinePlayer)fp2).setScore(lineNumber);
        return this;
    }
    
    public static String format(final String string) {
        return ChatColor.translateAlternateColorCodes('&', string);
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    public int getCurrentColor() {
        return this.currentColor;
    }
    
    public String[] getColors() {
        return this.colors;
    }
    
    public Scoreboard getTheScoreboard() {
        return this.theScoreboard;
    }
    
    public Objective getScoreboardObjective() {
        return this.scoreboardObjective;
    }
    
    public boolean isActived() {
        return this.isActived;
    }
    
    public BukkitTask getScoreboardTask() {
        return this.scoreboardTask;
    }
    
    public BukkitTask getScoreboardAnimationTask() {
        return this.scoreboardAnimationTask;
    }
    
    public HashMap<String, Integer> getLine() {
        return this.line;
    }
    
    static /* synthetic */ void access$0(final SkyBoard skyBoard, final int currentColor) {
        skyBoard.currentColor = currentColor;
    }
    
    public class FakePlayer implements OfflinePlayer
    {
        private String name;
        
        public FakePlayer(final String name) {
            this.name = name;
        }
        
        public boolean isOp() {
            return false;
        }
        
        public void setOp(final boolean arg0) {
        }
        
        public Map<String, Object> serialize() {
            return null;
        }
        
        public Location getBedSpawnLocation() {
            return null;
        }
        
        public long getFirstPlayed() {
            return 0L;
        }
        
        public long getLastPlayed() {
            return 0L;
        }
        
        public String getName() {
            return this.name;
        }
        
        public Player getPlayer() {
            return null;
        }
        
        public UUID getUniqueId() {
            return null;
        }
        
        public boolean hasPlayedBefore() {
            return false;
        }
        
        public boolean isBanned() {
            return false;
        }
        
        public boolean isOnline() {
            return false;
        }
        
        public boolean isWhitelisted() {
            return false;
        }
        
        public void setBanned(final boolean arg0) {
        }
        
        public void setWhitelisted(final boolean arg0) {
        }
    }
}
