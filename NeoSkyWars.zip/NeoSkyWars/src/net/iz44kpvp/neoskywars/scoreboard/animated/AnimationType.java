package net.iz44kpvp.neoskywars.scoreboard.animated;

public enum AnimationType
{
    NONE("NONE", 0), 
    SCROLLED("SCROLLED", 1), 
    HIGHLIGHTED("HIGHLIGHTED", 2);
    
    private AnimationType(final String s, final int n) {
    }
}
