package net.iz44kpvp.neoskywars.scoreboard.animated;

public interface AnimatableString
{
    String current();
    
    String next();
    
    String previous();
}
