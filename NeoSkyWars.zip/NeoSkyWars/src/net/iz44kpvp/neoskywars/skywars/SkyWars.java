
package net.iz44kpvp.neoskywars.skywars;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.SettingsManager;
import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.api.title.Title1_11;
import net.iz44kpvp.neoskywars.api.title.Title1_8;
import net.iz44kpvp.neoskywars.controllers.ChatController;
import net.iz44kpvp.neoskywars.controllers.KitController;
import net.iz44kpvp.neoskywars.lobby.Lobby;
import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.managers.TimerManager;
import net.iz44kpvp.neoskywars.player.SkyPlayer;
import net.iz44kpvp.neoskywars.player.storage.Stats;
import net.iz44kpvp.neoskywars.scoreboard.ScoreboardManager;
import net.iz44kpvp.neoskywars.utils.CuboID;
import net.iz44kpvp.neoskywars.utils.ItemBuilder;


@SuppressWarnings("all")
public class SkyWars
{
    private String ID;
    private GameMode mode;
    private int time;
    private GameState state;
    private BukkitTask task;
    private int refilltime;
    private boolean deathMatch;
    private boolean hasCheckedWin;
    private ChestType chestType;
    private Location dmLocation;
    private TimerManager countdown;
    private SettingsManager config;
    private CuboID bounds;
    private List<BlockState> states;
    private List<SkyWarsSpawn> spawns;
    private List<SkyPlayer> players;
    
    
    public static ArrayList<Player> invencible = new ArrayList<>();;
    public static ArrayList<Player> spectador = new ArrayList<Player>();

    
    public int getSpects(){
		return spectador.size();
    }
    
    
    
    public SkyWars(final String ID, final GameMode mode, final ChestType type) {
        this.time = 900;
        this.refilltime = 270;
        this.states = new ArrayList<BlockState>();
        this.spawns = new ArrayList<SkyWarsSpawn>();
        this.players = new ArrayList<SkyPlayer>();
        this.ID = ID;
        this.mode = mode;
        this.config = SettingsManager.getSkywars(ID);
        this.chestType = type;
        this.deathMatch = false;
        this.hasCheckedWin = false;
        this.state = GameState.WAITING;
        try {
            this.bounds = new CuboID(this.config.loadLocation(this.config.get("boundsA.location")), this.config.loadLocation(this.config.get("boundsB.location")));
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        if (this.config.contains("spawns")) {
            for (final String spawnID : this.config.get("spawns").getKeys(false)) {
                this.spawns.add(new SkyWarsSpawn(this.config.loadLocation(this.config.get("spawns." + spawnID + ".location")), mode));
            }
        }
        if (this.config.contains("chests")) {
            for (final String chestID : this.config.get("chests").getKeys(false)) {
                final Location loc = this.config.loadLocation(this.config.get("chests." + chestID + ".location"));
                if (loc.getBlock() == null || !(loc.getBlock().getState() instanceof Chest)) {
                    this.config.set("chests." + chestID, null);
                }
                else {
                    loc.getBlock().getState().update();
                }
            }
        }
        if (this.config.contains("feastchests")) {
            for (final String chestID : this.config.get("feastchests").getKeys(false)) {
                final Location loc = this.config.loadLocation(this.config.get("feastchests." + chestID + ".location"));
                if (loc.getBlock() == null || !(loc.getBlock().getState() instanceof Chest)) {
                    this.config.set("feastchests." + chestID, null);
                }
                else {
                    loc.getBlock().getState().update();
                }
            }
        }
        if (this.config.contains("deathmatch")) {
            this.dmLocation = this.config.loadLocation(this.config.get("deathmatch.location"));
        }
    }
    
    public void addPlayer(final Player p) {
        if (this.state.equals(GameState.STARTED)) {
            p.sendMessage(Messages.getInstance().SKYWARS_ALREADY_INGAME);
            return;
        }
        if (this.players.size() == this.getMaxPlayers()) {
            p.sendMessage(Messages.getInstance().SKYWARS_FULL);
            return;
        }
        if (SkyWarsManager.getInstance().getSkyWars(p) != null) {
            p.sendMessage(Messages.getInstance().YOU_ALREADY_IN_GAME);
            return;
        }
        if (ScoreboardManager.getScoreboard(p) != null) {
            ScoreboardManager.removeScoreboard(ScoreboardManager.getScoreboard(p));
        }
        Lobby.getInstance().removePlayer(p);
        this.players.add(new SkyPlayer(p));
        
        ScoreboardManager.iniciarScoreboardWait(p, this);
        
        
        this.getPlayer(p).setAlive(true);
        for (final PotionEffect effects : p.getActivePotionEffects()) {
            p.removePotionEffect(effects.getType());
        }
        p.getInventory().clear();
        p.getInventory().setArmorContents((ItemStack[])null);
        p.setAllowFlight(false);
        p.setHealth(20.0);
        p.setFoodLevel(20);
        Stats.addGames(p, 1);
        final ItemStack kit = new ItemBuilder(Material.BOW, Messages.getInstance().SW_KITSELECTOR_DISPLAY).getItem();
        final ItemStack bed = new ItemBuilder(Material.BED, Messages.getInstance().SW_BEDQUIT_DISPLAY).getItem();
        final ItemStack options = new ItemBuilder(Material.BLAZE_POWDER, Messages.getInstance().SW_OPTIONS_DISPLAY).getItem();
        
        p.getInventory().setItem(1, options);
        p.getInventory().setItem(0, kit); 
        p.getInventory().setItem(8, bed);
        p.updateInventory();
        
        
        
        for (final SkyPlayer players : this.players) {
            players.getPlayer().sendMessage(Messages.getInstance().SKYWARS_PLAYER_JOIN.replace("<player>", p.getName()).replace("<players>", String.valueOf(this.players.size()) + "/" + this.getMaxPlayers()));
            if (!p.canSee(players.getPlayer())) {
                p.showPlayer(players.getPlayer());
            }
            if (!players.getPlayer().canSee(p)) {
                players.getPlayer().showPlayer(p);
            }
        }
        
        //Tab Color
        p.setDisplayName("§a" + p.getName());
        for(SkyPlayer ps : players){
        	p.setDisplayName("§c" + p.getName());
        }
        
        	
        
        //Tab Color
        
        
        SkyWarsSpawn[] spawns;
        for (int length = (spawns = this.getSpawns()).length, i = 0; i < length; ++i) {
            final SkyWarsSpawn spawn = spawns[i];
            if (spawn.hasSlot()) {
            	spawn.getLocation().setWorld(Bukkit.getWorld(this.getID()));
            	p.teleport(spawn.getLocation());
                spawn.addPlayer(this.getPlayer(p));   
                	if(SkyWars.this.getMode() == GameMode.SOLO){
                	SkyWars.this.addCage(p.getLocation(), false);
                }else{
                	SkyWars.this.addCage(p.getLocation(), true);
                }
                break;
            }
        }
        
       
        	 if(Main.is18()){
            	 Title1_8 t1 = new Title1_8(Messages.getInstance().SKYWARS_TITLE_ON_JOIN, Messages.getInstance().SKYWARS_SUBTITLE_ON_JOIN.replace("<mode>", String.valueOf(this.getChestType().toString().substring(0, 1).toUpperCase()) + this.getChestType().toString().substring(1).toLowerCase()));
                 t1.send(p);
            }else{
            	Title1_11 t1 = new Title1_11(Messages.getInstance().SKYWARS_TITLE_ON_JOIN, Messages.getInstance().SKYWARS_SUBTITLE_ON_JOIN.replace("<mode>", String.valueOf(this.getChestType().toString().substring(0, 1).toUpperCase()) + this.getChestType().toString().substring(1).toLowerCase()));
                t1.send(p);
            }
        
        
        if (this.getCountdown() == null && this.getPlayers().length >= Main.getPlugin().getConfig().getInt("Min-Players")) {
            this.countdown = new TimerManager(this, 15, new int[] {10, 5, 4, 3, 2, 1 });
            this.getCountdown().start();
        }
        
    	
    }
    
    
    
    public void spectate(final Player p) {
        SkyPlayer[] players2;
        for (int length = (players2 = this.getPlayers()).length, i = 0; i < length; ++i) {
            final SkyPlayer players = players2[i];
            players.getPlayer().hidePlayer(p);
        }
        this.getPlayer(p).setDead(false);
        p.getInventory().clear();
        p.getInventory().setArmorContents((ItemStack[])null);
        p.setAllowFlight(true);
        p.setHealth(20.0);
        p.setFoodLevel(20);
        p.setFlying(true);
        p.teleport(this.getIsland(p).getLocation());
        p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 3));
        final ItemStack compass = new ItemBuilder(Material.COMPASS, Messages.getInstance().SW_SPECT_COMPASS_DISPLAY).getItem();
        final ItemStack paper = new ItemBuilder(Material.PAPER, Messages.getInstance().SW_PAPER_PLAY_AGAIN_DISPLAY).getItem();
        final ItemStack bed = new ItemBuilder(Material.BED, Messages.getInstance().SW_BEDQUIT_DISPLAY).getItem();
        p.getInventory().setItem(0, compass);
        p.getInventory().setItem(4, paper);
        p.getInventory().setItem(8, bed);
      
        if(!SkyWars.spectador.contains(p)){
        	SkyWars.spectador.add(p);
        }
        
        if(Main.is18()){
        	Title1_8 t = new Title1_8(Messages.getInstance().SKYWARS_TITLE_DEAD, Messages.getInstance().SKYWARS_SUBTITLE_DEAD);
            t.send(p);
        }else{
        	Title1_11 t = new Title1_11(Messages.getInstance().SKYWARS_TITLE_DEAD, Messages.getInstance().SKYWARS_SUBTITLE_DEAD);
            t.send(p);
        }
        this.checkWin();
    }
    
    public void removePlayer(final Player p) {
        SkyWarsSpawn[] spawns;
        for (int length = (spawns = this.getSpawns()).length, i = 0; i < length; ++i) {
            final SkyWarsSpawn spawn = spawns[i];
            if (spawn.getPlayers().length > 0 && spawn.hasPlayer(this.getPlayer(p))) {
                spawn.removePlayer(this.getPlayer(p));
                break;
            }
        }
        for (Player ps : Bukkit.getOnlinePlayers()) {
            
            if (SkyWarsManager.getInstance().getSkyWars(ps) == null) {
                if (Lobby.getInstance().hasPlayer(ps)) {
                    if (Lobby.getInstance().hasPlayer(ps) && Lobby.getInstance().getPlayer(ps).canViewPlayers()) {
                        ps.showPlayer(p);
                    }
                    p.showPlayer(ps);
                }
            }
        }
        if (ScoreboardManager.getScoreboard(p) != null) {
            ScoreboardManager.removeScoreboard(ScoreboardManager.getScoreboard(p));
        }
        this.players.remove(this.getPlayer(p));
        p.getInventory().clear();
        p.getInventory().setArmorContents((ItemStack[])null);
        p.updateInventory();
        if (!Lobby.getInstance().hasPlayer(p)) {
            Lobby.getInstance().addPlayer(p);
        }
        new BukkitRunnable() {
            public void run() {
                if (!p.isOnline()) {
                    Lobby.getInstance().removePlayer(p);
                }
            }
        }.runTaskLater((Plugin)Main.getInstance(), 2L);
        if (Lobby.getInstance().isLobby()) {
            p.teleport(Lobby.getInstance().getLobby());
        }
        p.setAllowFlight(false);
        p.setHealth(20.0);
        p.setExp(0);
        for (final PotionEffect effects : p.getActivePotionEffects()) {
            p.removePotionEffect(effects.getType());
        }
     
        if(SkyWars.spectador.contains(p)){
        	spectador.remove(p);
        }

        ScoreboardManager.iniciarScoreboardLobby(p);
        this.checkWin();

    }
       
    
    public void removePlayerSilent(final Player p) {
        SkyWarsSpawn[] spawns;
        for (int length = (spawns = this.getSpawns()).length, i = 0; i < length; ++i) {
            final SkyWarsSpawn spawn = spawns[i];
            if (spawn.getPlayers().length > 0 && spawn.hasPlayer(this.getPlayer(p))) {
                spawn.removePlayer(this.getPlayer(p));
                break;
            }
        }
        for (Player ps : Bukkit.getOnlinePlayers()) {
            if (!ps.canSee(p)) {
                ps.showPlayer(p);
            }
        }
        if (ScoreboardManager.getScoreboard(p) != null) {
            ScoreboardManager.removeScoreboard(ScoreboardManager.getScoreboard(p));
        }
 
       if(SkyWars.spectador.contains(p)){
    	   this.spectador.remove(p);
       }

        this.players.remove(this.getPlayer(p));
        p.getInventory().clear();
        p.getInventory().setArmorContents((ItemStack[])null);
        p.updateInventory();
        if (!Lobby.getInstance().hasPlayer(p)) {
            Lobby.getInstance().addPlayer(p);
        }
        if (Lobby.getInstance().isLobby()) {
            p.teleport(Lobby.getInstance().getLobby());
        }
        p.setAllowFlight(false);
        p.setHealth(20.0);
        p.setExp(0);
        for (final PotionEffect effects : p.getActivePotionEffects()) {
            p.removePotionEffect(effects.getType());
        }
        ScoreboardManager.iniciarScoreboardLobby(p);
        this.checkWin();
    }
    
    public void checkWin() {
        if (this.state != GameState.STARTED) {
            return;
        }
        if(hasCheckedWin){
        	return;
        }
        final List<SkyPlayer> alive = new ArrayList<SkyPlayer>();
        SkyPlayer[] players;
        for (int length = (players = this.getPlayers()).length, i = 0; i < length; ++i) {
            final SkyPlayer player = players[i];
            if (player.isAlive()) {
                alive.add(player);
            }
        }
        if(this.getMode() == GameMode.SOLO){
        	if(alive.size() > 1){
        		return;
        	}
                if (alive.size() == 1) {
                	hasCheckedWin = true;
                    final Player p = alive.get(0).getPlayer();
                    this.task.cancel();
                    this.task = null;
                    Stats.addWins(p, 1);
                    if(p.hasPermission("skywars.coins.x5")){
                    	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                    	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                    }else if(p.hasPermission("skywars.coins.x4")){
                    	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                    	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                    }else if(p.hasPermission("skywars.coins.x3")){
                    	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                    	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                    }else if(p.hasPermission("skywars.coins.x2")){
                    	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                    	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                    }else{
                    	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                    	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                    }
                    
                    p.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
    				new BukkitRunnable() {
    					int tempo = 15;

    					public void run() {
    						if (tempo > 0 && tempo != 1) {
    							firework(p);
    						}
    						if (tempo == 1) {
    							firework(p);
    						}
    						if (tempo == 0) {
    							firework(p);
    							cancel();
    						}
    						--tempo;
    					}
    				}.runTaskTimer(Main.getPlugin(), 0, 20);
                    
    				if(!SkyWars.invencible.contains(p)){
    					SkyWars.invencible.add(p);
    				}
                    
                    
                    for(SkyPlayer ps : this.getPlayers()){
                    	for(String list : Messages.getInstance().SKYWARS_PLAYERS_MESSAGE_WIN){
                    		list = ChatColor.translateAlternateColorCodes('&', list);
                    		ps.getPlayer().sendMessage(list.replace("<player>", p.getName()));
                    	}
                    	
                    	
                    	if(Main.is18()){
                    		Title1_8 t2 = new Title1_8(Messages.getInstance().SKYWARS_PLAYERS_TITLE_WIN.replaceAll("<player>", p.getName()), Messages.getInstance().SKYWARS_PLAYERS_SUBTITLE_WIN.replaceAll("<player>", p.getName()));
                        	t2.send(ps.getPlayer());
                    	}else{
                    		Title1_11 t2 = new Title1_11(Messages.getInstance().SKYWARS_PLAYERS_TITLE_WIN.replaceAll("<player>", p.getName()), Messages.getInstance().SKYWARS_PLAYERS_SUBTITLE_WIN.replaceAll("<player>", p.getName()));
                        	t2.send(ps.getPlayer());
                    	}
                    	
                    }
                    
                    if(Main.is18()){
                    	Title1_8 t = new Title1_8(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                        t.send(p);
                    }else{
                    	Title1_11 t = new Title1_11(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                        t.send(p);
                    }
                    
                    for(String list : Messages.getInstance().SKYWARS_REWARDS){
                    	list = ChatColor.translateAlternateColorCodes('&', list);
                    	p.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p))));
                    }
                    
                    RewardSummary.getInstance().resetPlayer(p);
                    RewardSummary.getInstance().resetPlayerSouls(p);
                    ChatController.runCommand(p, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                    for(String cmds : Main.extraconfig.getConfig().getStringList("Player-On-Game-Win-Commands")){
                    	p.chat(cmds);
                    }
                    
                    	try{
                    		Bukkit.dispatchCommand(Bukkit.getConsoleSender(), Main.extraconfig.getConfig().getString("Console-On-Player-Win-Command").replace("%winner%", p.getName()));
                    	}catch(Exception ex){
                    		//Empty
                    	}
                    

                    new BukkitRunnable() {
                        public void run() {
                            if (SkyWarsManager.getInstance().getSkyWars(p) != null && SkyWarsManager.getInstance().getSkyWars(p).getID().equals(SkyWars.this.ID)) {
                                p.setAllowFlight(false);
                            }
                            if(SkyWars.invencible.contains(p)){
            					SkyWars.invencible.remove(p);
            				}
                            SkyWars.this.reset();
                        }
                    }.runTaskLater((Plugin)Main.getInstance(), 300L);
                    
                    
                }
                else {
                    try{
                    	this.task.cancel();
                    }catch(Exception e){
                    	e.printStackTrace();
                    }
                    this.task = null;
                    this.reset();
                }
        }
        else {
            if(alive.size() > 2){
            	return;
            }
            if (alive.size() == 2) {
            	hasCheckedWin = true;
                if (this.getIsland(alive.get(0).getPlayer()).hasPlayer(alive.get(1))) {
                    final Player p = alive.get(0).getPlayer();
                    final Player p2 = alive.get(1).getPlayer();
                    this.task.cancel();
                    this.task = null;
                    Stats.addWins(p, 1);
                    Stats.addWins(p2, 1);
                    if(p.hasPermission("skywars.coins.x5")){
                    	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                    	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                    }else if(p.hasPermission("skywars.coins.x4")){
                    	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                    	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                    }else if(p.hasPermission("skywars.coins.x3")){
                    	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                    	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                    }else if(p.hasPermission("skywars.coins.x2")){
                    	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                    	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                    }else{
                    	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                    	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                    }
                    
                    SkyPlayer pl2 = new SkyPlayer(p2);
                    if(p2.hasPermission("skywars.coins.x5")){
                    	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                    	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                    }else if(p2.hasPermission("skywars.coins.x4")){
                    	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                    	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                    }else if(p2.hasPermission("skywars.coins.x3")){
                    	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                    	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                    }else if(p2.hasPermission("skywars.coins.x2")){
                    	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                    	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                    }else{
                    	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win"));
                    	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win"));
                    }
                    
                    
                    p.setAllowFlight(true);
                    p2.setAllowFlight(true);
      		        p.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
                    p2.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
    				new BukkitRunnable() {
    					int tempo = 15;

    					public void run() {
    						if (tempo > 0 && tempo != 1) {
    							firework(p);
    							firework(p2);
    						}
    						if (tempo == 1) {
    							firework(p);
    							firework(p2);
    						}
    						if (tempo == 0) {
    							firework(p);
    							firework(p2);
    							cancel();
    						}
    						--tempo;
    					}
    				}.runTaskTimer(Main.getPlugin(), 0, 20);
                    
    				if(!SkyWars.invencible.contains(p)){
    					SkyWars.invencible.add(p);
    				}
    				if(!SkyWars.invencible.contains(p2)){
    					SkyWars.invencible.add(p2);
    				}
    				
                    
                    for(SkyPlayer ps : this.getPlayers()){
                    	for(String list : Messages.getInstance().SKYWARS_TEAM_PLAYERS_MESSAGE_WIN){
                    		list = ChatColor.translateAlternateColorCodes('&', list);
                    		ps.getPlayer().sendMessage(list.replace("<player>", p.getName()).replace("<player2>", p2.getName()));
                    	}
                    	
                    
                    	
                    	if(Main.is18()){
                    		Title1_8 t2 = new Title1_8(Messages.getInstance().SKYWARS_TEAM_PLAYERS_TITLE_WIN.replace("<player1>", p.getName()).replace("<player2>", p2.getName()), Messages.getInstance().SKYWARS_TEAM_PLAYERS_SUBTITLE_WIN.replace("<player1>", p.getName()).replace("<player2>", p2.getName()));
                        	t2.send(ps.getPlayer());
                    	}else{
                    		Title1_11 t2 = new Title1_11(Messages.getInstance().SKYWARS_TEAM_PLAYERS_TITLE_WIN.replace("<player1>", p.getName()).replace("<player2>", p2.getName()), Messages.getInstance().SKYWARS_TEAM_PLAYERS_SUBTITLE_WIN.replace("<player1>", p.getName()).replace("<player2>", p2.getName()));
                        	t2.send(ps.getPlayer());
                    	}
                    	
                    }
                   
                    
                    if(Main.is18()){
                    	Title1_8 t = new Title1_8(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                        t.send(p);
                        t.send(p2);
                    }else{
                    	Title1_11 t = new Title1_11(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                        t.send(p);
                        t.send(p2);
                    }
                        
                    
                    for(String list : Messages.getInstance().SKYWARS_REWARDS){
                    	list = ChatColor.translateAlternateColorCodes('&', list);
                    	p.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p))));
                    	p2.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p2))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p2))));
                    }
                    
                    RewardSummary.getInstance().resetPlayer(p);
                    RewardSummary.getInstance().resetPlayerSouls(p);
                    RewardSummary.getInstance().resetPlayer(p2);
                    RewardSummary.getInstance().resetPlayerSouls(p2);
                    
                    ChatController.runCommand(p, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                    ChatController.runCommand(p2, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                    
                    
                    new BukkitRunnable() {
                        public void run() {
                            if (SkyWarsManager.getInstance().getSkyWars(p) != null && SkyWarsManager.getInstance().getSkyWars(p).getID().equals(SkyWars.this.ID)) {
                                p.setAllowFlight(false);
                            }
                            if (SkyWarsManager.getInstance().getSkyWars(p2) != null && SkyWarsManager.getInstance().getSkyWars(p2).getID().equals(SkyWars.this.ID)) {
                                p2.setAllowFlight(false);
                            }
                            
                            if(SkyWars.invencible.contains(p)){
            					SkyWars.invencible.remove(p);
            				}
            				if(SkyWars.invencible.contains(p2)){
            					SkyWars.invencible.remove(p2);
            				}
                            
                            SkyWars.this.reset();
                           
                        }
                    }.runTaskLater((Plugin)Main.getInstance(), 300L);
                }
            }
            else if (alive.size() <= 1) {
            	hasCheckedWin = true;
                final Player p = alive.get(0).getPlayer();
                this.task.cancel();
                this.task = null;
                Stats.addWins(p, 1);
                if(p.hasPermission("skywars.coins.x5")){
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                }else if(p.hasPermission("skywars.coins.x4")){
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                }else if(p.hasPermission("skywars.coins.x3")){
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                }else if(p.hasPermission("skywars.coins.x2")){
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                }else{
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                }
                p.setAllowFlight(true);
                p.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
				new BukkitRunnable() {
					int tempo = 15;

					public void run() {
						if (tempo > 0 && tempo != 1) {
							firework(p);
						}
						if (tempo == 1) {
							firework(p);
						}
						if (tempo == 0) {
							firework(p);
							cancel();
						}
						--tempo;
					}
				}.runTaskTimer(Main.getPlugin(), 0, 20);
                
				  if(!SkyWars.invencible.contains(p)){
  					SkyWars.invencible.add(p);
  				}
				
                for(SkyPlayer ps : SkyWarsManager.getInstance().getSkyWars(p).getPlayers()){
  
                	
                	if(Main.is18()){
                		Title1_8 t2 = new Title1_8(Messages.getInstance().SKYWARS_PLAYERS_TITLE_WIN.replace("<player>", p.getName()), Messages.getInstance().SKYWARS_PLAYERS_SUBTITLE_WIN.replace("<player>", p.getName()));
                    	t2.send(ps.getPlayer());
                	}else{
                		Title1_11 t2 = new Title1_11(Messages.getInstance().SKYWARS_PLAYERS_TITLE_WIN.replace("<player>", p.getName()), Messages.getInstance().SKYWARS_PLAYERS_SUBTITLE_WIN.replace("<player>", p.getName()));
                    	t2.send(ps.getPlayer());
                	}
                	
                }
                
                if(Main.is18()){
                	Title1_8 t = new Title1_8(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                    
                    t.send(p);
                }else{
                    Title1_11 t = new Title1_11(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                    
                    t.send(p);
                }
               
                
                
                
                for(String list : Messages.getInstance().SKYWARS_REWARDS){
                	list = ChatColor.translateAlternateColorCodes('&', list);
                	p.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p))));
                }
                
                RewardSummary.getInstance().resetPlayer(p);
                RewardSummary.getInstance().resetPlayerSouls(p);
                ChatController.runCommand(p, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                             
                
                
                new BukkitRunnable() {
                    public void run() {
                        if (SkyWarsManager.getInstance().getSkyWars(p) != null && SkyWarsManager.getInstance().getSkyWars(p).getID().equals(SkyWars.this.ID)) {
                            p.setAllowFlight(false);
                        }
                        if(SkyWars.invencible.contains(p)){
        					SkyWars.invencible.remove(p);
        				}
                        SkyWars.this.reset();
                    }
                }.runTaskLater((Plugin)Main.getInstance(), 300L);
            }
            else {
                this.task.cancel();
                this.task = null;
                this.reset();
            }
        }
         if(this.getMode() != GameMode.MEGA){
        	 return;
         }
         
         if(alive.size() == 1){
        	 hasCheckedWin = true;
                 final Player p = alive.get(0).getPlayer();
                 this.task.cancel();
                 this.task = null;
                 Stats.addWins(p, 1);
                 if(p.hasPermission("skywars.coins.x5")){
                 	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                 	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                 }else if(p.hasPermission("skywars.coins.x4")){
                 	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                 	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                 }else if(p.hasPermission("skywars.coins.x3")){
                 	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                 	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                 }else if(p.hasPermission("skywars.coins.x2")){
                 	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                 	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                 }else{
                 	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                 	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                 }
                 
                
                 
                 
                 p.setAllowFlight(true);
   		        p.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
 				new BukkitRunnable() {
 					int tempo = 15;

 					public void run() {
 						if (tempo > 0 && tempo != 1) {
 							firework(p);
 						}
 						if (tempo == 1) {
 							firework(p);
 						}
 						if (tempo == 0) {
 							firework(p);
 							cancel();
 						}
 						--tempo;
 					}
 				}.runTaskTimer(Main.getPlugin(), 0, 20);
                 
 				if(!SkyWars.invencible.contains(p)){
 					SkyWars.invencible.add(p);
 				}

 				
                 
                 for(SkyPlayer ps : this.getPlayers()){
                 	for(String list : Messages.getInstance().SKYWARS_TEAM_PLAYERS_MESSAGE_WIN){
                 		list = ChatColor.translateAlternateColorCodes('&', list);
                 		ps.getPlayer().sendMessage(list.replace("<player>", p.getName()));
                 	}
                 	
                 
                 	
                 	if(Main.is18()){
                 		Title1_8 t2 = new Title1_8(Messages.getInstance().SKYWARS_MEGA_PLAYERS_TITLE_WIN);
                     	t2.send(ps.getPlayer());
                 	}else{
                 		Title1_11 t2 = new Title1_11(Messages.getInstance().SKYWARS_MEGA_PLAYERS_TITLE_WIN);
                     	t2.send(ps.getPlayer());
                 	}
                 	
                 }
                
                 
                 if(Main.is18()){
                 	Title1_8 t = new Title1_8(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                     t.send(p);
                 }else{
                 	Title1_11 t = new Title1_11(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                     t.send(p);
                 }
                     
                 
                 for(String list : Messages.getInstance().SKYWARS_REWARDS){
                 	list = ChatColor.translateAlternateColorCodes('&', list);
                 	p.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p))));
                 }
                 
                 RewardSummary.getInstance().resetPlayer(p);
                 RewardSummary.getInstance().resetPlayerSouls(p);
                
                 
                 ChatController.runCommand(p, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                 
                 
                 
                 new BukkitRunnable() {
                     public void run() {
                         if (SkyWarsManager.getInstance().getSkyWars(p) != null && SkyWarsManager.getInstance().getSkyWars(p).getID().equals(SkyWars.this.ID)) {
                             p.setAllowFlight(false);
                         }
                                                  
                         if(SkyWars.invencible.contains(p)){
         					SkyWars.invencible.remove(p);
         				}
         				
                         
                         SkyWars.this.reset();
                        
                     }
                 }.runTaskLater((Plugin)Main.getInstance(), 300L);
         }
         
         if (alive.size() == 3) {
         	hasCheckedWin = true;
             if (this.getIsland(alive.get(0).getPlayer()).hasPlayer(alive.get(1)) && this.getIsland(alive.get(0).getPlayer()).hasPlayer(alive.get(2))) {
                 final Player p = alive.get(0).getPlayer();
                 final Player p2 = alive.get(1).getPlayer();
                 final Player p3 = alive.get(2).getPlayer();
                 
                 this.task.cancel();
                 this.task = null;
                 Stats.addWins(p, 1);
                 Stats.addWins(p2, 1);
                 Stats.addWins(p3, 1);
                 if(p.hasPermission("skywars.coins.x5")){
                 	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                 	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                 }else if(p.hasPermission("skywars.coins.x4")){
                 	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                 	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                 }else if(p.hasPermission("skywars.coins.x3")){
                 	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                 	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                 }else if(p.hasPermission("skywars.coins.x2")){
                 	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                 	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                 }else{
                 	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                 	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                 }
                 
                 SkyPlayer pl2 = new SkyPlayer(p2);
                 if(p2.hasPermission("skywars.coins.x5")){
                 	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                 	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                 }else if(p2.hasPermission("skywars.coins.x4")){
                 	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                 	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                 }else if(p2.hasPermission("skywars.coins.x3")){
                 	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                 	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                 }else if(p2.hasPermission("skywars.coins.x2")){
                 	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                 	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                 }else{
                 	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win"));
                 	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win"));
                 }
                 
                 SkyPlayer pl3 = new SkyPlayer(p3);
                 if(p3.hasPermission("skywars.coins.x5")){
                 	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                 	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                 }else if(p3.hasPermission("skywars.coins.x4")){
                 	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                 	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                 }else if(p3.hasPermission("skywars.coins.x3")){
                 	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                 	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                 }else if(p3.hasPermission("skywars.coins.x2")){
                 	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                 	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                 }else{
                 	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win"));
                 	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win"));
                 }
                 
                 
                 p.setAllowFlight(true);
                 p2.setAllowFlight(true);
                 p3.setAllowFlight(true);
   		         p.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
                 p2.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
                 p3.getWorld().spawnEntity(p3.getLocation(), EntityType.FIREWORK);
 				new BukkitRunnable() {
 					int tempo = 15;

 					public void run() {
 						if (tempo > 0 && tempo != 1) {
 							firework(p);
 							firework(p2);
 							firework(p3);
 						}
 						if (tempo == 1) {
 							firework(p);
 							firework(p2);
 							firework(p3);
 						}
 						if (tempo == 0) {
 							firework(p);
 							firework(p2);
 							firework(p3);
 							cancel();
 						}
 						--tempo;
 					}
 				}.runTaskTimer(Main.getPlugin(), 0, 20);
                 
 				if(!SkyWars.invencible.contains(p)){
 					SkyWars.invencible.add(p);
 				}
 				if(!SkyWars.invencible.contains(p2)){
 					SkyWars.invencible.add(p2);
 				}
 				if(!SkyWars.invencible.contains(p3)){
 					SkyWars.invencible.add(p3);
 				}
 				
                 
                 for(SkyPlayer ps : this.getPlayers()){
                 	for(String list : Messages.getInstance().SKYWARS_3_PLAYERS_MESSAGE_WIN){
                 		list = ChatColor.translateAlternateColorCodes('&', list);
                 		ps.getPlayer().sendMessage(list.replace("<player>", p.getName()).replace("<player2>", p2.getName()).replace("<player3>", p3.getName()));
                 	}
                 	
                 
                 	
                 	if(Main.is18()){
                 		Title1_8 t2 = new Title1_8(Messages.getInstance().SKYWARS_MEGA_PLAYERS_TITLE_WIN);
                     	t2.send(ps.getPlayer());
                 	}else{
                 		Title1_11 t2 = new Title1_11(Messages.getInstance().SKYWARS_MEGA_PLAYERS_TITLE_WIN);
                     	t2.send(ps.getPlayer());
                 	}
                 	
                 }
                
                 
                 if(Main.is18()){
                 	Title1_8 t = new Title1_8(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                     t.send(p);
                     t.send(p2);
                     t.send(p3);
                 }else{
                 	Title1_11 t = new Title1_11(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                     t.send(p);
                     t.send(p2);
                     t.send(p3);
                 }
                     
                 
                 for(String list : Messages.getInstance().SKYWARS_REWARDS){
                 	list = ChatColor.translateAlternateColorCodes('&', list);
                 	p.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p))));
                 	p2.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p2))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p2))));
                 	p3.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p3))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p3))));
                 }
                 
                 RewardSummary.getInstance().resetPlayer(p);
                 RewardSummary.getInstance().resetPlayerSouls(p);
                 RewardSummary.getInstance().resetPlayer(p2);
                 RewardSummary.getInstance().resetPlayerSouls(p2);
                 RewardSummary.getInstance().resetPlayer(p3);
                 RewardSummary.getInstance().resetPlayerSouls(p3);
                 
                 ChatController.runCommand(p, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                 ChatController.runCommand(p2, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                 ChatController.runCommand(p3, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                 
                 
                 new BukkitRunnable() {
                     public void run() {
                         if (SkyWarsManager.getInstance().getSkyWars(p) != null && SkyWarsManager.getInstance().getSkyWars(p).getID().equals(SkyWars.this.ID)) {
                             p.setAllowFlight(false);
                         }
                         if (SkyWarsManager.getInstance().getSkyWars(p2) != null && SkyWarsManager.getInstance().getSkyWars(p2).getID().equals(SkyWars.this.ID)) {
                             p2.setAllowFlight(false);
                         }
                         if (SkyWarsManager.getInstance().getSkyWars(p3) != null && SkyWarsManager.getInstance().getSkyWars(p3).getID().equals(SkyWars.this.ID)) {
                             p3.setAllowFlight(false);
                         }
                         
                         if(SkyWars.invencible.contains(p)){
         					SkyWars.invencible.remove(p);
         				}
         				if(SkyWars.invencible.contains(p2)){
         					SkyWars.invencible.remove(p2);
         				}
         				if(SkyWars.invencible.contains(p3)){
         					SkyWars.invencible.remove(p3);
         				}
         				
                         
                         SkyWars.this.reset();
                        
                     }
                 }.runTaskLater((Plugin)Main.getInstance(), 300L);
             }
         }else if (alive.size() == 4) {
          	hasCheckedWin = true;
            if (this.getIsland(alive.get(0).getPlayer()).hasPlayer(alive.get(1)) && this.getIsland(alive.get(0).getPlayer()).hasPlayer(alive.get(2)) && this.getIsland(alive.get(0).getPlayer()).hasPlayer(alive.get(3))) {
                final Player p = alive.get(0).getPlayer();
                final Player p2 = alive.get(1).getPlayer();
                final Player p3 = alive.get(2).getPlayer();
                final Player p4 = alive.get(3).getPlayer();
                
                this.task.cancel();
                this.task = null;
                Stats.addWins(p, 1);
                Stats.addWins(p2, 1);
                Stats.addWins(p3, 1);
                Stats.addWins(p4, 1);
                if(p.hasPermission("skywars.coins.x5")){
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                }else if(p.hasPermission("skywars.coins.x4")){
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                }else if(p.hasPermission("skywars.coins.x3")){
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                }else if(p.hasPermission("skywars.coins.x2")){
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                }else{
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                }
                
                SkyPlayer pl2 = new SkyPlayer(p2);
                if(p2.hasPermission("skywars.coins.x5")){
                	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                }else if(p2.hasPermission("skywars.coins.x4")){
                	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                }else if(p2.hasPermission("skywars.coins.x3")){
                	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                }else if(p2.hasPermission("skywars.coins.x2")){
                	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                }else{
                	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win"));
                	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win"));
                }
                
                SkyPlayer pl3 = new SkyPlayer(p3);
                if(p3.hasPermission("skywars.coins.x5")){
                	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                }else if(p3.hasPermission("skywars.coins.x4")){
                	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                }else if(p3.hasPermission("skywars.coins.x3")){
                	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                }else if(p3.hasPermission("skywars.coins.x2")){
                	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                }else{
                	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win"));
                	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win"));
                }
                
                SkyPlayer pl4 = new SkyPlayer(p4);
                if(p4.hasPermission("skywars.coins.x5")){
                	Stats.addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                	RewardSummary.getInstance().addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                }else if(p4.hasPermission("skywars.coins.x4")){
                	Stats.addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                	RewardSummary.getInstance().addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                }else if(p4.hasPermission("skywars.coins.x3")){
                	Stats.addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                	RewardSummary.getInstance().addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                }else if(p4.hasPermission("skywars.coins.x2")){
                	Stats.addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                	RewardSummary.getInstance().addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                }else{
                	Stats.addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win"));
                	RewardSummary.getInstance().addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win"));
                }
                
                
                p.setAllowFlight(true);
                p2.setAllowFlight(true);
                p3.setAllowFlight(true);
                p4.setAllowFlight(true);
  		        p.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
                p2.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
                p3.getWorld().spawnEntity(p3.getLocation(), EntityType.FIREWORK);
                p4.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
				new BukkitRunnable() {
					int tempo = 15;

					public void run() {
						if (tempo > 0 && tempo != 1) {
							firework(p);
							firework(p2);
							firework(p3);
							firework(p4);
						}
						if (tempo == 1) {
							firework(p);
							firework(p2);
							firework(p3);
							firework(p4);
						}
						if (tempo == 0) {
							firework(p);
							firework(p2);
							firework(p3);
							firework(p4);
							cancel();
						}
						--tempo;
					}
				}.runTaskTimer(Main.getPlugin(), 0, 20);
                
				if(!SkyWars.invencible.contains(p)){
					SkyWars.invencible.add(p);
				}
				if(!SkyWars.invencible.contains(p2)){
					SkyWars.invencible.add(p2);
				}
				if(!SkyWars.invencible.contains(p3)){
					SkyWars.invencible.add(p3);
				}
				if(!SkyWars.invencible.contains(p4)){
					SkyWars.invencible.add(p4);
				}
				
                
                for(SkyPlayer ps : this.getPlayers()){
                	for(String list : Messages.getInstance().SKYWARS_4_PLAYERS_MESSAGE_WIN){
                		list = ChatColor.translateAlternateColorCodes('&', list);
                		ps.getPlayer().sendMessage(list.replace("<player>", p.getName()).replace("<player2>", p2.getName()).replace("<player3>", p3.getName()).replace("<player4>", p4.getName()));
                	}
                	
                
                	
                	if(Main.is18()){
                		Title1_8 t2 = new Title1_8(Messages.getInstance().SKYWARS_MEGA_PLAYERS_TITLE_WIN);
                    	t2.send(ps.getPlayer());
                	}else{
                		Title1_11 t2 = new Title1_11(Messages.getInstance().SKYWARS_MEGA_PLAYERS_TITLE_WIN);
                    	t2.send(ps.getPlayer());
                	}
                	
                }
               
                
                if(Main.is18()){
                	Title1_8 t = new Title1_8(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                    t.send(p);
                    t.send(p2);
                    t.send(p3);
                    t.send(p4);
                }else{
                	Title1_11 t = new Title1_11(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                    t.send(p);
                    t.send(p2);
                    t.send(p3);
                    t.send(p4);
                }
                    
                
                for(String list : Messages.getInstance().SKYWARS_REWARDS){
                	list = ChatColor.translateAlternateColorCodes('&', list);
                	p.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p))));
                	p2.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p2))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p2))));
                	p3.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p3))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p3))));
                	p4.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p4))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p4))));
                }
                
                RewardSummary.getInstance().resetPlayer(p);
                RewardSummary.getInstance().resetPlayerSouls(p);
                RewardSummary.getInstance().resetPlayer(p2);
                RewardSummary.getInstance().resetPlayerSouls(p2);
                RewardSummary.getInstance().resetPlayer(p3);
                RewardSummary.getInstance().resetPlayerSouls(p3);
                RewardSummary.getInstance().resetPlayer(p4);
                RewardSummary.getInstance().resetPlayerSouls(p4);
                
                ChatController.runCommand(p, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                ChatController.runCommand(p2, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                ChatController.runCommand(p3, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                ChatController.runCommand(p4, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                
                new BukkitRunnable() {
                    public void run() {
                        if (SkyWarsManager.getInstance().getSkyWars(p) != null && SkyWarsManager.getInstance().getSkyWars(p).getID().equals(SkyWars.this.ID)) {
                            p.setAllowFlight(false);
                        }
                        if (SkyWarsManager.getInstance().getSkyWars(p2) != null && SkyWarsManager.getInstance().getSkyWars(p2).getID().equals(SkyWars.this.ID)) {
                            p2.setAllowFlight(false);
                        }
                        if (SkyWarsManager.getInstance().getSkyWars(p3) != null && SkyWarsManager.getInstance().getSkyWars(p3).getID().equals(SkyWars.this.ID)) {
                            p3.setAllowFlight(false);
                        }
                        if (SkyWarsManager.getInstance().getSkyWars(p4) != null && SkyWarsManager.getInstance().getSkyWars(p4).getID().equals(SkyWars.this.ID)) {
                            p4.setAllowFlight(false);
                        }
                        
                        if(SkyWars.invencible.contains(p)){
        					SkyWars.invencible.remove(p);
        				}
        				if(SkyWars.invencible.contains(p2)){
        					SkyWars.invencible.remove(p2);
        				}
        				if(SkyWars.invencible.contains(p3)){
        					SkyWars.invencible.remove(p3);
        				}
        				if(SkyWars.invencible.contains(p4)){
        					SkyWars.invencible.remove(p4);
        				}
        				
                        
                        SkyWars.this.reset();
                       
                    }
                }.runTaskLater((Plugin)Main.getInstance(), 300L);
            }
        }else if (alive.size() == 5) {
          	hasCheckedWin = true;
          	if (this.getIsland(alive.get(0).getPlayer()).hasPlayer(alive.get(1)) && this.getIsland(alive.get(0).getPlayer()).hasPlayer(alive.get(2)) && this.getIsland(alive.get(0).getPlayer()).hasPlayer(alive.get(3)) && this.getIsland(alive.get(0).getPlayer()).hasPlayer(alive.get(4))) {
                final Player p = alive.get(0).getPlayer();
                final Player p2 = alive.get(1).getPlayer();
                final Player p3 = alive.get(2).getPlayer();
                final Player p4 = alive.get(3).getPlayer();
                final Player p5 = alive.get(4).getPlayer();
                
                this.task.cancel();
                this.task = null;
                Stats.addWins(p, 1);
                Stats.addWins(p2, 1);
                Stats.addWins(p3, 1);
                Stats.addWins(p4, 1);
                Stats.addWins(p5, 1);
                if(p.hasPermission("skywars.coins.x5")){
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                }else if(p.hasPermission("skywars.coins.x4")){
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                }else if(p.hasPermission("skywars.coins.x3")){
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                }else if(p.hasPermission("skywars.coins.x2")){
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                }else{
                	Stats.addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                	RewardSummary.getInstance().addCoins(p, Main.getInstance().getConfig().getInt("Settings.points.win"));
                }
                
                SkyPlayer pl2 = new SkyPlayer(p2);
                if(p2.hasPermission("skywars.coins.x5")){
                	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                }else if(p2.hasPermission("skywars.coins.x4")){
                	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                }else if(p2.hasPermission("skywars.coins.x3")){
                	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                }else if(p2.hasPermission("skywars.coins.x2")){
                	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                }else{
                	Stats.addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win"));
                	RewardSummary.getInstance().addCoins(p2, Main.getInstance().getConfig().getInt("Settings.points.win"));
                }
                
                SkyPlayer pl3 = new SkyPlayer(p3);
                if(p3.hasPermission("skywars.coins.x5")){
                	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                }else if(p3.hasPermission("skywars.coins.x4")){
                	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                }else if(p3.hasPermission("skywars.coins.x3")){
                	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                }else if(p3.hasPermission("skywars.coins.x2")){
                	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                }else{
                	Stats.addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win"));
                	RewardSummary.getInstance().addCoins(p3, Main.getInstance().getConfig().getInt("Settings.points.win"));
                }
                
                SkyPlayer pl4 = new SkyPlayer(p4);
                if(p4.hasPermission("skywars.coins.x5")){
                	Stats.addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                	RewardSummary.getInstance().addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                }else if(p4.hasPermission("skywars.coins.x4")){
                	Stats.addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                	RewardSummary.getInstance().addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                }else if(p4.hasPermission("skywars.coins.x3")){
                	Stats.addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                	RewardSummary.getInstance().addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                }else if(p4.hasPermission("skywars.coins.x2")){
                	Stats.addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                	RewardSummary.getInstance().addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                }else{
                	Stats.addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win"));
                	RewardSummary.getInstance().addCoins(p4, Main.getInstance().getConfig().getInt("Settings.points.win"));
                }
                
                SkyPlayer pl5 = new SkyPlayer(p4);
                if(p5.hasPermission("skywars.coins.x5")){
                	Stats.addCoins(p5, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                	RewardSummary.getInstance().addCoins(p5, Main.getInstance().getConfig().getInt("Settings.points.win") * 5);
                }else if(p5.hasPermission("skywars.coins.x4")){
                	Stats.addCoins(p5, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                	RewardSummary.getInstance().addCoins(p5, Main.getInstance().getConfig().getInt("Settings.points.win") * 4);
                }else if(p5.hasPermission("skywars.coins.x3")){
                	Stats.addCoins(p5, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                	RewardSummary.getInstance().addCoins(p5, Main.getInstance().getConfig().getInt("Settings.points.win") * 3);
                }else if(p5.hasPermission("skywars.coins.x2")){
                	Stats.addCoins(p5, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                	RewardSummary.getInstance().addCoins(p5, Main.getInstance().getConfig().getInt("Settings.points.win") * 2);
                }else{
                	Stats.addCoins(p5, Main.getInstance().getConfig().getInt("Settings.points.win"));
                	RewardSummary.getInstance().addCoins(p5, Main.getInstance().getConfig().getInt("Settings.points.win"));
                }
                
                
                p.setAllowFlight(true);
                p2.setAllowFlight(true);
                p3.setAllowFlight(true);
                p4.setAllowFlight(true);
                p5.setAllowFlight(true);
  		        p.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
                p2.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
                p3.getWorld().spawnEntity(p3.getLocation(), EntityType.FIREWORK);
                p4.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
                p5.getWorld().spawnEntity(p.getLocation(), EntityType.FIREWORK);
				new BukkitRunnable() {
					int tempo = 15;

					public void run() {
						if (tempo > 0 && tempo != 1) {
							firework(p);
							firework(p2);
							firework(p3);
							firework(p4);
							firework(p5);
						}
						if (tempo == 1) {
							firework(p);
							firework(p2);
							firework(p3);
							firework(p4);
							firework(p5);
						}
						if (tempo == 0) {
							firework(p);
							firework(p2);
							firework(p3);
							firework(p4);
							firework(p5);
							cancel();
						}
						--tempo;
					}
				}.runTaskTimer(Main.getPlugin(), 0, 20);
                
				if(!SkyWars.invencible.contains(p)){
					SkyWars.invencible.add(p);
				}
				if(!SkyWars.invencible.contains(p2)){
					SkyWars.invencible.add(p2);
				}
				if(!SkyWars.invencible.contains(p3)){
					SkyWars.invencible.add(p3);
				}
				if(!SkyWars.invencible.contains(p4)){
					SkyWars.invencible.add(p4);
				}
				if(!SkyWars.invencible.contains(p5)){
					SkyWars.invencible.add(p5);
				}
                
                for(SkyPlayer ps : this.getPlayers()){
                	for(String list : Messages.getInstance().SKYWARS_5_PLAYERS_MESSAGE_WIN){
                		list = ChatColor.translateAlternateColorCodes('&', list);
                		ps.getPlayer().sendMessage(list.replace("<player>", p.getName()).replace("<player2>", p2.getName()).replace("<player3>", p3.getName()).replace("<player4>", p4.getName()).replace("<player5>", p5.getName()));
                	}
                	
                
                	
                	if(Main.is18()){
                		Title1_8 t2 = new Title1_8(Messages.getInstance().SKYWARS_MEGA_PLAYERS_TITLE_WIN);
                    	t2.send(ps.getPlayer());
                	}else{
                		Title1_11 t2 = new Title1_11(Messages.getInstance().SKYWARS_MEGA_PLAYERS_TITLE_WIN);
                    	t2.send(ps.getPlayer());
                	}
                	
                }
               
                
                if(Main.is18()){
                	Title1_8 t = new Title1_8(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                    t.send(p);
                    t.send(p2);
                    t.send(p3);
                    t.send(p4);
                    t.send(p5);
                }else{
                	Title1_11 t = new Title1_11(Messages.getInstance().SKYWARS_PLAYER_WIN_TITLE, Messages.getInstance().SKYWARS_PLAYER_WIN_SUBTITLE);
                    t.send(p);
                    t.send(p2);
                    t.send(p3);
                    t.send(p4);
                    t.send(p5);
                }
                    
                
                for(String list : Messages.getInstance().SKYWARS_REWARDS){
                	list = ChatColor.translateAlternateColorCodes('&', list);
                	p.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p))));
                	p2.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p2))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p2))));
                	p3.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p3))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p3))));
                	p4.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p4))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p4))));
                	p5.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p5))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p5))));
                }
                
                RewardSummary.getInstance().resetPlayer(p);
                RewardSummary.getInstance().resetPlayerSouls(p);
                RewardSummary.getInstance().resetPlayer(p2);
                RewardSummary.getInstance().resetPlayerSouls(p2);
                RewardSummary.getInstance().resetPlayer(p3);
                RewardSummary.getInstance().resetPlayerSouls(p3);
                RewardSummary.getInstance().resetPlayer(p4);
                RewardSummary.getInstance().resetPlayerSouls(p4);
                RewardSummary.getInstance().resetPlayer(p5);
                RewardSummary.getInstance().resetPlayerSouls(p5);
                
                ChatController.runCommand(p, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                ChatController.runCommand(p2, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                ChatController.runCommand(p3, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                ChatController.runCommand(p4, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                ChatController.runCommand(p5, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
                
                new BukkitRunnable() {
                    public void run() {
                        if (SkyWarsManager.getInstance().getSkyWars(p) != null && SkyWarsManager.getInstance().getSkyWars(p).getID().equals(SkyWars.this.ID)) {
                            p.setAllowFlight(false);
                        }
                        if (SkyWarsManager.getInstance().getSkyWars(p2) != null && SkyWarsManager.getInstance().getSkyWars(p2).getID().equals(SkyWars.this.ID)) {
                            p2.setAllowFlight(false);
                        }
                        if (SkyWarsManager.getInstance().getSkyWars(p3) != null && SkyWarsManager.getInstance().getSkyWars(p3).getID().equals(SkyWars.this.ID)) {
                            p3.setAllowFlight(false);
                        }
                        if (SkyWarsManager.getInstance().getSkyWars(p4) != null && SkyWarsManager.getInstance().getSkyWars(p4).getID().equals(SkyWars.this.ID)) {
                            p4.setAllowFlight(false);
                        }
                        if (SkyWarsManager.getInstance().getSkyWars(p5) != null && SkyWarsManager.getInstance().getSkyWars(p5).getID().equals(SkyWars.this.ID)) {
                            p5.setAllowFlight(false);
                        }
                        
                        if(SkyWars.invencible.contains(p)){
        					SkyWars.invencible.remove(p);
        				}
        				if(SkyWars.invencible.contains(p2)){
        					SkyWars.invencible.remove(p2);
        				}
        				if(SkyWars.invencible.contains(p3)){
        					SkyWars.invencible.remove(p3);
        				}
        				if(SkyWars.invencible.contains(p4)){
        					SkyWars.invencible.remove(p4);
        				}
        				if(SkyWars.invencible.contains(p5)){
        					SkyWars.invencible.remove(p5);
        				}
        				
                        
                        SkyWars.this.reset();
                       
                    }
                }.runTaskLater((Plugin)Main.getInstance(), 300L);
            }
        }
         
    }
    
    
    public void firework(Player p) {
        Location loc = p.getLocation();
        final Firework f = (Firework)loc.getWorld().spawnEntity(loc, EntityType.FIREWORK);
        FireworkMeta fm = f.getFireworkMeta();
        FireworkEffect.Type t = FireworkEffect.Type.BALL_LARGE;
        Color c1 = Color.ORANGE;
        Color c2 = Color.GREEN;
        Color c3 = Color.RED;
        FireworkEffect effect = FireworkEffect.builder().flicker(new Random().nextBoolean()).withColor(c1).withColor(c2).withFade(c3).with(t).trail(new Random().nextBoolean()).build();
        fm.addEffect(effect);
        fm.setPower(0);
        f.setFireworkMeta(fm);
        new BukkitRunnable() {
			
			@Override
			public void run() {
				 f.detonate();
				
			}
		}.runTaskLater(Main.getPlugin(), 4);
    }
    
    
    public void addCage(Location loc,boolean team){
    	  Location loc2=loc;
    	  loc=new Location(loc2.getWorld(),loc2.getX(),loc2.getY(),loc2.getZ());
    	  if(!team){
    	   loc.add(0,-1,0).getBlock().setType(Material.GLASS);
    	   for(int i=1;i<4;i++){
    	    loc.add(0,1,0);
    	    Location[] locs={loc.clone().add(1,0,0),loc.clone().add(-1,0,0),loc.clone().add(0,0,1),loc.clone().add(0,0,-1)};
    	    for(Location location:locs)
    	     location.getBlock().setType(Material.GLASS);
    	   }
    	   loc.add(0,1,0).getBlock().setType(Material.GLASS);
    	  }else{
    	   loc.add(0,-1,0);
    	   Location[] downs={loc,loc.clone().add(1,0,0),loc.clone().add(-1,0,0),loc.clone().add(0,0,1),loc.clone().add(0,0,-1),loc.clone().add(1,0,1),loc.clone().add(-1,0,1),loc.clone().add(1,0,-1),loc.clone().add(-1,0,-1)};
    	   for(Location down:downs)
    	    down.getBlock().setType(Material.GLASS);
    	   for(int i=1;i<4;i++){
    	    loc.add(0,1,0);
    	    Location[] uppers={loc.clone().add(2,0,0),loc.clone().add(-2,0,0),loc.clone().add(0,0,2),loc.clone().add(0,0,-2),loc.clone().add(2,0,1),loc.clone().add(2,0,-1),loc.clone().add(-2,0,1),loc.clone().add(-2,0,-1),loc.clone().add(1,0,2),loc.clone().add(-1,0,-2),loc.clone().add(1,0,-2),loc.clone().add(-1,0,2)};
    	    for(Location upper:uppers)
    	     upper.getBlock().setType(Material.GLASS);
    	   }
    	   loc.add(0,1,0);
    	   downs=new Location[]{loc,loc.clone().add(1,0,0),loc.clone().add(-1,0,0),loc.clone().add(0,0,1),loc.clone().add(0,0,-1),loc.clone().add(1,0,1),loc.clone().add(-1,0,1),loc.clone().add(1,0,-1),loc.clone().add(-1,0,-1)};
    	   for(Location down:downs)
    	    down.getBlock().setType(Material.GLASS);
    	  }
    	 }
   
    
    private void reset() {
        SkyPlayer[] players;
        for (int length = (players = this.getPlayers()).length, i = 0; i < length; ++i) {
            final SkyPlayer p = players[i];
            this.removePlayerSilent(p.getPlayer());
        }
        this.countdown = null;
        this.players.clear();
        this.state = GameState.RESET;
        this.refilltime = 270;
        this.deathMatch = false;
        this.hasCheckedWin = false;
        this.time = 900;
        this.rollback();
    }
    
    public void addSpawn(final Location location) {
        this.spawns.add(new SkyWarsSpawn(location, this.getMode()));
    }
    
    public void rollback() {
        for (final Player ps : Bukkit.getWorld(this.ID).getPlayers()) {
            ps.kickPlayer("§cMap Reseting Wait...");
        }
        SkyWarsManager.getInstance().getSkyWars().remove(this);
        Bukkit.unloadWorld(this.ID, false);
        new BukkitRunnable() {
            public void run() {
                final File world = new File(SkyWars.this.ID);
                final File newWorld = new File("plugins/NeoSkyWars/mapas/" + SkyWars.this.ID);
                SkyWarsManager.getInstance().deleteFolder(world);
                try {
                    SkyWarsManager.getInstance().copyDir(newWorld, world);
                }
                catch (Exception e) {
                    Main.getInstance().consoleSender.sendMessage("§cFailed to copy the world of arena: " + SkyWars.this.ID);
                    e.printStackTrace();
                }
                new BukkitRunnable() {
                    public void run() {
                        final WorldCreator wc = new WorldCreator(SkyWars.this.ID);
                        wc.generateStructures(false);
                        final World map = wc.createWorld();
                        map.setAutoSave(false);
                        map.setKeepSpawnInMemory(false);
                        map.setGameRuleValue("doMobSpawning", "false");
                        map.setGameRuleValue("doDaylightCycle", "false");
                        map.setGameRuleValue("mobGriefing", "false");
                        map.setTime(0L);
                        new BukkitRunnable() {
                            public void run() {
                                SkyWars.access$2(SkyWars.this, GameState.WAITING);
                                SkyWarsManager.getInstance().getSkyWars().add(SkyWars.this);
                            }
                        }.runTaskLater((Plugin)Main.getInstance(), 25L);
                    }
                }.runTaskLater((Plugin)Main.getInstance(), 20L);
            }
        }.runTaskLater((Plugin)Main.getInstance(), 20L);
        Bukkit.getConsoleSender().sendMessage("§eArena: §a" + this.ID + " §eWill Reseted");
    }
    
    public void startCount() {
        this.countdown.start();
    }
    
    public void gameCount() {
        this.task = new BukkitRunnable() {
            public void run() {
                if (!SkyWars.this.deathMatch) {
                    if (SkyWars.this.refilltime == 0) {
                    	//Feast Chests
                        if (SkyWars.this.config.contains("feastchests")) {
                            for (final String chestID : SkyWars.this.config.get("feastchests").getKeys(false)) {
                                final Location loc = SkyWars.this.config.loadLocation(SkyWars.this.config.get("feastchests." + chestID + ".location"));
                                if (loc.getBlock() != null && loc.getBlock().getState() instanceof Chest) {
                                	if(SkyWars.this.getMode() == GameMode.MEGA){
                                   	 SkyWars.this.fillChestsMega((Chest)loc.getBlock().getState(), true, true);
                                    }else{
                                   	 SkyWars.this.fillChests((Chest)loc.getBlock().getState(), true, true);
                                    }
                                    for(SkyPlayer ps : SkyWars.this.getPlayers()){
                                    	
                                    		
                                    		if(Main.is18()){
                                    			Title1_8 t = new Title1_8("", Messages.getInstance().SKYWARS_SUBTITLE_CHEST_REFILLED);
                                    			t.send(ps.getPlayer());
                                    		}else{
                                    			Title1_11 t = new Title1_11("", Messages.getInstance().SKYWARS_SUBTITLE_CHEST_REFILLED);
                                    			t.send(ps.getPlayer());
                                    		}
                                    		
                                    		ps.getPlayer().playSound(ps.getPlayer().getLocation(), Main.CHEST_OPEN, 1.0F, 1.0F);
                                    	
                                    	
                                    }
                                }
                              
                            }
                        }//Feast Chests //Normal Chests
                        if (SkyWars.this.config.contains("chests")) {
                            for (final String chestID : SkyWars.this.config.get("chests").getKeys(false)) {
                                final Location loc = SkyWars.this.config.loadLocation(SkyWars.this.config.get("chests." + chestID + ".location"));
                                if (loc.getBlock() != null && loc.getBlock().getState() instanceof Chest) {
                                	if(SkyWars.this.getMode() == GameMode.MEGA){
                                   	 SkyWars.this.fillChestsMega((Chest)loc.getBlock().getState(), true, false);
                                    }else{
                                   	 SkyWars.this.fillChests((Chest)loc.getBlock().getState(), true, false);
                                    }
                                    for(SkyPlayer ps : SkyWars.this.getPlayers()){
                                    	
                                    		
                                    		if(Main.is18()){
                                    			Title1_8 t = new Title1_8("", Messages.getInstance().SKYWARS_SUBTITLE_CHEST_REFILLED);
                                    			t.send(ps.getPlayer());
                                    		}else{
                                    			Title1_11 t = new Title1_11("", Messages.getInstance().SKYWARS_SUBTITLE_CHEST_REFILLED);
                                    			t.send(ps.getPlayer());
                                    		}
                                    		
                                    		ps.getPlayer().playSound(ps.getPlayer().getLocation(), Main.CHEST_OPEN, 1.0F, 1.0F);
                                    	
                                    	
                                    }
                                }
                              
                            }
                        }//Normal Chests
                        SkyWars.access$6(SkyWars.this, 150);
                    }
                    if (SkyWars.this.time <= 0 && !SkyWars.this.deathMatch) {
                        SkyWars.access$8(SkyWars.this, 300);
                        
                        for(SkyPlayer ps : SkyWars.this.getPlayers()){
                        	
                        	for(String list : Messages.getInstance().SKYWARS_PLAYER_DEATHMATCH){
                        		list = ChatColor.translateAlternateColorCodes('&', list);
                        		ps.getPlayer().sendMessage(list);
                        	}
                        	ps.getPlayer().teleport(SkyWars.this.dmLocation);
                        }
                        return;
                    }
                    final SkyWars this$0 = SkyWars.this;
                    SkyWars.access$6(this$0, this$0.refilltime - 1);
                }
                else {
                    if (SkyWars.this.state == GameState.STARTED && SkyWars.this.players.size() == 0) {
                        SkyWars.this.players.clear();
                        SkyWars.access$2(SkyWars.this, GameState.WAITING);
                        SkyWars.this.rollback();
                        SkyWars.this.startCount();
                        this.cancel();
                        return;
                    }
                    if (SkyWars.this.time == 0) {
                        if (SkyWars.this.players.size() == 0) {
                            SkyWars.this.task.cancel();
                            SkyWars.access$12(SkyWars.this, null);
                            SkyPlayer[] players;
                            for (int length = (players = SkyWars.this.getPlayers()).length, i = 0; i < length; ++i) {
                                final SkyPlayer p = players[i];
                                SkyWars.this.removePlayerSilent(p.getPlayer());
                            }
                            SkyWars.this.players.clear();
                            SkyWars.access$2(SkyWars.this, GameState.WAITING);
                            SkyWars.access$6(SkyWars.this, 300);
                            SkyWars.access$13(SkyWars.this, false);
                            SkyWars.access$8(SkyWars.this, 900);
                            SkyWars.this.rollback();
                            if (SkyWars.this.config.contains("chests")) {
                                for (final String chestID : SkyWars.this.config.get("chests").getKeys(false)) {
                                    final Location loc = SkyWars.this.config.loadLocation(SkyWars.this.config.get("chests." + chestID + ".location"));
                                    if (loc.getBlock() != null && loc.getBlock().getState() instanceof Chest) {
                                        final Chest chest = (Chest)loc.getBlock().getState();
                                        chest.getInventory().clear();
                                        chest.update();
                                    }
                                }
                            }
                            if (SkyWars.this.config.contains("feastchests")) {
                                for (final String chestID : SkyWars.this.config.get("feastchests").getKeys(false)) {
                                    final Location loc = SkyWars.this.config.loadLocation(SkyWars.this.config.get("feastchests." + chestID + ".location"));
                                    if (loc.getBlock() != null && loc.getBlock().getState() instanceof Chest) {
                                        final Chest chest = (Chest)loc.getBlock().getState();
                                        chest.getInventory().clear();
                                        chest.update();
                                    }
                                }
                            }
                            for (final Entity e : Bukkit.getWorld(SkyWars.this.getBounds().getWorld().getName()).getEntities()) {
                                if (SkyWars.this.getBounds().hasBlockInside(e.getLocation().getBlock()) && e.getType() == EntityType.DROPPED_ITEM) {
                                    e.remove();
                                }
                            }
                        }
                        else if (SkyWars.this.players.size() == 1) {
                            SkyWars.this.checkWin();
                        }
                    }
                }
                final SkyWars this$2 = SkyWars.this;
                SkyWars.access$8(this$2, this$2.time - 1);
            }
        }.runTaskTimer((Plugin)Main.getInstance(), 0L, 20L);
    }
    
    public void start() {
        this.state = GameState.STARTED;
        if (this.countdown != null) {
            this.countdown.cancel();
        }
         try{
             if (this.config.contains("chests")) {
                 for (final String chestID : this.config.get("chests").getKeys(false)) {
                     final Location loc = this.config.loadLocation(this.config.get("chests." + chestID + ".location"));
                     if (loc.getBlock() != null && loc.getBlock().getState() instanceof Chest) {
                         if(this.getMode() == GameMode.MEGA){
                        	 this.fillChestsMega((Chest)loc.getBlock().getState(), false, false);
                         }else{
                        	 this.fillChests((Chest)loc.getBlock().getState(), false, false);
                         }
                     }
                 }
             }
             if (this.config.contains("feastchests")) {
                 for (final String chestID : this.config.get("feastchests").getKeys(false)) {
                     final Location loc = this.config.loadLocation(this.config.get("feastchests." + chestID + ".location"));
                     if (loc.getBlock() != null && loc.getBlock().getState() instanceof Chest) {
                    	 if(this.getMode() == GameMode.MEGA){
                        	 this.fillChestsMega((Chest)loc.getBlock().getState(), false, true);
                         }else{
                        	 this.fillChests((Chest)loc.getBlock().getState(), false, true);
                         }
                     }
                 }
             }
         }catch(Exception e){
        	 //Empty Block
         }
         
        SkyPlayer[] players;
        for (int length = (players = this.getPlayers()).length, i = 0; i < length; ++i) {
            final SkyPlayer p = players[i];
            p.getPlayer().getInventory().clear();
            
            p.getPlayer().getInventory().setArmorContents((ItemStack[])null);
            if (KitController.getData().get(p.getPlayer()) != null) {
                KitController.getData().get(p.getPlayer()).giveKit(p.getPlayer());
            }
            p.getPlayer().updateInventory();
            p.getPlayer().closeInventory();
            p.getPlayer().setHealth(20.0);
            p.getPlayer().setFoodLevel(20);
            if (p.getPlayer().getGameMode() != org.bukkit.GameMode.SURVIVAL) {
                p.getPlayer().setGameMode(org.bukkit.GameMode.SURVIVAL);
            }
            
            if(ScoreboardManager.getScoreboard(p.getPlayer()) != null){
            	ScoreboardManager.removeScoreboard(ScoreboardManager.getScoreboard(p.getPlayer()));
            }
            
            ScoreboardManager.iniciarScoreboardSkywars(p.getPlayer(), this);
            invencible.add(p.getPlayer());
            new BukkitRunnable() {
				
				@Override
				public void run() {
					invencible.remove(p.getPlayer());
					
				}
			}.runTaskLater(Main.getPlugin(), 20*4);
        }
        SkyWarsSpawn[] spawns;
        for (int length2 = (spawns = this.getSpawns()).length, j = 0; j < length2; ++j) {
            final SkyWarsSpawn spawn = spawns[j];
            if (this.mode.equals(GameMode.TEAM)) {
                this.removeFrom(spawn.getLocation(), 6.0);
            }else if (this.mode.equals(GameMode.MEGA)) {
                this.removeFrom(spawn.getLocation(), 6.0);
            }
            else {
                this.removeFrom(spawn.getLocation(), 3.0);
            }
        }

        this.gameCount();
        this.checkWin();
    }
    
    public void startArena() {
        if (this.dmLocation != null) {
            this.deathMatch = true;
            SkyPlayer[] players2;
            for (int length = (players2 = this.getPlayers()).length, i = 0; i < length; ++i) {
                final SkyPlayer players = players2[i];
                players.getPlayer().teleport(this.dmLocation);
            }
        }
    }
    
    public void addKills(final Player p) {
        this.getPlayer(p).addKills();
    }
    
    public void setState(final GameState state) {
        this.state = state;
    }
    
    public void setArena(final Location location) {
        this.dmLocation = location;
    }
    
    public void fillChests(final Chest chest, final boolean isRefill, final boolean isfeast) {
        List<String> items = new ArrayList<String>();
        if(!isfeast){
        	if (this.getChestType().equals(ChestType.NORMAL)) {
                if (isRefill) {
                    items = (List<String>)Main.chests.getConfig().getStringList("chests.normal.island.refill");
                }
                else {
                    items = (List<String>)Main.chests.getConfig().getStringList("chests.normal.island.basic");
                }
            }
            else if (isRefill) {
                items = (List<String>)Main.chests.getConfig().getStringList("chests.insane.island.refill");
            }
            else {
                items = (List<String>)Main.chests.getConfig().getStringList("chests.insane.island.basic");
            }
        }else if(isfeast){
        	if (this.getChestType().equals(ChestType.NORMAL)) {
                if (isRefill) {
                    items = (List<String>)Main.chests.getConfig().getStringList("chests.normal.feast.refill");
                }
                else {
                    items = (List<String>)Main.chests.getConfig().getStringList("chests.normal.feast.basic");
                }
            }
            else if (isRefill) {
                items = (List<String>)Main.chests.getConfig().getStringList("chests.insane.feast.refill");
            }
            else {
                items = (List<String>)Main.chests.getConfig().getStringList("chests.insane.feast.basic");
            }
        }
        int index=0;
        List<Integer> slots=new ArrayList<>();
        for(int i=0;i<27;i++)
             slots.add(i);
        Collections.shuffle(slots);
        for (final String spliter : items) {
            final String[] split = spliter.split(" ");
            final Random random = new Random();
            final int amount = Integer.valueOf(split[2]);
            int durability = 9999;
            Material material = null;
            if (split[1].contains(";")) {
                try {
                    durability = Integer.valueOf(split[1].split(";")[1]);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            else {
                try {
                    material = Material.matchMaterial(split[1].toUpperCase());
                }
                catch (Exception e) {
                    material = Material.getMaterial((int)Integer.valueOf(split[1]));
                }
            }
            if (material == null) {
                continue;
            }
            final ItemStack item = new ItemStack(material, amount);
            if (durability != 9999) {
                item.setDurability((short)durability);
            }
            if (split.length > 3) {
                final String enchName = split[3].split(";")[0];
                final int level = Integer.valueOf(split[3].split(";")[1]);
                try {
                    item.addUnsafeEnchantment(getEnchant(enchName), level);
                }
                catch (Exception e2) {
                    try {
                        item.addUnsafeEnchantment(Enchantment.getById((int)Integer.valueOf(enchName)), level);
                    }
                    catch (Exception ex2) {
                        ex2.printStackTrace();
                    }
                }
            }
            if (random.nextInt(100) <= Integer.valueOf(split[0])) {
                chest.getInventory().setItem(slots.get(index++), item);
            }
            chest.update();
        }
    }
    
    public void fillChestsMega(final Chest chest, final boolean isRefill, final boolean isfeast) {
        List<String> items = new ArrayList<String>();
        if(!isfeast){
        	if (this.getChestType().equals(ChestType.MEGA)) {
                if (isRefill) {
                    items = (List<String>)Main.chests.getConfig().getStringList("chests.mega.island.refill");
                }
                else {
                    items = (List<String>)Main.chests.getConfig().getStringList("chests.mega.island.basic");
                }
            }
            else if (isRefill) {
                items = (List<String>)Main.chests.getConfig().getStringList("chests.mega.island.refill");
            }
            else {
                items = (List<String>)Main.chests.getConfig().getStringList("chests.mega.island.basic");
            }
        }else if(isfeast){
        	if (this.getChestType().equals(ChestType.MEGA)) {
                if (isRefill) {
                    items = (List<String>)Main.chests.getConfig().getStringList("chests.mega.feast.refill");
                }
                else {
                    items = (List<String>)Main.chests.getConfig().getStringList("chests.mega.feast.basic");
                }
            }
            else if (isRefill) {
                items = (List<String>)Main.chests.getConfig().getStringList("chests.mega.feast.refill");
            }
            else {
                items = (List<String>)Main.chests.getConfig().getStringList("chests.mega.feast.basic");
            }
        }
        int index=0;
        List<Integer> slots=new ArrayList<>();
        for(int i=0;i<27;i++)
             slots.add(i);
        Collections.shuffle(slots);
        for (final String spliter : items) {
            final String[] split = spliter.split(" ");
            final Random random = new Random();
            final int amount = Integer.valueOf(split[2]);
            int durability = 9999;
            Material material = null;
            if (split[1].contains(";")) {
                try {
                    durability = Integer.valueOf(split[1].split(";")[1]);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            else {
                try {
                    material = Material.matchMaterial(split[1].toUpperCase());
                }
                catch (Exception e) {
                    material = Material.getMaterial((int)Integer.valueOf(split[1]));
                }
            }
            if (material == null) {
                continue;
            }
            final ItemStack item = new ItemStack(material, amount);
            if (durability != 9999) {
                item.setDurability((short)durability);
            }
            if (split.length > 3) {
                final String enchName = split[3].split(";")[0];
                final int level = Integer.valueOf(split[3].split(";")[1]);
                try {
                    item.addUnsafeEnchantment(getEnchant(enchName), level);
                }
                catch (Exception e2) {
                    try {
                        item.addUnsafeEnchantment(Enchantment.getById((int)Integer.valueOf(enchName)), level);
                    }
                    catch (Exception ex2) {
                        ex2.printStackTrace();
                    }
                }
            }
            if (random.nextInt(100) <= Integer.valueOf(split[0])) {
                chest.getInventory().setItem(slots.get(index++), item);
            }
            chest.update();
        }
    }
    
    public static Enchantment getEnchant(final String enchantment) {
        final String data = enchantment.toLowerCase();
        if (data.equals("sharpness")) {
            return Enchantment.DAMAGE_ALL;
        }
        if (data.equals("projectileprotection")) {
            return Enchantment.PROTECTION_PROJECTILE;
        }
        if (data.equals("fireprotection")) {
            return Enchantment.PROTECTION_FIRE;
        }
        if (data.equals("featherfall")) {
            return Enchantment.PROTECTION_FALL;
        }
        if (data.equals("blastprotection")) {
            return Enchantment.PROTECTION_EXPLOSIONS;
        }
        if (data.equals("respiration")) {
            return Enchantment.OXYGEN;
        }
        if (data.equals("aquaaffinity")) {
            return Enchantment.WATER_WORKER;
        }
        if (data.equals("protection")) {
            return Enchantment.PROTECTION_ENVIRONMENTAL;
        }
        if (data.equals("smite")) {
            return Enchantment.DAMAGE_UNDEAD;
        }
        if (data.equals("baneofarthropods")) {
            return Enchantment.DAMAGE_ARTHROPODS;
        }
        if (data.equals("knockback")) {
            return Enchantment.KNOCKBACK;
        }
        if (data.equals("fireaspect")) {
            return Enchantment.FIRE_ASPECT;
        }
        if (data.equals("looting")) {
            return Enchantment.LOOT_BONUS_MOBS;
        }
        if (data.equals("power")) {
            return Enchantment.ARROW_DAMAGE;
        }
        if (data.equals("punch")) {
            return Enchantment.ARROW_KNOCKBACK;
        }
        if (data.equals("flame")) {
            return Enchantment.ARROW_FIRE;
        }
        if (data.equals("infinity")) {
            return Enchantment.ARROW_INFINITE;
        }
        if (data.equals("efficiency")) {
            return Enchantment.DIG_SPEED;
        }
        if (data.equals("silktouch")) {
            return Enchantment.SILK_TOUCH;
        }
        if (data.equals("unbreaking")) {
            return Enchantment.DURABILITY;
        }
        if (data.equals("fortune")) {
            return Enchantment.LOOT_BONUS_BLOCKS;
        }
        if (data.equals("luckofthesea")) {
            return Enchantment.LUCK;
        }
        if (data.equals("luck")) {
            return Enchantment.LUCK;
        }
        if (data.equals("lure")) {
            return Enchantment.LURE;
        }
        if (data.equals("thorns")) {
            return Enchantment.THORNS;
        }
        return null;
    }
    
    public void removeFrom(final Location l, final double radius) {
        for (double x = -radius; x <= radius; ++x) {
            for (double y = -radius; y <= radius; ++y) {
                for (double z = -radius; z <= radius; ++z) {
                    final Location l2 = new Location(l.getWorld(), l.getX() + x, l.getY() + y, l.getZ() + z);
                    if (l2.getBlock().getType() == Material.getMaterial(95) || l2.getBlock().getType() == Material.GLASS) {
                        l2.getBlock().setType(Material.AIR);
                    }
                }
            }
        }
    }
    
    public SettingsManager getConfig() {
        return this.config;
    }
    
    public String getID() {
        return this.ID;
    }
    
    public CuboID getBounds() {
        return this.bounds;
    }
    
    public int getMaxPlayers() {
        if (this.mode.equals(GameMode.SOLO)) {
            return this.spawns.size();
        }else if(this.mode.equals(GameMode.MEGA)){
        	return this.spawns.size() * 5;
        }
        return this.spawns.size() * 2;
    }
    
    public BukkitTask getTask() {
        return this.task;
    }
    
    public TimerManager getCountdown() {
        return this.countdown;
    }
    
    public int getRefill() {
        return this.refilltime;
    }
    
    public int getTime() {
        return this.time;
    }
    
    public int getKills(final Player p) {
        if (this.getPlayer(p) == null) {
            return 0;
        }
        return this.getPlayer(p).getKills();
    }
    
    public GameState getState() {
        return this.state;
    }
    
    public GameMode getMode() {
        return this.mode;
    }
    
    public ChestType getChestType() {
        return this.chestType;
    }
    
    public SkyWarsSpawn getIsland(final Player p) {
        SkyWarsSpawn[] spawns;
        for (int length = (spawns = this.getSpawns()).length, i = 0; i < length; ++i) {
            final SkyWarsSpawn spawn = spawns[i];
            if (spawn.getPlayers().length > 0 && spawn.hasPlayer(this.getPlayer(p))) {
                return spawn;
            }
        }
        return null;
    }
    
	    
    
    public Location getDeathMatch() {
        return this.dmLocation;
    }
    
    public SkyWarsSpawn[] getSpawns() {
        return this.spawns.toArray(new SkyWarsSpawn[this.spawns.size()]);
    }
    
    public SkyPlayer[] getPlayers() {
        return this.players.toArray(new SkyPlayer[this.players.size()]);
    }
    
    public SkyPlayer getPlayer(final Player p) {
        SkyPlayer[] players;
        for (int length = (players = this.getPlayers()).length, i = 0; i < length; ++i) {
            final SkyPlayer a = players[i];
            if (a.getPlayer().equals(p)) {
                return a;
            }
        }
        return null;
    }
    
    public boolean hasPlayer(final Player p) {
        return this.getPlayer(p) != null;
    }
    
    static void access$2(final SkyWars skywars, final GameState state) {
        skywars.state = state;
    }
    
    static void access$6(final SkyWars skywars, final int refilltime) {
        skywars.refilltime = refilltime;
    }
    
    static void access$8(final SkyWars skywars, final int time) {
        skywars.time = time;
    }
    
    static void access$12(final SkyWars skywars, final BukkitTask task) {
        skywars.task = task;
    }
    
    static void access$13(final SkyWars skywars, final boolean deathMatch) {
        skywars.deathMatch = deathMatch;
    }
    
    public enum ChestType
    {
        NORMAL("NORMAL", 0), 
        INSANE("INSANE", 1),
        MEGA("MEGA", 2);
        
        private ChestType(final String s, final int n) {
        }
    }
    
    public enum GameMode
    {
        SOLO("SOLO", 0), 
        TEAM("TEAM", 1),
        MEGA("MEGA", 2);
        
        private GameMode(final String s, final int n) {
        }
    }
    
    public enum GameState
    {
        WAITING("WAITING", 0), 
        STARTED("STARTED", 1), 
        RESET("RESET", 2);
        
        private GameState(final String s, final int n) {
        }
    }
}
