package net.iz44kpvp.neoskywars.skywars;

import java.util.HashMap;

import org.bukkit.entity.Player;

public class RewardSummary {
	
	private static RewardSummary instance = new RewardSummary();
	public HashMap<Player, Integer> coins = new HashMap<>();
	public HashMap<Player, Integer> souls = new HashMap<>();
	
	public static RewardSummary getInstance(){
		return instance;
	}
	
	
	public Integer addCoins(Player p, int coins){
		if(!isInHash(p)){
			return this.coins.put(p, coins);
		}else{
			return this.coins.put(p, this.coins.get(p) + coins);
		}
	}
	
	
	public Integer getCoins(Player p){
		if(isInHash(p)){
			return this.coins.get(p);
		}else{
			return 0;
		}
	}
	
	public void resetPlayer(Player p){
		if(isInHash(p)){
			this.coins.remove(p);
		}
	}
	
	public boolean isInHash(Player p){
		if(coins.containsKey(p))
			return true;
		return false;
	}
	
	///////////Souls////////
	
	public Integer addSouls(Player p, int souls){
	   if(!isInHashSouls(p)){
		   return this.souls.put(p, souls);
	   }else{
		   return this.souls.put(p, this.souls.get(p) + souls);
	   }
	}
	
	
	public Integer getSouls(Player p){
		if(isInHashSouls(p)){
		return this.souls.get(p);
		}else{
			return 0;
		}
	}
	
	public void resetPlayerSouls(Player p){
		if(isInHashSouls(p)){
			this.souls.remove(p);
		}
	}
	
	public boolean isInHashSouls(Player p){
		if(souls.containsKey(p))
			return true;
		return false;
	}
	
}
