package net.iz44kpvp.neoskywars.skywars;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Location;

import net.iz44kpvp.neoskywars.player.SkyPlayer;

public class SkyWarsSpawn
{
    private List<SkyPlayer> player;
    private Location location;
    private SkyWars.GameMode mode;
    
    public SkyWarsSpawn(final Location l, final SkyWars.GameMode mode) {
        this.player = new ArrayList<SkyPlayer>();
        this.location = l;
        this.mode = mode;
    }
    
    public SkyWarsSpawn addPlayer(final SkyPlayer p) {
        this.player.add(p);
        return this;
    }
    
    public void removePlayer(final SkyPlayer p) {
        this.player.remove(p);
    }
    
    public Location getLocation() {
        return this.location;
    }
    
    public SkyPlayer[] getPlayers() {
        return this.player.toArray(new SkyPlayer[this.player.size()]);
    }
    
    public boolean hasPlayer(final SkyPlayer p) {
        return this.player.contains(p);
    }
    
    public boolean hasSlot() {
        if (this.mode.equals(SkyWars.GameMode.TEAM)) {
            return this.player.size() < 2;
        }
        if(this.mode.equals(SkyWars.GameMode.MEGA)){
        	return this.player.size() < 5;
        }
        return this.player.size() < 1;
    }
}
