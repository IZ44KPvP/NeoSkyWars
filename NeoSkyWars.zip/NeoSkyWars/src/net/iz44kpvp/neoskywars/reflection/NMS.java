package net.iz44kpvp.neoskywars.reflection;

import java.lang.reflect.Field;

public abstract class NMS
{
    private static boolean initialized;
    public static Class<?> DataWatcher;
    public static Class<?> EntityLiving;
    public static Class<?> EntityPlayer;
    public static Class<?> Packet;
    public static Class<?> EnumClientCommand;
    public static Class<?> PacketPlayInClientCommand;
    public static Class<?> PacketPlayOutSpawnEntityLiving;
    public static Class<?> PacketPlayOutEntityDestroy;
    public static Class<?> PacketPlayOutEntityMetadata;
    public static Class<?> PacketPlayOutTitle$EnumTitleAction;
    public static Class<?> PacketPlayOutTitle;
    public static Class<?> IChatBaseComponent;
    public static Class<?> IChatBaseComponent$ChatSerializer;
    public static Class<?> PacketPlayOutChat;
    public static Class<?> World;
    public static Class<?> CraftWorld;
    public static Class<?> Chunk;
    public static Class<?> BlockPosition;
    public static Class<?> IBlockData;
    public static Class<?> Block;
    
    static {
        if (!NMS.initialized) {
            Field[] declaredFields;
            for (int length = (declaredFields = NMS.class.getDeclaredFields()).length, i = 0; i < length; ++i) {
                final Field f = declaredFields[i];
                if (f.getType().equals(Class.class)) {
                    try {
                        f.set(null, Reflection.getNMSWithException(f.getName()));
                    }
                    catch (Exception e2) {
                        if (f.getName().equals("EnumClientCommand")) {
                            try {
                                f.set(null, Reflection.getNMSWithException("PacketPlayInClientCommand$EnumClientCommand"));
                            }
                            catch (Exception e1) {
                                e1.printStackTrace();
                            }
                        }
                        else if (f.getName().equals("CraftWorld")) {
                            try {
                                f.set(null, Reflection.getOBCClass(f.getName()));
                            }
                            catch (Exception e1) {
                                e1.printStackTrace();
                            }
                        }
                    }
                }
            }
        }
    }
}
