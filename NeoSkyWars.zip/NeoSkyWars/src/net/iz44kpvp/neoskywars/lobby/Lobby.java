package net.iz44kpvp.neoskywars.lobby;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.Plugin;

import com.sk89q.worldedit.bukkit.WorldEditPlugin;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.SettingsManager;
import net.iz44kpvp.neoskywars.lobby.GUIs.Rooms;
import net.iz44kpvp.neoskywars.lobby.GUIs.SpectatorGUI;
import net.iz44kpvp.neoskywars.utils.LobbyPlayer;
import net.iz44kpvp.neoskywars.utils.Menu;

public class Lobby
{
    private static Lobby instance;
    private HashMap<String, Menu> menus;
    private List<LobbyPlayer> players;
    public static HashMap<String, ItemStack[]> saveinv = new HashMap<String, ItemStack[]>();
    public static HashMap<String, ItemStack[]> armadura = new HashMap<String, ItemStack[]>();
    
    static {
        Lobby.instance = new Lobby();
    }
    	
    private Lobby() {
        this.menus = new HashMap<String, Menu>();
        this.players = new ArrayList<LobbyPlayer>();
        this.registerMenu("spect", new SpectatorGUI());
        this.registerMenu("rooms", new Rooms());
    }
    
    public static Lobby getInstance() {
        return Lobby.instance;
    }
    
    public boolean isLobby() {
        return SettingsManager.getLobby().contains("lobby.location");
    }
    
    public Location getLobby() {
        return SettingsManager.getLobby().loadLocation(SettingsManager.getLobby().get("lobby.location"));
    }
    
    public WorldEditPlugin getWorldEdit() {
        Plugin p = Bukkit.getServer().getPluginManager().getPlugin("WorldEdit");
        if (p instanceof WorldEditPlugin) return (WorldEditPlugin) p;
        else return null;
}
    
    
    public void registerMenu(final String id, final Menu menu) {
        this.menus.put(id, menu);
    }
    
    public void addPlayer(final Player p) {
        if (this.getPlayer(p) == null) {
            this.players.add(new LobbyPlayer(p));
        }
        saveinv.put(p.getName(), p.getInventory().getContents());
        armadura.put(p.getName(), p.getInventory().getArmorContents());
        p.setLevel(0);
        p.setExp(0.0f);
        p.setHealth(20.0);
        p.setFoodLevel(20);
        if (p.getAllowFlight() && p.getGameMode() != GameMode.CREATIVE) {
            p.setAllowFlight(false);
        }
        ArrayList<String> lore1 = new ArrayList<>();
        ArrayList<String> lore2 = new ArrayList<>();
        ArrayList<String> lore3 = new ArrayList<>();
        ItemStack stats = null;
        if(Main.items.getConfig().getString("Lobby.Items.Stats.Id").equalsIgnoreCase("skull")){
        	stats = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
        	SkullMeta statsmeta = (SkullMeta) stats.getItemMeta();
       	    statsmeta.setDisplayName(Main.items.get("Lobby.Items.Stats.Name"));
       	    statsmeta.setOwner(p.getName());
            for(String list : Main.items.getConfig().getStringList("Lobby.Items.Stats.Lore")){
            	lore1.add(list.replace("&", "�"));
            	statsmeta.setLore(lore1);
            }
            stats.setItemMeta(statsmeta);
        }else{
        	stats = new ItemStack(Material.getMaterial(Main.items.getConfig().getString("Lobby.Items.Stats.Id")));
        	ItemMeta statsmeta = stats.getItemMeta();
        	 statsmeta.setDisplayName(Main.items.get("Lobby.Items.Stats.Name"));
             for(String list : Main.items.getConfig().getStringList("Lobby.Items.Stats.Lore")){
             	lore1.add(list.replace("&", "�"));
             	statsmeta.setLore(lore1);
             }
             stats.setItemMeta(statsmeta);
        }

        
        ItemStack stats1 = new ItemStack(Material.getMaterial(Main.items.getConfig().getString("Lobby.Items.Shop.Id")));
        ItemMeta statsmeta1 = stats1.getItemMeta();
        statsmeta1.setDisplayName(Main.items.get("Lobby.Items.Shop.Name"));
        for(String list2 : Main.items.getConfig().getStringList("Lobby.Items.Shop.Lore")){
        	lore2.add(list2.replace("&", "�"));
        	statsmeta1.setLore(lore2);
        }
        stats1.setItemMeta(statsmeta1);
        
        ItemStack stats11 = new ItemStack(Material.getMaterial(Main.items.getConfig().getString("Lobby.Items.Selector.Id")));
        ItemMeta statsmeta11 = stats11.getItemMeta();
        statsmeta11.setDisplayName(Main.items.get("Lobby.Items.Selector.Name"));
        for(String list2 : Main.items.getConfig().getStringList("Lobby.Items.Selector.Lore")){
        	lore3.add(list2.replace("&", "�"));
        	statsmeta11.setLore(lore3);
        }
        stats11.setItemMeta(statsmeta11);
        
        p.getInventory().clear();
        p.getInventory().setArmorContents((ItemStack[])null);
        if(Main.items.getConfig().getBoolean("Lobby.Items.Stats.Enable")){
        	p.getInventory().setItem(Main.items.getInt("Lobby.Items.Stats.Slot"), stats);
        }
        if(Main.items.getConfig().getBoolean("Lobby.Items.Shop.Enable")){
        p.getInventory().setItem(Main.items.getInt("Lobby.Items.Shop.Slot"), stats1);
        }
        if(Main.items.getConfig().getBoolean("Lobby.Items.Selector.Enable")){
        	p.getInventory().setItem(Main.items.getInt("Lobby.Items.Selector.Slot"), stats11);
        }
        p.updateInventory();

    }
    
    public void addPlayerWithoutItems(final Player p) {
        if (this.getPlayer(p) == null) {
            this.players.add(new LobbyPlayer(p));
        }
        p.setLevel(0);
        p.setExp(0.0f);
        p.setHealth(20.0);
        p.setFoodLevel(20);
        if (p.getAllowFlight() && p.getGameMode() != GameMode.CREATIVE) {
            p.setAllowFlight(false);
        }
       
  

    }
   

    
    public void removePlayer(final Player p) {
    	
        if (this.getPlayer(p) != null) {
            this.players.remove(this.getPlayer(p));
        }
        p.getInventory().setContents((ItemStack[])saveinv.get(p.getName()));
        p.getInventory().setArmorContents((ItemStack[])armadura.get(p.getName()));
        saveinv.remove(p.getName());
        armadura.remove(p.getName());
    }
    
    public Menu getMenu(final String id) {
        return this.menus.get(id);
    }
    
    public LobbyPlayer getPlayer(final Player p) {
        for (final LobbyPlayer players : this.players) {
            if (players.getPlayer().equals(p)) {
                return players;
            }
        }
        return null;
    }
    
    public boolean hasPlayer(final Player p) {
        return this.getPlayer(p) != null;
    }
    
    public Menu[] getMenus() {
        return this.menus.values().toArray(new Menu[this.menus.values().size()]);
    }
    
    public LobbyPlayer[] getPlayers() {
        return this.players.toArray(new LobbyPlayer[this.players.size()]);
    }
}
