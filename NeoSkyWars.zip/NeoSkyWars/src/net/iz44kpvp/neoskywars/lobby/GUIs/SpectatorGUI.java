package net.iz44kpvp.neoskywars.lobby.GUIs;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.SkullType;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.player.SkyPlayer;
import net.iz44kpvp.neoskywars.skywars.SkyWars;
import net.iz44kpvp.neoskywars.utils.Menu;

public class SpectatorGUI extends Menu implements Listener
{
    public SpectatorGUI() {
        super(Messages.getInstance().SPECTATOR_INV_TITLE, 27);
    }
    
    @Override
    public void registerItems() {
    }
    
    @Override
    public void registerItems(final Player p) {
        this.inv.clear();
        final SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
        SkyPlayer[] players;
        for (int length = (players = sw.getPlayers()).length, i = 0; i < length; ++i) {
            final SkyPlayer alive = players[i];
            if (alive.isAlive()) {
                this.inv.addItem(new ItemStack[] { this.addHead(alive.getPlayer()) });
            }
        }
        p.openInventory(this.inv);
    }
    
    @EventHandler
    public void click(InventoryClickEvent e) {
    	Player p = (Player) e.getWhoClicked();
    	ItemStack item = e.getCurrentItem();
    	if(e.getInventory().getName() != Messages.getInstance().SPECTATOR_INV_TITLE){
    		return;
    	}
    	if(e.getCurrentItem() == null)return;
    	if(e.getClickedInventory() == null)return;
    	if(!e.getCurrentItem().hasItemMeta())return;
        if (item.hasItemMeta() && item.getType() == Material.SKULL_ITEM) {
            p.closeInventory();
            final String name = ((SkullMeta)item.getItemMeta()).getOwner();
            if (Bukkit.getPlayerExact(name) != null) {
                p.teleport((Entity)Bukkit.getPlayerExact(name));
                p.sendMessage(Messages.getInstance().SPECT_TELEPORTED.replace("<player>", Bukkit.getPlayerExact(name).getName()));
            }
        }
    }
    

    
    public ItemStack addHead(final Player p) {
        final ItemStack head = new ItemStack(Material.SKULL_ITEM, 1, (short)SkullType.PLAYER.ordinal());
        final SkullMeta meta = (SkullMeta)head.getItemMeta();
        meta.setDisplayName(String.valueOf(Main.green) + p.getName());
        meta.setOwner(p.getName());
        head.setItemMeta((ItemMeta)meta);
        return head;
    }

	@Override
	public void click(ItemStack p0, Player p1) {
				
	}
}
