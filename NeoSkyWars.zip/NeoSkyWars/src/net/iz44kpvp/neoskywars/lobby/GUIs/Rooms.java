package net.iz44kpvp.neoskywars.lobby.GUIs;

import java.util.ArrayList;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.managers.PartyManager;
import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.skywars.SkyWars;
import net.iz44kpvp.neoskywars.utils.Menu;

public class Rooms
  extends Menu
{
  public Rooms()
  {
    super("�a�lSKYWARS ARENAS", 54);
  }
  
  private static Rooms instance = new Rooms();
  
  public static Rooms getInstance(){
	  return instance;
  }
  
  @SuppressWarnings("incomplete-switch")
public void registerItems()
  {
    int rooms = 0;
    this.inv.clear();
    for (SkyWars skywars : SkyWarsManager.getInstance().getSkyWars())
    {
      rooms++;
      if (rooms > 53) {
        break;
      }
      ItemStack item = null;
      String type = null;
      String state = null;
      skywars.getState().toString().substring(0, 1).toUpperCase();
	  skywars.getState().toString().substring(1).toLowerCase();
	  
      switch (skywars.getState())
      {
      case WAITING: 
    	state = Main.items.get("Lobby.Inventories.Arenas.Items.SkyWars.State-Waiting");
        type = skywars.getChestType().toString().substring(0, 1) + skywars.getChestType().toString().substring(1).toLowerCase();
        item = new ItemStack(Material.getMaterial(Main.items.getConfig().getString("Lobby.Inventories.Arenas.Items.SkyWars.Id-Waiting")));
        item.setAmount(skywars.getPlayers().length);
        break;
      case STARTED: 
    	state = Main.items.get("Lobby.Inventories.Arenas.Items.SkyWars.State-Started");
        type = skywars.getChestType().toString().substring(0, 1) + skywars.getChestType().toString().substring(1).toLowerCase();
        item = new ItemStack(Material.getMaterial(Main.items.getConfig().getString("Lobby.Inventories.Arenas.Items.SkyWars.Id-Started")));
        item.setAmount(skywars.getPlayers().length);
        break;
      }
      if (type != null)
      {
    	ArrayList<String> lista = new ArrayList<>();
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("�a" + skywars.getID());
        for(String list : Main.items.getConfig().getStringList("Lobby.Inventories.Arenas.Items.SkyWars.Lore")){
        	lista.add(list.replace("&", "�").replace("%players%", "" + skywars.getPlayers().length + "/" + skywars.getMaxPlayers()).replace("%type%", skywars.getMode().toString().substring(0, 1) + skywars.getMode().toString().substring(1).toLowerCase()).replace("%mode%", skywars.getChestType().toString().substring(0, 1) + skywars.getChestType().toString().substring(1).toLowerCase()).replace("%state%", state));
        	meta.setLore(lista);
        }
        item.setItemMeta(meta);
        
        this.inv.setItem(this.inv.firstEmpty(), item);
      }
    }
  }
  
  public void click(ItemStack item, Player p)
  {
	  boolean leader = false;
    if ((item.hasItemMeta()) && item != null && item.getType() != Material.AIR && item.getType() != null &&
      (item.getType() == Material.getMaterial(Main.items.getConfig().getString("Lobby.Inventories.Arenas.Items.SkyWars.Id-Started")) || item.getType() == Material.getMaterial(Main.items.getConfig().getString("Lobby.Inventories.Arenas.Items.SkyWars.Id-Waiting"))))
    {
      p.closeInventory();
      SkyWars highest = SkyWarsManager.getInstance().getSkyWars(ChatColor.stripColor(item.getItemMeta().getDisplayName()));
      if (highest != null) {
    	  
        if(SkyWarsManager.getInstance().getSkyWars(p) == null){
        	PartyManager party = PartyManager.getParty(p);
            
            if(party != null){
            	if(party.getOwner().getName().equalsIgnoreCase(p.getName())){
            		highest.addPlayer(p);
            		p.sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
            		leader = true;
            	}else{
            		p.sendMessage(Messages.getInstance().PARTY_YOU_IS_NOT_LEADER);
            		leader = false;
            	}
            }else{
            	highest.addPlayer(p);
            	p.sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
            }
            if(party == null){
            	return;
            }
            for(Player member : party.getMembers()){
            	if(member != null){
            		if(member != p){
            			if(leader){
            				if(SkyWarsManager.getInstance().getSkyWars(member) != null){
            					SkyWars sw = SkyWarsManager.getInstance().getSkyWars(member);
            						sw.removePlayerSilent(member);
            				}
            				member.sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
                    		highest.addPlayer(member);
            			}
            		}
            	}
            }
            
        }
       }
        	return;		
        }
        p.sendMessage(Messages.getInstance().YOU_ALREADY_IN_GAME);
      
    
  }
  
  
  public void registerItems(Player p) {}
}
