package net.iz44kpvp.neoskywars.lobby.GUIs;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.skywars.SkyWars;

public class StatsGUI
  implements Listener
{

  
 @EventHandler
  protected void click(InventoryClickEvent e)
  {
	 Player p = (Player) e.getWhoClicked();
	 SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
	 
	 if(sw != null){
		 return;
	 }
	 
	 if(e.getCurrentItem() == null){
		 return;
	 }
	 
    if ((e.getCurrentItem().hasItemMeta()) && (e.getCurrentItem().getItemMeta().getDisplayName().equals(Main.items.get("Lobby.Inventories.Stats.Name")))) {
      e.setCancelled(true);
    }
  }
}
