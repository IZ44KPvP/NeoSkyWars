package net.iz44kpvp.neoskywars.commands;

import java.io.File;
import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;

import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import com.sk89q.worldedit.bukkit.selections.Selection;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.SettingsManager;
import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.listeners.LobbyListeners;
import net.iz44kpvp.neoskywars.listeners.SignListeners;
import net.iz44kpvp.neoskywars.lobby.Lobby;
import net.iz44kpvp.neoskywars.managers.PartyManager;
import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.player.SkyPlayer;
import net.iz44kpvp.neoskywars.player.storage.Stats;
import net.iz44kpvp.neoskywars.scoreboard.ScoreboardManager;
import net.iz44kpvp.neoskywars.skywars.SkyWars;
import net.iz44kpvp.neoskywars.utils.Utils;

public class SkyWarsCommand implements CommandExecutor{

    public static ArrayList<Player> incooldown = new ArrayList<>();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(cmd.getName().equalsIgnoreCase("skywars")){
		    if(!(sender instanceof Player)){
		    	if(args[0].equalsIgnoreCase("coins")){
					if(!sender.hasPermission("skywars.coins")){
						sender.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
						return true;
					}
					if(args.length != 4){
						sender.sendMessage("�cUsages: \n"
								+ "�7/skywars coins add <player> <value> \n"
								+ "�7/skywars coins remove <player> <value>");
						return true;
					}
					int coins = Integer.valueOf(args[3]);
					Player player = Bukkit.getPlayerExact(args[2]);
					if(player == null){
						sender.sendMessage("�cThis Player is Currently Offline.");
						return true;
					}
					try{
						if(args[1].equalsIgnoreCase("add")){
							Stats.addCoins(player, coins);
							sender.sendMessage("�aYou have added �7" + coins + " coins �ain Player�s �7" + player.getName() + " �aAccount");
						}else if(args[1].equalsIgnoreCase("remove")){
							Stats.removeCoins(player, coins);
							sender.sendMessage("�aYou have removed �7" + coins + " coins �ain Player�s �7" + player.getName() + " �aAccount");
						}else{
							sender.sendMessage("�cUsages: \n"
									+ "�7/skywars coins add <player> <value> \n"
									+ "�7/skywars coins remove <player> <value>");
						}
					}catch(Exception e){
						sender.sendMessage("�cThe coins Value must be Numbers");
						e.printStackTrace();
					}
					return true;
				}
				
				if(args[0].equalsIgnoreCase("souls")){
					if(!sender.hasPermission("skywars.coins")){
						sender.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
						return true;
					}
					if(args.length != 4){
						sender.sendMessage("�cUsages: \n"
								+ "�7/skywars souls add <player> <value> \n"
								+ "�7/skywars souls remove <player> <value>");
						return true;
					}
					int souls = Integer.valueOf(args[3]);
					Player player = Bukkit.getPlayerExact(args[2]);
					if(player == null){
						sender.sendMessage("�cThis Player is Currently Offline.");
						return true;
					}
					try{
						if(args[1].equalsIgnoreCase("add")){
							Stats.addSouls(player, souls);
							sender.sendMessage("�aYou have added �7" + souls + " souls �ain Player�s �7" + player.getName() + " �aAccount");
						}else if(args[1].equalsIgnoreCase("remove")){
							Stats.removeSouls(player, souls);
							sender.sendMessage("�aYou have remove �7" + souls + " souls �ain Player�s �7" + player.getName() + " �aAccount");
						}else{
							sender.sendMessage("�cUsages: \n"
									+ "�7/skywars souls add <player> <value> \n"
									+ "�7/skywars souls remove <player> <value>");
						}
					}catch(Exception e){
						sender.sendMessage("�cThe coins Value must be Numbers");
						e.printStackTrace();
					}
					return true;
				}
		    	
				sender.sendMessage("�cOnly Players can use this command.");
				return true;
			}
			final Player p = (Player) sender;
			if(args.length == 0){
	
			   if(!p.hasPermission("skywars.cmd")){
			   p.sendMessage("");
		       p.sendMessage("�a/skywars leave �7- Leave of current Arena");
			   p.sendMessage("�a/skywars stats �7- Display your SkyWars Stats!");
			   p.sendMessage("�a/skywars arenaselector �7- Selector of SkyWars Arenas");
			   p.sendMessage("�a/skywars playagain �7- To Player SkyWars Again");
			   p.sendMessage("");
			   }else{
					p.sendMessage("�aNeoSkyWars v" + Main.getPlugin().getDescription().getVersion());
					p.sendMessage("");
					p.sendMessage("�a�m�l-------- �e�lCOMMANDS�a�m�l -----------�7");
					p.sendMessage("");
				    p.sendMessage("�a/skywars joinlobby �7- Join SkyWars Lobby");
				    p.sendMessage("�a/skywars leavelobby �7- Leave SkyWars Lobby");
				    p.sendMessage("�a/skywars forcestart �7- Force SkyWars Game Start");
					p.sendMessage("�a/skywars setlobby �7- To Set SkyWars Lobby");
					p.sendMessage("�a/skywars create mode<solo, team> type<insane, normal> �7- Create new arena");
					p.sendMessage("�a/skywars createmap <name> �7- To create one Empty World");
					p.sendMessage("�a/skywars tp <worldName> �7- Teleport to one World");
					p.sendMessage("�a/skywars load <worldName> �7- Load one World in Server Folder");
					p.sendMessage("�a/skywars addspawn �7- Add a spawn to the arena");
					p.sendMessage("�a/skywars chest <normal, feast> �7- Get Item to set SkyWars Chests");
					p.sendMessage("�a/skywars setdmlocation �7- DeathMatch Arena Set");
					p.sendMessage("�a/skywars saveworld �7- Save an edit if you made the Map");
					p.sendMessage("�a/skywars coins <add, remove> <player> <value> �7- Add/Remove Coins from Player�s Account");
					p.sendMessage("�a/skywars souls <add, remove> <player> <value> �7- Add/Remove Souls from Player�s Account");
					p.sendMessage("�a/skywars addnpc <play, arenas> �7- Add NPC TO Join/See Arenas on Click");
					p.sendMessage("�a/skywars version �7- Check plugin version");
					p.sendMessage("");
					p.sendMessage("�a�m�l----------------------------------�7");
			   }
				return true;
			}
			if(args[0].equalsIgnoreCase("create")){
				if(!p.hasPermission("skywars.create")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
	          
	            if(args.length != 3){
	            	p.sendMessage("�cUsage: �7/skywars create <solo, team, mega> <normal, insane, mega>");
	            	return true;
	            }
	            
	            String mode = args[1];
	            String chests = args[2];
	            
	            if (SkyWars.GameMode.valueOf(mode.toUpperCase()) != null && SkyWars.ChestType.valueOf(chests.toUpperCase()) != null) {
	                if (SkyWarsManager.getInstance().getSkyWars(p.getWorld().getName()) == null) {
	                    Selection selection = ((WorldEditPlugin)Bukkit.getPluginManager().getPlugin("WorldEdit")).getSelection(p);
	                    if (selection != null) {
	                        SettingsManager sm = SettingsManager.getSkywars(p.getWorld().getName());
	                        sm.set("world", selection.getWorld().getName());
	                        sm.set("mode", mode.toUpperCase());
	                        if(mode.equalsIgnoreCase("mega")){
	                        	sm.set("type", "MEGA");
	                        }else{
	                        	sm.set("type", chests.toUpperCase());
	                        }
	                        sm.saveLocation(sm.createSection("boundsA"), selection.getMaximumPoint(), false, null);
	                        sm.saveLocation(sm.createSection("boundsB"), selection.getMinimumPoint(), false, null);
	                        sm.save();
	                        p.chat("/skywars saveworld");
	                        SkyWarsManager.getInstance().setup();
	                        p.sendMessage("�7Arena:�7 " + p.getWorld().getName() + " �aCreated");
	                        
	                        for(Player ps: Bukkit.getWorld(p.getWorld().getName()).getPlayers()){
	                        	ps.kickPlayer("�aWorld Preparing please relog in the Server!");
	                        }
                        	

	                    } else {
	                        p.sendMessage("�cSelect arena border with WorldEdit");
	                    }
	                } else {
	                    p.sendMessage("�cThis skywars already exists");
	                }
	            }
	           return true;   
			}
			if(args[0].equalsIgnoreCase("saveworld")){
				if(!p.hasPermission("skywars.saveworld")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
             	File from = new File(p.getWorld().getName());
	 			    File to = new File(Main.getPlugin().getDataFolder() + "/mapas/" + p.getWorld().getName());
	 			    p.getWorld().save();
	 			    if(to.exists()){
	 			    	SkyWarsManager.getInstance().deleteFolder(to);
	 			    }
	 			    SkyWarsManager.getInstance().copyDir(from, to);
					p.sendMessage("�aWorld saved successfully.");
	 			    return true;
			}
			if(args[0].equalsIgnoreCase("addspawn")){
				if(!p.hasPermission("skywars.addspawn")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
	            SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p.getWorld().getName());
	            if (sw != null) {
	                if (p.hasPermission("skywars.addspawn")) {
	                	
				         
	                    sw.addSpawn(p.getLocation());
	                    SettingsManager sm = sw.getConfig();
	                    if (!sm.contains("spawns")) {
	                        sm.createSection("spawns");
	                    }
	                    sm.saveLocation(sm.createSection("spawns." + sm.get("spawns").getKeys(false).size()), p.getLocation(), false, null);
	                    sm.save();
	                    p.sendMessage("�aSpawn added.");
	                } else {
	                    p.sendMessage("�cYou are not allowed to use this command.");
	                }
	            } else {
	                p.sendMessage(Messages.getInstance().COMMAND_SW_NOTFOUND);
	            }
	            return true;
			}
			if(args[0].equalsIgnoreCase("setwait")){
				boolean manu = true;
				if(manu){
                   p.sendMessage("�cComing Soon");  
				  return true;
				}
				if(!p.hasPermission("skywars.setwait")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
	            SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p.getWorld().getName());
	            if (sw != null) {
	                if (p.hasPermission("skywars.setwait")) {
	                	
				         
	                    sw.addSpawn(p.getLocation());
	                    SettingsManager sm = sw.getConfig();
	                    sm.set("wait.x", p.getLocation().getBlockX());
	                    sm.set("wait.y", p.getLocation().getBlockY());
	                    sm.set("wait.z", p.getLocation().getBlockZ());
	                    sm.set("wait.pitch", p.getLocation().getPitch());
	                    sm.set("wait.yaw", p.getLocation().getYaw());
	                    sm.save();
	                    p.sendMessage("�aSkyWars Wait Room Seted.");
	                } else {
	                    p.sendMessage("�cYou are not allowed to use this command.");
	                }
	            } else {
	                p.sendMessage(Messages.getInstance().COMMAND_SW_NOTFOUND);
	            }
	            return true;
			}			
			if(args[0].equalsIgnoreCase("chest")){
				if(!p.hasPermission("skywars.setchests")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
				
				if(args.length != 2){
					p.sendMessage("�cUse /skywars chest <normal, feast>");
					return true;
				}

				if(args[1].equalsIgnoreCase("normal")){
					SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p.getWorld().getName());
					if(sw == null){
						p.sendMessage(Messages.getInstance().COMMAND_SW_NOTFOUND);
						return true;
					}
		    		ItemStack item = new ItemStack(Material.GOLD_INGOT);
		    		ItemMeta itemmeta = item.getItemMeta();
		    		itemmeta.setDisplayName("�aChest Normal");
		    		item.setItemMeta(itemmeta);
		    		
		    		p.getInventory().addItem(item);
		    		p.sendMessage("�aReceived item");
		    		p.sendMessage("");
		    		p.sendMessage("�aClick on chests with the left button");

				}else if(args[1].equalsIgnoreCase("feast")){
		     		ItemStack item = new ItemStack(Material.DIAMOND);
		    		ItemMeta itemmeta = item.getItemMeta();
		    		itemmeta.setDisplayName("�aChest Feast");
		    		item.setItemMeta(itemmeta);
		    		
		    		p.getInventory().addItem(item);
		    		p.sendMessage("�aReceived item");
		    		p.sendMessage("");
		    		p.sendMessage("�aClick on chests with the left button");
				}
				return true;
			}
			if(args[0].equalsIgnoreCase("setdmlocation")){
				if(!p.hasPermission("skywars.setdm")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
	            final SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p.getWorld().getName());
	            if (sw != null) {
	                sw.setArena(p.getLocation());
	                final SettingsManager sm = sw.getConfig();
	                if (!sm.contains("deathmatch")) {
	                    sm.createSection("deathmatch");
	                }
	                sm.saveLocation(sm.createSection("deathmatch"), p.getLocation(), false, null);
	                sm.save();
	                p.sendMessage(Messages.getInstance().COMMAND_SWDM_SUCESS);
	            }
	            else {
	                p.sendMessage(Messages.getInstance().COMMAND_SW_NOTFOUND);
	            }
	         return true;   
			}
			if(args[0].equalsIgnoreCase("setlobby")){
				if(!p.hasPermission("skywars.setlobby")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
		        if (!SettingsManager.getLobby().contains("lobby")) {
		            SettingsManager.getLobby().createSection("lobby");
		        }
		        SettingsManager.getLobby().saveLocation(SettingsManager.getLobby().get("lobby"), p.getLocation(), false, null);
		        SettingsManager.getLobby().save();
		        p.sendMessage("�aLobby successfully set");
		        return true;
			}
			if(args[0].equalsIgnoreCase("leave")){
				if(!p.hasPermission("skywars.leave")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
				SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
	        	if(sw != null){
	                SkyWarsManager.getInstance().getSkyWars(p).removePlayerSilent(p);
	                p.sendMessage("�cYou left the game.");
	                return true;
	           	}
	           	p.sendMessage("�cYou're not in a match.");
	           	return true;
	       	}
			if(args[0].equalsIgnoreCase("joinlobby")){
                if(!p.hasPermission("skywars.joinlobby")){
                	p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
                	return true;
                }
                if(Lobby.getInstance().hasPlayer(p)){
                	p.sendMessage("�cYou already in Lobby.");
                	return true;
                }
				for (Player ps : Bukkit.getOnlinePlayers()) {
		            if (Lobby.getInstance().hasPlayer(ps)) {
		                if (!Lobby.getInstance().getPlayer(ps).canViewPlayers()) {
		                    ps.hidePlayer(p);
		                }
		            }
		            else if (SkyWarsManager.getInstance().getSkyWars(ps) != null) {
		                ps.hidePlayer(p);
		                p.hidePlayer(ps);
		            }
		            else if (!ps.canSee(p)) {
		                ps.showPlayer(p);
		            }
		        }
		        if (p.getGameMode() != GameMode.SURVIVAL) {
		            p.setGameMode(GameMode.SURVIVAL);
		        }
		        p.sendMessage(Messages.getInstance().PLAYER_JOINED_SKYWARS_LOBBY);
		        Lobby.getInstance().addPlayer(p);
		        if(ScoreboardManager.getScoreboard(p) == null){
		        	ScoreboardManager.iniciarScoreboardLobby(p);
		        }
		        if (Lobby.getInstance().isLobby()) {
		            p.teleport(Lobby.getInstance().getLobby());
		        }
		   
		        Stats.createAccount(p);
		        return true;
			}
			if(args[0].equalsIgnoreCase("leavelobby")){
				if(p.hasPermission("skywars.lobbyleave")){
					if(!Lobby.getInstance().hasPlayer(p)){
						p.sendMessage("�cYou are not in SkyWars Lobby");
						return true;
					}
					Lobby.getInstance().removePlayer(p);
					p.sendMessage(Messages.getInstance().PLAYER_LEFT_SKYWARS_LOBBY);
					p.getInventory().clear();
					
					if(ScoreboardManager.getScoreboard(p) != null){
						ScoreboardManager.removeScoreboard(ScoreboardManager.getScoreboard(p));
					}
				    p.performCommand(Main.getPlugin().getConfig().getString("Player-On-Lobby-Leave-Command"));
				}else{
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
				}
				return true;
			}
			if(args[0].equalsIgnoreCase("stats")){
				if(!p.hasPermission("skywars.stats")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
				}
				SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
	             if(sw == null){
	            	 LobbyListeners.openInv(p);
	            	 return true;
	             }
	             p.sendMessage("�cThis command can not be used in Game.");
	             return true;
			}
			if(args[0].equalsIgnoreCase("forcestart")){
				if(p.hasPermission("skywars.forcestart")){
					SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
					if(sw == null){
						p.sendMessage("�cYou are not in a SkyWars arena");
						return true;
					}
					if(sw.getState() == SkyWars.GameState.RESET || sw.getState() == SkyWars.GameState.STARTED){
						p.sendMessage("�cThis arena has already started.");
						return true;
					}
					sw.start();
					p.sendMessage("�aYou forced the start of the arena.");
					for(SkyPlayer ps : sw.getPlayers()){
						ps.getPlayer().sendMessage("�7" +  p.getName() + " �aForced the start of the match.");
					}
				}else{
					p.sendMessage("�cYou are not allowed to start an arena.");
				}
				
		    
				return true;
			}
			
			if(args[0].equalsIgnoreCase("version")){
				if(!p.hasPermission("skywars.version")){
					p.sendMessage(Messages.getInstance().COMMAND_NOT_FOUND);
				}
		    	p.sendMessage("�a�lNeoSkyWars Running version: �7" + Main.getPlugin().getDescription().getVersion());
		    	return true;
		    }
			
			if(args[0].equalsIgnoreCase("createmap")){
				if(!p.hasPermission("skywars.createmap")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
			 if(!(args.length < 2)){
	          try{
					
					
					p.sendMessage("�aStarting World Create");
					World worldCreator = Utils.createEmptyWorld(args[1]);
				      if (worldCreator == null)
				      {
				        p.sendMessage("�cThis World Exist�s.");
				        return true;
				      }
				      p.sendMessage("�aWorld Created With Sucess!.");
				      p.teleport(new Location(worldCreator, 0.0D, 21.0D, 0.0D), PlayerTeleportEvent.TeleportCause.PLUGIN);
				      Block block = p.getLocation().clone().subtract(0.0D, 1.0D, 0.0D).getBlock();
				      if (block.getType() == Material.AIR) {
				        block.setType(Material.BEDROCK);
				      }
				      
				      p.sendMessage("�aYou have be teleported to Map.");
                    
				}catch(Exception e){
					p.sendMessage("�cAn error has ocurred please check Console.");
					e.printStackTrace();
				}
			 }else{
				p.sendMessage("�cUsage �7/skywars createmap <name>");
			}
			
			return true;
			}
			
			if(args[0].equalsIgnoreCase("tp")){
				if(!p.hasPermission("skywars.tp")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
				if(args.length < 2){
					p.sendMessage("�cUsage �7/skywars tp <worldName>");
				}
				org.bukkit.World w = Bukkit.getWorld(args[1]);
				
				if(w == null){
					p.sendMessage("�cInvalid World");
					return true;
				}
				
				p.teleport(new Location(w, w.getSpawnLocation().getX(), w.getSpawnLocation().getY(), w.getSpawnLocation().getZ()));
				Block block = p.getLocation().clone().subtract(0.0D, 1.0D, 0.0D).getBlock();
			      if (block.getType() == Material.AIR) {
			        block.setType(Material.BEDROCK);
			      }
				p.sendMessage("�aTeleported.");
				return true;
			}
			
			if(args[0].equalsIgnoreCase("load")){
				if(!p.hasPermission("skywars.load")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
				if(args.length < 2){
					p.sendMessage("�cUsage �7/skywars load <worldName>");
					
				}
				try{
					String id = args[1];
					
					File f = new File(args[1]);
					
					if(!f.exists()){
						p.sendMessage("�cWorld not found in Server Folder.");
						return true;
					}
					
					p.sendMessage("�aStarting World Import");
                    final WorldCreator wc = new WorldCreator(id);
                    wc.generateStructures(false);
                    org.bukkit.World map = wc.createWorld();
                    map.setAutoSave(false);
                    map.setKeepSpawnInMemory(false);
                    map.setGameRuleValue("doMobSpawning", "false");
                    map.setGameRuleValue("doDaylightCycle", "false");
                    map.setGameRuleValue("mobGriefing", "false");
                    map.setTime(0L);
                    
                    p.sendMessage("�aWorld imported.");
					
				}catch(Exception e){
					p.sendMessage("�cAn Error ocorred Please Check Console.");
					e.printStackTrace();
				}
				
				return true;
			}
			if(args[0].equalsIgnoreCase("playagain")){
				boolean leader = false;
				if(incooldown.contains(p)){
					return true;
				}
				incooldown.add(p);
				new BukkitRunnable() {
					
					@Override
					public void run() {
						incooldown.remove(p);
						
					}
				}.runTaskLater(Main.getPlugin(), 20*10);
				if(SkyWarsManager.getInstance().getSkyWars(p) == null){
					return true;
				}
				final SkyWars highest = SignListeners.getOrganizedFromPlayers(SkyWarsManager.getInstance().getSkyWars(p).getMode(), SkyWarsManager.getInstance().getSkyWars(p).getChestType());
                if (highest != null) {
                    PartyManager p1 = PartyManager.getParty(p);
                    SkyWars sw1 = SkyWarsManager.getInstance().getSkyWars(p);

                    
                    if(p1 != null){
                    	if(p1.getOwner().getName().equalsIgnoreCase(p.getName())){
                    		 sw1.removePlayerSilent(p);
                    		highest.addPlayer(p);
                    		
                    		p.sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
                    		leader = true;
                    	}else{
                    		p.sendMessage(Messages.getInstance().PARTY_YOU_IS_NOT_LEADER);
                    		leader = false;
                    	}
                    }else{
                    	 sw1.removePlayerSilent(p);
                    	highest.addPlayer(p);
                    	p.sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
                    }
                    if(p1 == null){
                    	return true;
                    }
                    for(Player member : p1.getMembers()){
                    	if(member != null){
                    		if(member != p){
                    			if(leader){
                    				if(SkyWarsManager.getInstance().getSkyWars(member) != null){
                    					SkyWars sw = SkyWarsManager.getInstance().getSkyWars(member);
                    						sw.removePlayerSilent(member);
                    				}
                    				member.sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
                            		highest.addPlayer(member);
                            		
                    			}
                    		}
                    	}
                    }
                    
                }
                else {
                    p.sendMessage(Messages.getInstance().SW_SIGN_NOT_HAVEROOM_AVAIBLE);
                }
				return true;
			}
			
			if(args[0].equalsIgnoreCase("coins")){
				if(!p.hasPermission("skywars.coins")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
				if(args.length != 4){
					p.sendMessage("�cUsages: \n"
							+ "�7/skywars coins add <player> <value> \n"
							+ "�7/skywars coins remove <player> <value>");
					return true;
				}
				int coins = Integer.valueOf(args[3]);
				Player player = Bukkit.getPlayerExact(args[2]);
				if(player == null){
					p.sendMessage("�cThis Player is Currently Offline.");
					return true;
				}
				try{
					if(args[1].equalsIgnoreCase("add")){
						Stats.addCoins(player, coins);
						p.sendMessage("�aYou have added �7" + coins + " coins �ain Player�s �7" + player.getName() + " �aAccount");
					}else if(args[1].equalsIgnoreCase("remove")){
						Stats.removeCoins(player, coins);
						p.sendMessage("�aYou have removed �7" + coins + " coins �ain Player�s �7" + player.getName() + " �aAccount");
					}else{
						p.sendMessage("�cUsages: \n"
								+ "�7/skywars coins add <player> <value> \n"
								+ "�7/skywars coins remove <player> <value>");
					}
				}catch(Exception e){
					p.sendMessage("�cThe coins Value must be Numbers");
					e.printStackTrace();
				}
				return true;
			}
			
			if(args[0].equalsIgnoreCase("souls")){
				if(!p.hasPermission("skywars.coins")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
				if(args.length != 4){
					p.sendMessage("�cUsages: \n"
							+ "�7/skywars souls add <player> <value> \n"
							+ "�7/skywars souls remove <player> <value>");
					return true;
				}
				int coins = Integer.valueOf(args[3]);
				Player player = Bukkit.getPlayerExact(args[2]);
				if(player == null){
					p.sendMessage("�cThis Player is Currently Offline.");
					return true;
				}
				try{
					if(args[1].equalsIgnoreCase("add")){
						Stats.addSouls(player, coins);
						p.sendMessage("�aYou have added �7" + coins + " souls �ain Player�s �7" + player.getName() + " �aAccount");
					}else if(args[1].equalsIgnoreCase("remove")){
						Stats.removeSouls(player, coins);
						p.sendMessage("�aYou have remove �7" + coins + " souls �ain Player�s �7" + player.getName() + " �aAccount");
					}else{
						p.sendMessage("�cUsages: \n"
								+ "�7/skywars souls add <player> <value> \n"
								+ "�7/skywars souls remove <player> <value>");
					}
				}catch(Exception e){
					p.sendMessage("�cThe coins Value must be Numbers");
					e.printStackTrace();
				}
				return true;
			}
			
			if(args[0].equalsIgnoreCase("arenaselector")){
				if(!p.hasPermission("skywars.arenaselector")){
					p.sendMessage(Messages.getInstance().ONLY_VIPS_CAN_ACESS);
					return true;
				}
				
				Lobby.getInstance().getMenu("rooms").registerItems();
				p.openInventory(Lobby.getInstance().getMenu("rooms").inv);
				
				return true;
			}
			
			if(args[0].equalsIgnoreCase("addnpc")){
				if(!p.hasPermission("skywars.addnpc")){
					p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
					return true;
				}
				
				if(args.length == 1){
					p.sendMessage("�cUse: �c/skywars addnpc <arenas, play>");
					return true;
				}
				
				if(args[1].equalsIgnoreCase("arenas")){
					Utils.spawnarVillagerArenas(p.getLocation());
					p.sendMessage("�aAdded NPC.");
				}else if(args[1].equalsIgnoreCase("play")){
					Utils.spawnarVillagerPlay(p.getLocation());
					p.sendMessage("�aAdded NPC.");
				}else{
					p.sendMessage("�cUse: �c/skywars addnpc <arenas, play>");
				}
				
				return true;
			}
			
			p.sendMessage("�cArgument invalid use /skywars to see commands.");
			
			
		}
		return false;
	}

	

	
}
