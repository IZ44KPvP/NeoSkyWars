package net.iz44kpvp.neoskywars.commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.controllers.ChatController;
import net.iz44kpvp.neoskywars.managers.PartyManager;


public class PartyCommand implements CommandExecutor{
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args){
		if(!(sender instanceof Player))
			return true;
		
		Player p=(Player)sender;
		if(label.equalsIgnoreCase("party")){
			if(args.length==0){
				for(String list : Messages.getInstance().PARTY_COMMAND){
					list = ChatColor.translateAlternateColorCodes('&', list);
					p.sendMessage(list);
				}
			}
			else{
				if(args[0].equalsIgnoreCase("invite")){
					if(PartyManager.getParty(p)==null)
						PartyManager.createParty(p);
					PartyManager party=PartyManager.getParty(p);
					if(args.length==2){
						Player p2=Bukkit.getPlayerExact(args[1]);
						if(p2!=null&&p2.isOnline()){
							PartyManager party2=PartyManager.getParty(p2);
							if(party2==null){
								if(!party.getInvite().contains(p2)){
									party.invitePlayer(p2, 60);
									p.sendMessage(Messages.getInstance().PARTY_INVITED.replace("<invited>", p2.getName()));
									p2.sendMessage(Messages.getInstance().PARTY_NEW_INVITE.replace("<inviter>", p.getName()));
									ChatController.runCommand(p2, Messages.getInstance().PARTY_CHAT_CLICK, "/party accept " + p.getName(), Messages.getInstance().PARTY_CHAT_CLICK_LORE.replace("<inviter>", p.getName()));
								}else{
									p.sendMessage(Messages.getInstance().PARTY_IS_ALREADY_INVITED.replace("<invited>", p2.getName()));
								}
							}else{
								p.sendMessage(Messages.getInstance().PARTY_IS_ALREADY_IN_PARTY.replace("<invited>", p2.getName()));
							}
						}else{
							p.sendMessage(Messages.getInstance().PARTY_IS_OFFLINE.replace("<invited>", args[1]));
						}
					}else{
						p.sendMessage(Messages.getInstance().PARTY_INCORRECT_ARGS);
					}
				}else if(args[0].equalsIgnoreCase("accept")){
					PartyManager party=PartyManager.getParty(p);
					if(args.length==2){
						Player p2=Bukkit.getPlayerExact(args[1]);
						if(p2!=null&&p2.isOnline()){
							PartyManager party2=PartyManager.getParty(p2);
							if(party==null){
								if(party2!=null&&party2.getInvite().contains(p)){
									party2.addPlayer(p);
						            party2.getInvite().remove(p);
						            p.sendMessage(Messages.getInstance().PARTY_HAS_JOINED.replace("<inviter>", p2.getName()));
									for(Player p3:party2.getMembers())
									    p3.sendMessage(Messages.getInstance().PARTY_PLAYER_JOINED.replace("<player>", p.getName()).replace("<inviter>", p2.getName()));
								}else{
									p.sendMessage(Messages.getInstance().PARTY_NOT_HAVE_INVITE.replace("<player>", p2.getName()));
								}
							}else{
								p.sendMessage(Messages.getInstance().PARTY_YOU_IS_ALREADY_IN_PARTY);
							}
						}else{
							p.sendMessage(Messages.getInstance().PARTY_INVITER_IS_OFFLINE.replace("<inviter>", args[1]));
						}
					}else{
						p.sendMessage(Messages.getInstance().PARTY_INCORRECT_ARGS);
					}
				}else if(args[0].equalsIgnoreCase("kick")){
					if(args.length==2){
						PartyManager party=PartyManager.getParty(p);
						if(party!=null){
							if(party.getOwner().equals(p)){
								Player p2=Bukkit.getPlayerExact(args[1]);
								if(p2!=null&&p2.isOnline()){
									if(p2!=p&&party.getMembers().contains(p2)){
										party.removePlayer(p2);
										p.sendMessage(Messages.getInstance().PARTY_KICKED_PLAYER.replace("<player>", p2.getName()));
										p2.sendMessage(Messages.getInstance().PARTY_KICKED_BY.replace("<player>", p.getName()));
										if(party.getMembers().size()>1){
											for(Player ps:party.getMembers())
												if(ps!=p)
													ps.sendMessage(Messages.getInstance().PARTY_MEMBER_KICKED.replace("<leader>", p.getName()).replace("<player>", p2.getName()));
										}else{
											PartyManager.getPartys().remove(party);
											p.sendMessage(Messages.getInstance().PARTY_NEED_PLAYERS);
										}
									}else{
										if(p2==p)
											p.sendMessage(Messages.getInstance().PARTY_CANT_REMOVE_YOURSELF);
										else p.sendMessage(Messages.getInstance().PARTY_PLAYER_NOT_IS_IN_YOUR_PARTY.replace("player", p2.getName()));
									}
								}else{
									p.sendMessage(Messages.getInstance().PARTY_REMOVED_PLAYER_OFFLINE.replace("<player>", args[1]));
								}
							}else{
								p.sendMessage(Messages.getInstance().PARTY_ONLY_LEADER.replace("<player>", party.getOwner().getName()));
							}
						}else{
							p.sendMessage(Messages.getInstance().PARTY_YOU_IS_NOT_IN_PARTY);
						}
					}else{
						p.sendMessage(Messages.getInstance().PARTY_INCORRECT_ARGS);
					}
				}else if(args[0].equalsIgnoreCase("leave")){
					PartyManager party=PartyManager.getParty(p);
					if(party!=null){
						party.removePlayer(p);
						if(party.getMembers().size()<=1){
							if(party.getMembers().size()==1){
								p.sendMessage(Messages.getInstance().PARTY_YOU_HAS_LEFT.replace("<player>", party.getOwner().getName()));
								for(String list : Messages.getInstance().PARTY_DISBANDED){
									list = ChatColor.translateAlternateColorCodes('&', list);
									party.getOwner().sendMessage(list.replace("<player>", p.getName()));
								}
							}else p.sendMessage(Messages.getInstance().PARTY_DISBANDED_OTHER_REASON);
							
						}else
							for(Player ps:party.getMembers())
								ps.sendMessage(Messages.getInstance().PARTY_PLAYER_LEFT.replace("<player>", p.getName()));
						        
					}else{
						p.sendMessage(Messages.getInstance().PARTY_YOU_NOT_HAVE_PARTY);
					}
				}else if(args[0].equalsIgnoreCase("chat")){
                   PartyManager party = PartyManager.getParty(p);
                   if(party != null){
                	   if(!party.hasChat(p)){
                		   party.addChat(p);
                		   p.sendMessage(Messages.getInstance().PARTY_JOINED_CHAT);
                	   }
                	   if(party.hasChat(p)){
                		   party.removeChat(p);
                		   p.sendMessage(Messages.getInstance().PARTY_LEAVED_CHAT);
                	   }
                   }else{
                	   p.sendMessage(Messages.getInstance().PARTY_YOU_IS_NOT_IN_PARTY);
                   }
				}else if(args[0].equalsIgnoreCase("help")){
					for(String list : Messages.getInstance().PARTY_COMMAND){
						list = ChatColor.translateAlternateColorCodes('&', list);
						p.sendMessage(list);
					}
				}
			}
		}
		return false;
	}
}
