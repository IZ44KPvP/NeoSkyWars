package net.iz44kpvp.neoskywars.utils;

import org.bukkit.ChatColor;

public interface ColoredTexts
{
    public static final String white = ChatColor.WHITE.toString();
    public static final String black = ChatColor.BLACK.toString();
    public static final String green = ChatColor.GREEN.toString();
    public static final String red = ChatColor.RED.toString();
    public static final String purple = ChatColor.LIGHT_PURPLE.toString();
    public static final String blue = ChatColor.BLUE.toString();
    public static final String gray = ChatColor.GRAY.toString();
    public static final String yellow = ChatColor.YELLOW.toString();
    public static final String gold = ChatColor.GOLD.toString();
    public static final String aqua = ChatColor.AQUA.toString();
    public static final String bold = ChatColor.BOLD.toString();
    public static final String reset = ChatColor.RESET.toString();
    public static final String magic = ChatColor.MAGIC.toString();
    public static final String italic = ChatColor.ITALIC.toString();
    public static final String underline = ChatColor.UNDERLINE.toString();
    public static final String strikethroug = ChatColor.STRIKETHROUGH.toString();
    public static final String darkGreen = ChatColor.DARK_GREEN.toString();
    public static final String darkPurple = ChatColor.DARK_PURPLE.toString();
    public static final String darkRed = ChatColor.DARK_RED.toString();
    public static final String darkBlue = ChatColor.DARK_BLUE.toString();
    public static final String darkGray = ChatColor.DARK_GRAY.toString();
    public static final String darkAqua = ChatColor.DARK_AQUA.toString();
}
