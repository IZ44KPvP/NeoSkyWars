package net.iz44kpvp.neoskywars.utils;

import java.util.List;

public class Comparator implements java.util.Comparator<String>
{
    List<String> strings;
    
    public Comparator(final List<String> strings) {
        this.strings = null;
        this.strings = strings;
    }
    
    @Override
    public int compare(final String a, final String b) {
        final int valA = Integer.parseInt(a.split(" ")[1]);
        final int valB = Integer.parseInt(b.split(" ")[1]);
        return Integer.compare(valA, valB);
    }
}
