package net.iz44kpvp.neoskywars.utils;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class LobbyPlayer
{
    private Player player;
    private ItemStack hat;
    private boolean viewPlayers;
    
    public LobbyPlayer(final Player p) {
        this.viewPlayers = true;
        this.player = p;
    }
    
    public void setCanViewPlayers(final boolean value) {
        this.viewPlayers = value;
    }
    
    public void setHat(final ItemStack item) {
        this.hat = item;
        this.player.getInventory().setHelmet(item);
        this.player.updateInventory();
    }
    
    public void removeHat() {
        if (this.player.getInventory().getArmorContents()[3].equals((Object)this.hat)) {
            this.player.getInventory().setHelmet((ItemStack)null);
        }
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    public ItemStack getHat() {
        return this.hat;
    }
        public boolean canViewPlayers() {
        return this.viewPlayers;
    }
}
