package net.iz44kpvp.neoskywars.utils;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public abstract class Menu
{
    public Inventory inv;
    
    public Menu(final String name, final int size) {
        this.inv = Bukkit.createInventory((InventoryHolder)null, size, name);
    }
    
    public Menu(final String name, final InventoryType type) {
        this.inv = Bukkit.createInventory((InventoryHolder)null, type, name);
    }
    
    public abstract void registerItems();
    
    public abstract void registerItems(final Player p0);
    
    public abstract void click(final ItemStack p0, final Player p1);
}
