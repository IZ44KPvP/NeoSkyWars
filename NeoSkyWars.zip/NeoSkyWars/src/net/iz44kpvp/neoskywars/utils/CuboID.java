package net.iz44kpvp.neoskywars.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.entity.Player;

public class CuboID implements Iterable<Block>, Cloneable, ConfigurationSerializable
{
    World world;
    int xmax;
    int xmin;
    int ymax;
    int ymin;
    int zmax;
    int zmin;
    
    public CuboID(final CuboID cuboid) {
        this.world = cuboid.getWorld();
        this.xmax = cuboid.getXmax();
        this.xmin = cuboid.getXmin();
        this.ymax = cuboid.getYmax();
        this.ymin = cuboid.getYmin();
        this.zmax = cuboid.getZmax();
        this.zmin = cuboid.getZmin();
    }
    
    public CuboID(final Location l1, final Location l2) throws Exception {
        if (l1.getWorld().getName().equals(l2.getWorld().getName())) {
            this.world = l1.getWorld();
            this.xmax = Math.max(l1.getBlockX(), l2.getBlockX());
            this.xmin = Math.min(l1.getBlockX(), l2.getBlockX());
            this.ymax = Math.max(l1.getBlockY(), l2.getBlockY());
            this.ymin = Math.min(l1.getBlockY(), l2.getBlockY());
            this.zmax = Math.max(l1.getBlockZ(), l2.getBlockZ());
            this.zmin = Math.min(l1.getBlockZ(), l2.getBlockZ());
            return;
        }
        throw new Exception("Nao e possivel criar cuboid com localizacoes de mundos diferentes");
    }
    
    public CuboID(final int xmax, final int xmin, final int ymax, final int ymin, final int zmax, final int zmin, final World world) {
        this.world = world;
        this.xmax = xmax;
        this.xmin = xmin;
        this.ymax = ymax;
        this.ymin = ymin;
        this.zmax = zmax;
        this.zmin = zmin;
    }
    
    
    public CuboID(final Map<String, Object> map) {
        this.xmax = (int) map.get("xmax");
        this.xmin = (int) map.get("xmin");
        this.ymax = (int) map.get("ymax");
        this.ymin = (int) map.get("ymin");
        this.zmax = (int) map.get("zmax");
        this.zmin = (int) map.get("zmin");
        this.world = Bukkit.getServer().getWorld(map.get("world").toString());
    }
    
    @Override
    public Iterator<Block> iterator() {
        return new CuboidIterator(new CuboID(this.xmax, this.xmin, this.ymax, this.ymin, this.zmax, this.zmin, this.world));
    }
    
    public boolean hasPlayerInside(final Player player) {
        final Location loc = player.getLocation();
        return this.xmin <= loc.getX() && this.xmax >= loc.getX() && this.ymin <= loc.getY() && this.ymax >= loc.getY() && this.zmin <= loc.getZ() && this.zmax >= loc.getX() && this.world.getName().equals(loc.getWorld().getName());
    }
    
    public boolean hasBlockInside(final Block block) {
        final Location loc = block.getLocation();
        return this.xmin <= loc.getX() && this.xmax >= loc.getX() && this.ymin <= loc.getY() && this.ymax >= loc.getY() && this.zmin <= loc.getZ() && this.zmax >= loc.getX() && this.world.getName().equals(loc.getWorld().getName());
    }
    
    public Map<String, Object> serialize() {
        final Map<String, Object> map = new HashMap<String, Object>();
        map.put("world", this.getWorld().toString());
        map.put("xmax", this.getXmax());
        map.put("xmin", this.getXmin());
        map.put("ymax", this.getYmax());
        map.put("ymin", this.getYmin());
        map.put("zmax", this.getZmax());
        map.put("zmin", this.getZmin());
        return map;
    }
    
    public CuboID clone() throws CloneNotSupportedException {
        return new CuboID(this);
    }
    
    public World getWorld() {
        return this.world;
    }
    
    public void setWorld(final World world) {
        this.world = world;
    }
    
    public int getXmax() {
        return this.xmax;
    }
    
    public void setXmax(final int xmax) {
        this.xmax = xmax;
    }
    
    public int getXmin() {
        return this.xmin;
    }
    
    public void setXmin(final int xmin) {
        this.xmin = xmin;
    }
    
    public int getYmax() {
        return this.ymax;
    }
    
    public void setYmax(final int ymax) {
        this.ymax = ymax;
    }
    
    public int getYmin() {
        return this.ymin;
    }
    
    public void setYmin(final int ymin) {
        this.ymin = ymin;
    }
    
    public int getZmax() {
        return this.zmax;
    }
    
    public void setZmax(final int zmax) {
        this.zmax = zmax;
    }
    
    public int getZmin() {
        return this.zmin;
    }
    
    public void setZmin(final int zmin) {
        this.zmin = zmin;
    }
    
    public class CuboidIterator implements Iterator<Block>
    {
        CuboID cci;
        World wci;
        int baseX;
        int baseY;
        int baseZ;
        int sizeX;
        int sizeY;
        int sizeZ;
        private int x;
        private int y;
        private int z;
        ArrayList<Block> blocks;
        Map<Location, Material> blocks2;
        ArrayList<Location> blocks3;
        
        public CuboidIterator(final CuboID c) {
            this.cci = c;
            this.wci = c.getWorld();
            this.baseX = CuboID.this.getXmin();
            this.baseY = CuboID.this.getYmin();
            this.baseZ = CuboID.this.getZmin();
            this.sizeX = Math.abs(CuboID.this.getXmax() - CuboID.this.getXmin()) + 1;
            this.sizeY = Math.abs(CuboID.this.getYmax() - CuboID.this.getYmin()) + 1;
            this.sizeZ = Math.abs(CuboID.this.getZmax() - CuboID.this.getZmin()) + 1;
            final boolean x = false;
            this.z = (x ? 1 : 0);
            this.y = (x ? 1 : 0);
            this.x = (x ? 1 : 0);
        }
        
        @Override
        public boolean hasNext() {
            return this.x < this.sizeX && this.y < this.sizeY && this.z < this.sizeZ;
        }
        
        @Override
        public Block next() {
            final Block b = CuboID.this.world.getBlockAt(this.baseX + this.x, this.baseY + this.y, this.baseZ + this.z);
            if (++this.x >= this.sizeX) {
                this.x = 0;
                if (++this.y >= this.sizeY) {
                    this.y = 0;
                    ++this.z;
                }
            }
            return b;
        }
        
        @Override
        public void remove() {
        }
        
        public Map<Location, Material> getBlockAtLocations() {
            this.blocks2 = new HashMap<Location, Material>();
            for (int x = this.cci.getXmin(); x <= this.cci.getXmax(); ++x) {
                for (int y = this.cci.getYmin(); y <= this.cci.getYmax(); ++y) {
                    for (int z = this.cci.getZmin(); z <= this.cci.getZmax(); ++z) {
                        this.blocks2.put(new Location(this.cci.getWorld(), (double)x, (double)y, (double)z), CuboID.this.getWorld().getBlockAt(x, y, z).getType());
                    }
                }
            }
            return this.blocks2;
        }
        
        public Collection<Location> getLocations() {
            this.blocks3 = new ArrayList<Location>();
            for (int x = this.cci.getXmin(); x <= this.cci.getXmax(); ++x) {
                for (int y = this.cci.getYmin(); y <= this.cci.getYmax(); ++y) {
                    for (int z = this.cci.getZmin(); z <= this.cci.getZmax(); ++z) {
                        this.blocks3.add(new Location(this.wci, (double)x, (double)y, (double)z));
                    }
                }
            }
            return this.blocks3;
        }
        
        public Collection<Block> iterateBlocks() {
            this.blocks = new ArrayList<Block>();
            for (int x = this.cci.getXmin(); x <= this.cci.getXmax(); ++x) {
                for (int y = this.cci.getYmin(); y <= this.cci.getYmax(); ++y) {
                    for (int z = this.cci.getZmin(); z <= this.cci.getZmax(); ++z) {
                        this.blocks.add(this.cci.getWorld().getBlockAt(x, y, z));
                    }
                }
            }
            return this.blocks;
        }
        
        public CuboID getCci() {
            return this.cci;
        }
    }
}
