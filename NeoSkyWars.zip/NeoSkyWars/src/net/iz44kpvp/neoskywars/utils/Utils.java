package net.iz44kpvp.neoskywars.utils;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.Difficulty;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Block;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Villager;
import org.bukkit.entity.Villager.Profession;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import net.iz44kpvp.neoskywars.api.Messages;

public class Utils {

	
	public static void spawnarVillagerArenas(Location local) {
		Villager v = (Villager) Bukkit.getServer().getWorld(local.getWorld().getName()).spawnEntity(local,
				EntityType.VILLAGER);
		v.setCanPickupItems(false);
		v.setAdult();
		v.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 9999999, 255));
		v.setHealth(20);
		v.setCustomName(Messages.getInstance().NPC_ARENAS_DISPLAY);
		v.setProfession(Profession.LIBRARIAN);
		v.setAgeLock(true);
		v.setAge(0);


	}
	
	public static void spawnarVillagerPlay(Location local) {
		Villager v = (Villager) Bukkit.getServer().getWorld(local.getWorld().getName()).spawnEntity(local,
				EntityType.VILLAGER);
		v.setCanPickupItems(false);
		v.setAdult();
		v.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 9999999, 255));
		v.setHealth(20);
		v.setCustomName(Messages.getInstance().NPC_PLAY_DISPLAY);
		v.setProfession(Profession.LIBRARIAN);
		v.setAgeLock(true);
		v.setAge(0);
   

	}
	
	
	public static World createEmptyWorld(String name)
	  {
	    WorldCreator worldCreator = new WorldCreator(name);
	    worldCreator.environment(World.Environment.NORMAL);
	    worldCreator.generateStructures(false);
	    worldCreator.generator(new ChunkGenerator()
	    {
	      public List<BlockPopulator> getDefaultPopulators(World world)
	      {
	        return Arrays.asList(new BlockPopulator[0]);
	      }
	      
	      public boolean canSpawn(World world, int x, int z)
	      {
	        return true;
	      }
	      
	      public byte[] generate(World world, Random random, int x, int z)
	      {
	        return new byte[32768];
	      }
	      
	      public Location getFixedSpawnLocation(World world, Random random)
	      {
	        return new Location(world, 0.0D, 64.0D, 0.0D);
	      }
	    });
	    World world = worldCreator.createWorld();
	    world.setDifficulty(Difficulty.NORMAL);
	    world.setSpawnFlags(true, true);
	    world.setPVP(true);
	    world.setStorm(false);
	    world.setThundering(false);
	    world.setWeatherDuration(2147483647);
	    world.setAutoSave(false);
	    world.setKeepSpawnInMemory(false);
	    world.setTicksPerAnimalSpawns(1);
	    world.setTicksPerMonsterSpawns(1);
	    
	    world.setGameRuleValue("doMobSpawning", "false");
	    world.setGameRuleValue("mobGriefing", "false");
	    world.setGameRuleValue("doFireTick", "false");
	    world.setGameRuleValue("showDeathMessages", "false");
	    
	    Block b = world.getBlockAt(0, 20, 0);
	    b.setType(Material.STONE);
	    
	   
	    
	    return world;
	  }
	
}
