package net.iz44kpvp.neoskywars.utils;

import java.util.List;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;


@SuppressWarnings("all")
public class ItemBuilder
{
    private ItemStack item;
    
    public ItemBuilder(final Material material, final String displayName) {
        this.item = new ItemStack(material);
        final ItemMeta meta = this.item.getItemMeta();
        meta.setDisplayName(displayName);
        this.item.setItemMeta(meta);
    }
    
    public ItemBuilder(final Material material, final String displayName, final int durability) {
        (this.item = new ItemStack(material)).setDurability((short)durability);
        final ItemMeta meta = this.item.getItemMeta();
        meta.setDisplayName(displayName);
        this.item.setItemMeta(meta);
    }
    
    public ItemBuilder(final Material material, final String displayName, final List<String> lore) {
        this.item = new ItemStack(material);
        final ItemMeta meta = this.item.getItemMeta();
        meta.setDisplayName(displayName);
        meta.setLore((List)lore);
        this.item.setItemMeta(meta);
    }
    
    public ItemBuilder(final Material material, final String displayName, final int durability, final List<String> lore) {
        (this.item = new ItemStack(material)).setDurability((short)durability);
        final ItemMeta meta = this.item.getItemMeta();
        meta.setLore((List)lore);
        meta.setDisplayName(displayName);
        this.item.setItemMeta(meta);
    }
    
    public ItemStack getItem() {
        return this.item;
    }
}
