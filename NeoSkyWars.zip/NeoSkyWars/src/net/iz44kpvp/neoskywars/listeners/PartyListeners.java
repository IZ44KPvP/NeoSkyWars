package net.iz44kpvp.neoskywars.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.managers.PartyManager;

public class PartyListeners implements Listener{
		
		
	
	@EventHandler
	private void onChat(AsyncPlayerChatEvent e){
		Player p  = e.getPlayer();
		PartyManager party = PartyManager.getParty(p);
		if(party == null){
			return;
		}
		
		if(!party.hasChat(p)){
			return;
		}
		
		e.setCancelled(true);
		for(Player ps : party.getMembers()){
			ps.sendMessage(Messages.getInstance().PARTY_CHAT_FORMAT.replace("<player>", p.getName()).replace("<message>", e.getMessage()));
		}
		
	}
	
	
	@EventHandler
	private void onLeave(PlayerQuitEvent e){
		Player p=e.getPlayer();
		PartyManager party=PartyManager.getParty(p);
		
		if(p!=null&&party!=null){
			party.removePlayer(p);
			if(party.getMembers().size()<=1){
				Player p2=party.getOwner();
				
				PartyManager.deleteParty(p2);
				p2.sendMessage(Messages.getInstance().PARTY_DISBANDED_PLAYER_HAS_LEFT.replace("<player>", p.getName()));
			}
			if(party.getOwner().getName().equalsIgnoreCase(p.getName())){
				for(Player ps : party.getMembers()){
					ps.sendMessage(Messages.getInstance().PARTY_DISBANDED_LEADER_HAS_LEFT);
				}
			}
		}
	}

}
