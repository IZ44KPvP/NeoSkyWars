package net.iz44kpvp.neoskywars.listeners;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.SettingsManager;
import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.controllers.SignsController;
import net.iz44kpvp.neoskywars.managers.PartyManager;
import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.skywars.SkyWars;

public class SignListeners implements Listener
{
    public List<SignsController> signs;

    
    public SignListeners() {
        this.signs = new ArrayList<SignsController>();
        for (final String key : SettingsManager.getSigns().getKeys("lobbys.signs")) {
            final Location loc = SettingsManager.getSigns().loadLocation(SettingsManager.getSigns().get("lobbys.signs." + key + ".location"));
            if (loc.getBlock() == null || !(loc.getBlock().getState() instanceof Sign)) {
                SettingsManager.getSigns().set(key, null);
                SettingsManager.getSigns().save();
                System.err.println("Broken sign removed in " + loc + ".");
            }
            else if (SettingsManager.getSigns().get("lobbys.signs." + key).getString("mode") == null || SettingsManager.getSigns().get("lobbys.signs." + key).getString("type") == null) {
                SettingsManager.getSigns().set(key, null);
                SettingsManager.getSigns().save();
                System.err.println("Loaded sign in " + loc + ".");
            }
            else {
                this.signs.add(new SignsController(loc, SkyWars.GameMode.valueOf(SettingsManager.getSigns().get("lobbys.signs." + key).getString("mode")), SkyWars.ChestType.valueOf(SettingsManager.getSigns().get("lobbys.signs." + key).getString("type"))));
            }
        }
        new BukkitRunnable() {
            public void run() {
                for (final SignsController sign : SignListeners.this.signs) {
                    sign.update();
                }
            }
        }.runTaskTimer((Plugin)Main.getInstance(), 0L, 20L);
        
        
        
    }
    
    
    public void addNewSign(final SignsController sign) {
        this.signs.add(sign);
        if (!SettingsManager.getSigns().contains("lobbys.signs")) {
            SettingsManager.getSigns().createSection("lobbys.signs");
        }
        SettingsManager.getSigns().saveLocation(SettingsManager.getSigns().createSection("lobbys.signs." + SettingsManager.getSigns().get("lobbys.signs").getKeys(false).size()), sign.getLocation(), sign.getMode(), sign.getType());
        SettingsManager.getSigns().save();
    }
    
    @EventHandler
    private void onSignChange(final SignChangeEvent e) {
    	Player p = e.getPlayer();
    
         	if(e.getLine(0).contains("&")){
         		e.getLine(0).replaceAll("&", "�");
         	}
         	if(e.getLine(1).contains("&")){
         		e.getLine(1).replaceAll("&", "�");
         	}
         	if(e.getLine(2).contains("&")){
         		e.getLine(2).replaceAll("&", "�");
         	}
         	if(e.getLine(3).contains("&")){
         		e.getLine(3).replaceAll("&", "�");
         	}
    	
        if (e.getLine(1) != null && e.getLine(0) != null && e.getLine(2) != null && e.getLine(3) != null && e.getLine(0).equalsIgnoreCase("[SkyWars]")) {
            if (e.getLine(1).equalsIgnoreCase("solo") && e.getLine(2).equalsIgnoreCase("global") && e.getLine(3).equalsIgnoreCase("normal")) {
                final SignsController sign = new SignsController(e.getBlock().getLocation(), SkyWars.GameMode.SOLO, SkyWars.ChestType.NORMAL);
                this.addNewSign(sign);
            }
            else if (e.getLine(1).equalsIgnoreCase("solo") && e.getLine(2).equalsIgnoreCase("global") && e.getLine(3).equalsIgnoreCase("insane")) {
                final SignsController sign = new SignsController(e.getBlock().getLocation(), SkyWars.GameMode.SOLO, SkyWars.ChestType.INSANE);
                this.addNewSign(sign);
            }
            else if (e.getLine(1).equalsIgnoreCase("team") && e.getLine(2).equalsIgnoreCase("global") && e.getLine(3).equalsIgnoreCase("normal")) {
                final SignsController sign = new SignsController(e.getBlock().getLocation(), SkyWars.GameMode.TEAM, SkyWars.ChestType.NORMAL);
                this.addNewSign(sign);
            }
            else if (e.getLine(1).equalsIgnoreCase("team") && e.getLine(2).equalsIgnoreCase("global") && e.getLine(3).equalsIgnoreCase("insane")) {
                final SignsController sign = new SignsController(e.getBlock().getLocation(), SkyWars.GameMode.TEAM, SkyWars.ChestType.INSANE);
                this.addNewSign(sign);
            }else if (e.getLine(1).equalsIgnoreCase("mega") && e.getLine(2).equalsIgnoreCase("global") && e.getLine(3).equalsIgnoreCase("mega")) {
                final SignsController sign = new SignsController(e.getBlock().getLocation(), SkyWars.GameMode.MEGA, SkyWars.ChestType.MEGA);
                this.addNewSign(sign);
            }
            else if (e.getLine(1).equalsIgnoreCase("mega") && e.getLine(2).equalsIgnoreCase("global")) {
                final SignsController sign = new SignsController(e.getBlock().getLocation(), SkyWars.GameMode.MEGA, SkyWars.ChestType.MEGA);
                this.addNewSign(sign);
            }
            else{
            	e.setLine(0, null);
            	e.setLine(2, null);
            	e.setLine(1, "�e�lInvalid Type");
            	e.setLine(3, null);
            	p.sendMessage("�eThis sign type not exists");
            }
        }
    }
    
   
	@EventHandler
    private void onPlayerInteract(final PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
    	boolean leader = false;
        final Block block = e.getClickedBlock();
        if (block.getType() != Material.SIGN && block.getType() != Material.WALL_SIGN && block.getType() != Material.SIGN_POST) {
            return;
        }
        e.setCancelled(false);
        for (final SignsController sign : this.signs) {
            if (sign.getLocation().equals((Object)block.getLocation())) {
                final SkyWars highest = getOrganizedFromPlayers(sign.getMode(), sign.getType());
                if (highest == null) {
                	e.getPlayer().sendMessage(Messages.getInstance().SW_SIGN_NOT_HAVEROOM_AVAIBLE);
                	return;
                }
                PartyManager p = PartyManager.getParty(e.getPlayer());
                
                if(p != null){
                	if(p.getOwner().getName().equalsIgnoreCase(e.getPlayer().getName())){
                		highest.addPlayer(e.getPlayer());
                		e.getPlayer().sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
                		leader = true;
                	}else{
                		e.getPlayer().sendMessage(Messages.getInstance().PARTY_YOU_IS_NOT_LEADER);
                		leader = false;
                	}
                }else{
                	highest.addPlayer(e.getPlayer());
                	e.getPlayer().sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
                }
                sign.update();
                if(p == null){
                	return;
                }
                for(Player member : p.getMembers()){
                	if(member != null){
                		if(member != e.getPlayer()){
                			if(leader){
                				if(SkyWarsManager.getInstance().getSkyWars(member) != null){
                					SkyWars sw = SkyWarsManager.getInstance().getSkyWars(member);
                						sw.removePlayerSilent(member);
                				}
                				member.sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
                        		highest.addPlayer(member);
                			}
                		}
                	}
                }
                
            }
        }
        
        
    }
	

    public static SkyWars getOrganizedFromPlayers(final SkyWars.GameMode mode, final SkyWars.ChestType chestType) {
        try {
            final List<String> a = new ArrayList<String>();
            for (final SkyWars sw : SkyWarsManager.getInstance().getSkyWars()) {
                if(sw.getState() == SkyWars.GameState.WAITING && sw.getMode() == mode && sw.getChestType() == chestType && sw.getMaxPlayers() > sw.getPlayers().length && sw.getPlayers().length >= 1){
                	a.add(String.valueOf(sw.getID()));
                }else if(sw.getState() == SkyWars.GameState.WAITING && sw.getMode() == mode && sw.getChestType() == chestType && sw.getMaxPlayers() > sw.getPlayers().length) {
                    a.add(String.valueOf(sw.getID()));
                }
            }
		
            return SkyWarsManager.getInstance().getSkyWars(a.get(0).split(" ")[0]);
           
        }
        catch (Exception e) {
            return null;
        }
    }

}
