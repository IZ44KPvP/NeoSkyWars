package net.iz44kpvp.neoskywars.listeners;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.controllers.KitController;
import net.iz44kpvp.neoskywars.player.storage.Stats;

public class KitsListeners implements Listener{

	
	
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onClick(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();
		ItemStack stack = e.getCurrentItem();	
		if(!e.getInventory().getName().equalsIgnoreCase("Kits")){
			return;
		}
		for(KitController kit : KitController.getKits().keySet()){
			if(stack.getTypeId() == kit.getIcon().getTypeId()){
				
				// Correct next!
				if(kit.getCost() >= 1 && kit.getPermission()!= null){
					if(p.hasPermission(kit.getPermission())){
				
					p.sendMessage(Messages.getInstance().KIT_ALREADY_PURSHASED.replaceAll("<kit>", kit.getName()));
					p.closeInventory();
					
					}else {
					 String executeTransaction = Main.kits.getConfig().getString("command_buy").replaceAll("<player>", p.getName()).replaceAll("<perm>", kit.getPermission());
					 if(Stats.getCoins(p) >= kit.getCost()){
		
					 Bukkit.getServer().dispatchCommand(Bukkit.getServer().getConsoleSender(), executeTransaction);
					 Stats.removeCoins(p, (int) kit.getCost());

					
					 p.sendMessage(Messages.getInstance().KIT_PURSHASED.replaceAll("<kit>", kit.getName()));
					   p.closeInventory();
					 }else {
						p.sendMessage(Messages.getInstance().KIT_NOT_ENOUGHT_MONEY.replaceAll("<cost>", ""+kit.getCost()));
					   p.closeInventory();
					   }
					}
					}else {
					p.sendMessage(Messages.getInstance().KIT_ALREADY_PURSHASED.replaceAll("<kit>", kit.getName()));
					p.closeInventory();
					
				
				}
			}
			p.closeInventory();
		}
		
	}
	
	

	@SuppressWarnings("deprecation")
	@EventHandler
	public void onClick2(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();
		ItemStack stack = e.getCurrentItem();
		if(!e.getInventory().getName().equalsIgnoreCase(Main.kits.get("menu_name"))){
			return;
		}
		for(KitController kit : KitController.getKits().keySet()){
			if(stack.getTypeId() == kit.getIcon().getTypeId()){
				
				// Correct next!
				
				if(kit.getCost() >= 1 && kit.getPermission()!= null){
					if(p.hasPermission(kit.getPermission())){
					kit.setKit(p);
					p.sendMessage(Messages.getInstance().SKYWARS_KITSELECTED.replaceAll("<kit>", kit.getName()));
					}else {
					 String executeTransaction = Main.kits.getConfig().getString("command_buy").replaceAll("<player>", p.getName()).replaceAll("<perm>", kit.getPermission());
					 if(Stats.getCoins(p) >= kit.getCost()){
					 kit.setKit(p);
					 Bukkit.getServer().dispatchCommand(Bukkit.getServer().getConsoleSender(), executeTransaction);
					 Stats.removeCoins(p, (int) kit.getCost());

					 p.sendMessage(Messages.getInstance().KIT_PURSHASED.replaceAll("<kit>", kit.getName()));
					 p.sendMessage(Messages.getInstance().SKYWARS_KITSELECTED.replaceAll("<kit>", kit.getName()));
					 }else {
						p.sendMessage(Messages.getInstance().KIT_NOT_ENOUGHT_MONEY.replaceAll("<kit>", ""+kit.getCost()));
					}
					}
				}else {
					kit.setKit(p);
					p.sendMessage(Messages.getInstance().SKYWARS_KITSELECTED.replaceAll("<kit>", kit.getName()));
				}
			}
			p.closeInventory();
		}
		
	}
	
	
}
