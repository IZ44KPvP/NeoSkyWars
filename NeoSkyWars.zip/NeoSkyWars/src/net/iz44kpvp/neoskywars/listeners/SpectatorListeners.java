package net.iz44kpvp.neoskywars.listeners;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockCanBuildEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.event.vehicle.VehicleEnterEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.skywars.SkyWars;

public class SpectatorListeners implements Listener{

	
	
	@EventHandler
	private void onAsyncChatEvent(AsyncPlayerChatEvent e){
		Player p = e.getPlayer();
		
		SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
		
		if(sw == null){
			return;
		}
		if(SkyWars.spectador.contains(p)){
			e.setCancelled(true);
			for(Player ps : SkyWars.spectador){
			    if(sw.hasPlayer(ps)){
			    	ps.sendMessage(Messages.getInstance().CHAT_SKYWARS_SPECT_FORMAT.replace("<player>", p.getName()).replace("<message>", e.getMessage()));
			    }
			}
		}
		
	}
	
	@EventHandler
	protected void onBlockCanBuild(BlockCanBuildEvent e) {
		if (!e.isBuildable()) {
			
			
			Location blockL = e.getBlock().getLocation();
			
			boolean allowed = false;
			
			for (Player target : Bukkit.getOnlinePlayers()) {
				if (target.getWorld().equals(e.getBlock().getWorld())) { 
					Location playerL = target.getLocation();
					
					if (playerL.getX() > blockL.getBlockX()-1 && playerL.getX() < blockL.getBlockX()+1) { 
						if (playerL.getZ() > blockL.getBlockZ()-1 && playerL.getZ() < blockL.getBlockZ()+1) { 
							if (playerL.getY() > blockL.getBlockY()-2 && playerL.getY() < blockL.getBlockY()+1) { 
								if(SkyWars.spectador.contains(target)) allowed = true;
								else {
									allowed = false;
									break;
								}
							}
						}
					}
					
				}
			}
			e.setBuildable(allowed);
		}
	}
	
	
    @EventHandler
    private void onPickUP(PlayerPickupItemEvent e){
    	Player p = e.getPlayer();
    	if(SkyWars.spectador.contains(p)){
    		e.setCancelled(true);
    	}
    	
    }
    
    
    @EventHandler
    private void onBreakBlock(BlockBreakEvent e){
    	Player p = e.getPlayer();
    	
    	if(SkyWars.spectador.contains(p)){
    		e.setCancelled(true);
    	}
    	
    }
    
    
    @EventHandler
    private void onPlaceBlock(BlockPlaceEvent e){
    	Player p = e.getPlayer();
    	
    	if(SkyWars.spectador.contains(p)){
    		e.setCancelled(true);
    	}
 
    }
    
    @EventHandler
    private void onSpectInteract(final PlayerInteractEvent e){
    	Player p = e.getPlayer();
        
    	if(SkyWars.spectador.contains(p)){
    		e.setCancelled(true);
    	}
    	
    }
    
    @EventHandler
    private void onPlayerDropItem(final PlayerDropItemEvent e) {
        if (SkyWars.spectador.contains(e.getPlayer())) {
            e.setCancelled(true);
        }
    }
    
    
    @EventHandler
    private void onHunguer(FoodLevelChangeEvent e){
    	if(!(e.getEntity() instanceof Player)){
    		return;
    	}
    	Player p = (Player) e.getEntity();
    	if(SkyWars.spectador.contains(p)){
    		e.setCancelled(true);
    		p.setFoodLevel(20);
    	}
    }
    
    
    
    @EventHandler
    private void onDamage2(EntityDamageEvent e){
    	if(!(e.getEntity() instanceof Player)){
    		return;
    		
    	}
    	
    	Player p = (Player) e.getEntity();
    	if(SkyWars.spectador.contains(p)){
    		e.setCancelled(true);
    	}
    	
    }
	
	   @EventHandler
	    private void onSpectMoveSkyWarsBorder(PlayerMoveEvent e){
	    	Player p = e.getPlayer();
	    	
	    	SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
	    	if(sw == null){
	    		return;
	    	}
	    	
	    	if(!SkyWars.spectador.contains(p)){
	    		return;
	    	}
	    	
	    	  if(!Main.getPlugin().getConfig().getBoolean("Arena-Border-System")){
	          	return;
	          }
	    	
	    	if(p.getLocation().getBlockX() > sw.getBounds().getXmax()){
	    		p.teleport(sw.getIsland(p).getLocation());
	    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
	    	}
	    	if(p.getLocation().getBlockX() < sw.getBounds().getXmin()){
	    		p.teleport(sw.getIsland(p).getLocation());
	    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
	    	}
	        if(p.getLocation().getBlockY() > sw.getBounds().getYmax()){
	        	p.teleport(sw.getIsland(p).getLocation());
	    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
	    	}
	        if(p.getLocation().getBlockY() < sw.getBounds().getYmin()){
	        	p.teleport(sw.getIsland(p).getLocation());
	    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
	    	}
	    	
	        if(p.getLocation().getBlockZ() > sw.getBounds().getZmax()){
	        	p.teleport(sw.getIsland(p).getLocation());
	    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
	    	}
	    	if(p.getLocation().getBlockZ() < sw.getBounds().getZmin()){
	    		p.teleport(sw.getIsland(p).getLocation());
	    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
	    	}
	    	
	    }
	
	@EventHandler(priority=EventPriority.HIGHEST)
	protected void onBlockPlace(BlockPlaceEvent e) {
		if (SkyWars.spectador.contains(e.getPlayer())) {
			e.setCancelled(true);
		}
		
		Location blockL = e.getBlock().getLocation();

		for (Player target : Bukkit.getOnlinePlayers()) {
			if (SkyWars.spectador.contains(target) && target.getWorld().equals(e.getBlock().getWorld())) {
				Location playerL = target.getLocation();

				if (playerL.getX() > blockL.getBlockX()-1 && playerL.getX() < blockL.getBlockX()+1) {
					if (playerL.getZ() > blockL.getBlockZ()-1 && playerL.getZ() < blockL.getBlockZ()+1) {
						if (playerL.getY() > blockL.getBlockY()-2 && playerL.getY() < blockL.getBlockY()+1) { 
							target.teleport(e.getPlayer(), TeleportCause.PLUGIN);
						}
					}
				}
				
			}
		}
	}
	
	@SuppressWarnings("deprecation")
	@EventHandler
	protected void onEntityDamageEvent(final EntityDamageByEntityEvent e) {		
		
		if(!(e.getEntity() instanceof Player)){
			return;
		}
		
		if(!(e.getDamager() instanceof Player)){
			return;
		}
		

		if (e.getDamager() instanceof Player && e.getEntity() instanceof Player) {
			if ((!e.getDamager().hasMetadata("NPC") && SkyWars.spectador.contains((Player)e.getEntity()) || (!e.getEntity().hasMetadata("NPC") && SkyWars.spectador.contains((Player)e.getEntity())))) {
				e.setCancelled(true);
			}
		
		} else if (!(e.getEntity() instanceof Player) && e.getDamager() instanceof Player) {
			if (!e.getDamager().hasMetadata("NPC") && SkyWars.spectador.contains((Player)e.getEntity()) == true) {
				e.setCancelled(true);
			}

		} else if (e.getEntity() instanceof Player && !(e.getDamager() instanceof Player)) {
			if (!e.getEntity().hasMetadata("NPC") && SkyWars.spectador.contains((Player)e.getEntity()) == true) {
				e.setCancelled(true);
			}
		}
		
		
		if(e.getDamager() instanceof Projectile
				&& !(e.getDamager() instanceof ThrownPotion) 
				&& e.getEntity() instanceof Player
				&& !e.getEntity().hasMetadata("NPC") 
				&& (SkyWars.spectador.contains((Player)e.getEntity()))) {
			
			e.setCancelled(true);
			
			final Player spectatorInvolved = (Player) e.getEntity();
			final boolean wasFlying = spectatorInvolved.isFlying();
			final Location initialSpectatorLocation = spectatorInvolved.getLocation();
			
			final Vector initialProjectileVelocity = e.getDamager().getVelocity();
			final Location initialProjectileLocation = e.getDamager().getLocation();
			
			spectatorInvolved.setFlying(true);
			spectatorInvolved.teleport(initialSpectatorLocation.clone().add(0, 6, 0), TeleportCause.PLUGIN);
			
			Bukkit.getScheduler().runTaskLater(Main.getPlugin(), new BukkitRunnable() {
				@Override
				public void run() {
					e.getDamager().teleport(initialProjectileLocation);
					e.getDamager().setVelocity(initialProjectileVelocity);
				}
			}, 1L);
			

			Bukkit.getScheduler().runTaskLater(Main.getPlugin(), new BukkitRunnable() {
				@Override
				public void run() {
					spectatorInvolved.teleport(new Location(initialSpectatorLocation.getWorld(), initialSpectatorLocation.getX(), initialSpectatorLocation.getY(), initialSpectatorLocation.getZ(), spectatorInvolved.getLocation().getYaw(), spectatorInvolved.getLocation().getPitch()), TeleportCause.PLUGIN);
					spectatorInvolved.setFlying(wasFlying);
				}
			}, 5L);
		}
	}
	
	
	@EventHandler
	public void onVehicleEnter(VehicleEnterEvent e) {
		if(!(e.getEntered() instanceof Player)){
			return;
		}
		if (SkyWars.spectador.contains((Player)e.getEntered())) {
			e.setCancelled(true);
		}
	}
	
	
}
