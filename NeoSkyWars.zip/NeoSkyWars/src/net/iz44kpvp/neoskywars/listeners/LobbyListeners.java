package net.iz44kpvp.neoskywars.listeners;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.kits.ShopKits;
import net.iz44kpvp.neoskywars.lobby.Lobby;
import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.player.storage.Stats;
import net.iz44kpvp.neoskywars.scoreboard.ScoreboardManager;
import net.iz44kpvp.neoskywars.skywars.RewardSummary;
import net.iz44kpvp.neoskywars.utils.ItemBuilder;
import net.iz44kpvp.neoskywars.utils.Menu;

public class LobbyListeners implements Listener
{
	@EventHandler(priority = EventPriority.HIGH)
    private void onPlayerJoin(final PlayerJoinEvent e) {
        e.setJoinMessage(null);
        Player p = e.getPlayer();

        if(Main.getPlugin().getConfig().getBoolean("Auto_Join_Lobby")){
        	
        	
	        for (Player ps : Bukkit.getOnlinePlayers()) {
	            if (Lobby.getInstance().hasPlayer(ps)) {
	                if (!Lobby.getInstance().getPlayer(ps).canViewPlayers()) {
	                    ps.hidePlayer(p);
	                }
	            }
	            else if (SkyWarsManager.getInstance().getSkyWars(ps) != null) {
	                ps.hidePlayer(p);
	                p.hidePlayer(ps);
	            }
	            else if (!ps.canSee(p)) {
	                ps.showPlayer(p);
	            }
	        }
	        if (p.getGameMode() != GameMode.SURVIVAL) {
	            p.setGameMode(GameMode.SURVIVAL);
	        }
	        p.sendMessage(Messages.getInstance().PLAYER_JOINED_SKYWARS_LOBBY);
	        Lobby.getInstance().addPlayer(p);
	        if(ScoreboardManager.getScoreboard(p) == null){
	        	ScoreboardManager.iniciarScoreboardLobby(p);
	        }
	        if (Lobby.getInstance().isLobby()) {
	            p.teleport(Lobby.getInstance().getLobby());
	        } 
        	
        }
        
        Stats.createAccount(p);
    }
	

    
    @EventHandler
    private void onVoid(PlayerMoveEvent e){
    	Player p = e.getPlayer();
    	
    	if(p.getLocation().getBlockY() < 0){
    		if(Lobby.getInstance().hasPlayer(p)){
    			p.teleport(Lobby.getInstance().getLobby());
    		}
    		
    	}
    	
    	
    }
    
    
   
    @EventHandler
    private void onPlayerQuit(final PlayerQuitEvent e) {
        final Player p = e.getPlayer();
        e.setQuitMessage((String)null);
        if (Lobby.getInstance().hasPlayer(p)) {
            Lobby.getInstance().removePlayer(p);
        }
       RewardSummary.getInstance().resetPlayer(p);
       RewardSummary.getInstance().resetPlayerSouls(p);
    }
    
    
    public static void openInv(Player p)
    {
  	  Inventory inv = Bukkit.createInventory(p, 9, Main.items.get("Lobby.Inventories.Stats.Name"));
  	  ArrayList<String> lore = new ArrayList<>();
     for(String list: Main.items.getConfig().getStringList("Lobby.Inventories.Stats.Item.Lore")){
    	 lore.add(list.replace("&", "�").replace("%coins%", String.valueOf(Stats.getCoins(p))).replace("%souls%", String.valueOf(Stats.getSouls(p))).replace("%wins%", String.valueOf(Stats.getWins(p))).replace("%kills%", String.valueOf(Stats.getKills(p))).replace("%deaths%", String.valueOf(Stats.getDeaths(p))).replace("%games%", String.valueOf(Stats.getGames(p))));
    	 ItemStack grass = new ItemBuilder(Material.getMaterial(Main.items.getConfig().getString("Lobby.Inventories.Stats.Item.Id")), Main.items.get("Lobby.Inventories.Stats.Item.Name"), lore).getItem();
         inv.setItem(4, grass);
     }
  	  

      p.openInventory(inv);
    }
    

    
    
    @SuppressWarnings("deprecation")
	@EventHandler
    private void onPlayerInteract(final PlayerInteractEvent e) {
        final Player p = e.getPlayer();
        if (Lobby.getInstance().hasPlayer(p)) {
            if (p.getGameMode() != GameMode.CREATIVE) {
                e.setCancelled(true);
            }
            
    		if (p.getItemInHand() == null) return;
    		if (p.getItemInHand().getType() == Material.AIR) return;
    		if (p.getItemInHand().getItemMeta().getDisplayName() == null) return;
            
            if(e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK){
            	if(p.getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase(Main.items.get("Lobby.Items.Stats.Name")) && e.getItem() != null){
                	openInv(p);
                }
            	if(p.getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase(Main.items.get("Lobby.Items.Shop.Name"))){
            		openInventoryShop(p);
            	}
            	if(p.getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase(Main.items.get("Lobby.Items.Selector.Name"))){
            		if(p.hasPermission("skywars.arenaselector")){
            			Lobby.getInstance().getMenu("rooms").registerItems();
                		p.openInventory(Lobby.getInstance().getMenu("rooms").inv);
            		}else{
            			p.sendMessage(Messages.getInstance().ONLY_VIPS_CAN_ACESS);
            		}
            	}
            }
            
         }
    }
    
    private void openInventoryShop(Player p) {
    	ArrayList<String> lore1 = new ArrayList<>();
    	ArrayList<String> lore2 = new ArrayList<>();
		Inventory inv = Bukkit.createInventory(p, 54, Main.items.get("Lobby.Inventories.Shop.Name"));
		for(String list : Main.items.getConfig().getStringList("Lobby.Inventories.Shop.Items.Kits.Lore")){
			lore1.add(list.replace("&", "�"));
		ItemStack grass = new ItemBuilder(Material.getMaterial(Main.items.getConfig().getString("Lobby.Inventories.Shop.Items.Kits.Id")), Main.items.get("Lobby.Inventories.Shop.Items.Kits.Name"), lore1).getItem();
		inv.setItem(31, grass);
		}
		for(String list : Main.items.getConfig().getStringList("Lobby.Inventories.Shop.Items.Coins.Lore")){
			lore2.add(list.replace("&", "�").replace("%coins%", String.valueOf(Stats.getCoins(p))));
			ItemStack emerald = new ItemBuilder(Material.getMaterial(Main.items.getConfig().getString("Lobby.Inventories.Shop.Items.Coins.Id")), Main.items.get("Lobby.Inventories.Shop.Items.Coins.Name"), lore2).getItem();
		     
			inv.setItem(49, emerald);
		}
		
		p.openInventory(inv);
	}

	@EventHandler
    private void onInventoryClickMenus(final InventoryClickEvent e) {
        if (e.getWhoClicked() instanceof Player) {
        	Player p = (Player) e.getWhoClicked();
        	if(!Lobby.getInstance().hasPlayer(p)){
        		return;
        	}
            if (SkyWarsManager.getInstance().getSkyWars((Player)e.getWhoClicked()) == null && ((Player)e.getWhoClicked()).getGameMode() != GameMode.CREATIVE && (e.getSlotType().equals((Object)InventoryType.SlotType.ARMOR) || e.getSlotType().equals((Object)InventoryType.SlotType.CONTAINER) || e.getSlotType().equals((Object)InventoryType.SlotType.QUICKBAR) || e.getSlotType().equals((Object)InventoryType.SlotType.CRAFTING))) {
                e.setCancelled(true);
            }
            if (e.getInventory().getName() != null && e.getCurrentItem() != null) {
                Menu[] menus2;
                for (int length = (menus2 = Lobby.getInstance().getMenus()).length, i = 0; i < length; ++i) {
                    final Menu menus = menus2[i];
                    if (e.getInventory().getTitle().equals(menus.inv.getTitle())) {
                        e.setCancelled(true);
                        menus.click(e.getCurrentItem(), (Player)e.getWhoClicked());
                        break;
                    }
                    if(e.getInventory().getName().equalsIgnoreCase(Main.items.get("Lobby.Inventories.Shop.Name"))){
                    	e.setCancelled(true);
                    	if(e.getCurrentItem() == null)return;
                    	if(!e.getCurrentItem().hasItemMeta())return;
                    	if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Main.items.get("Lobby.Inventories.Shop.Items.Kits.Name"))){
                    	new ShopKits(p).o(p);
                    	}
                    }
                }
            }
        }
    }
    
    @EventHandler
    private void onFoodLevelChange(final FoodLevelChangeEvent e) {
        if (!(e.getEntity() instanceof Player)) {
            return;
        }
        final Player p = (Player)e.getEntity();
        if (Lobby.getInstance().hasPlayer(p)) {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    private void onBlockBreak(final BlockBreakEvent e) {
        final Player p = e.getPlayer();
        if (Lobby.getInstance().hasPlayer(p) && p.getGameMode() != GameMode.CREATIVE) {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    private void onBlockPlace(final BlockPlaceEvent e) {
        final Player p = e.getPlayer();
        if (Lobby.getInstance().hasPlayer(p) && p.getGameMode() != GameMode.CREATIVE) {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    private void onDropItem(final PlayerDropItemEvent e) {
        final Player p = e.getPlayer();
        if (Lobby.getInstance().hasPlayer(p)) {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    private void onPlayerPickUP(PlayerPickupItemEvent e){
    	Player p = e.getPlayer();
    	if(Lobby.getInstance().hasPlayer(p)){
    		e.setCancelled(true);
    	}
    	
    }
    
    
    @EventHandler
    private void onEntityDamage(final EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player)) {
            return;
        }
        final Player p = (Player)e.getEntity();
        if (Lobby.getInstance().hasPlayer(p)) {
            e.setCancelled(true);
        }
    }
}
