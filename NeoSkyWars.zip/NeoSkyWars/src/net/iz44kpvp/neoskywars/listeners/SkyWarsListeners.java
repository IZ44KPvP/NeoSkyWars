package net.iz44kpvp.neoskywars.listeners;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.SettingsManager;
import net.iz44kpvp.neoskywars.api.ActionBar;
import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.controllers.ChatController;
import net.iz44kpvp.neoskywars.kits.KitMenu;
import net.iz44kpvp.neoskywars.lobby.Lobby;
import net.iz44kpvp.neoskywars.managers.PartyManager;
import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.player.SkyPlayer;
import net.iz44kpvp.neoskywars.player.storage.Stats;
import net.iz44kpvp.neoskywars.skywars.RewardSummary;
import net.iz44kpvp.neoskywars.skywars.SkyWars;
import net.iz44kpvp.neoskywars.skywars.SkyWars.GameState;
import net.iz44kpvp.neoskywars.utils.ItemBuilder;
import net.iz44kpvp.neoskywars.utils.LobbyPlayer;

public class SkyWarsListeners implements Listener
{
	
	 @EventHandler
	  private void onPlayerDeath(PlayerDeathEvent e)
	  {
	    final Player p = e.getEntity();
	    e.setDeathMessage(null);
	    SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
	    if (sw != null)
	    {
	    	Stats.addDeaths(p, 1);
	      if ((p.getKiller() instanceof Player))
	      {
	        sw.addKills(p.getKiller());
	        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), Main.extraconfig.getConfig().getString("Console-On-Player-Kill-Command").replace("%killer%", p.getName()));
	        
	       int coins = 0;
	       int souls = 0;
	        
	       
	        Stats.addKills(p.getKiller(), 1);
	        if(p.getKiller().hasPermission("skywars.souls.x5")){
	        	Stats.addSouls(p.getKiller(), 5);
	        	RewardSummary.getInstance().addSouls(p.getKiller(), 5);
	        	souls = 5;
	        }else if(p.getKiller().hasPermission("skywars.souls.x4")){
	        	Stats.addSouls(p.getKiller(), 4);
	        	RewardSummary.getInstance().addSouls(p.getKiller(), 4);
	        	souls = 4;
	        }else if(p.getKiller().hasPermission("skywars.souls.x3")){
	        	Stats.addSouls(p.getKiller(), 3);
	        	RewardSummary.getInstance().addSouls(p.getKiller(), 3);
	        	souls = 3;
	        }else if(p.getKiller().hasPermission("skywars.souls.x2")){
	        	Stats.addSouls(p.getKiller(), 2);
	        	RewardSummary.getInstance().addSouls(p.getKiller(), 2);
	        	souls = 2;
	        }else{
	        	Stats.addSouls(p.getKiller(), 1);
	        	RewardSummary.getInstance().addSouls(p.getKiller(), 1);
	        	souls = 1;
	        }
	        if(p.getKiller().hasPermission("skywars.coins.x5")){
	        	Stats.addCoins(p.getKiller(), Main.getInstance().getConfig().getInt("Settings.points.kill") * 5);
	        	RewardSummary.getInstance().addCoins(p.getKiller(), Main.getInstance().getConfig().getInt("Settings.points.kill") * 5);
	            coins = Main.getInstance().getConfig().getInt("Settings.points.kill") * 5;
	        }else if(p.getKiller().hasPermission("skywars.coins.x4")){
	        	Stats.addCoins(p.getKiller(), Main.getInstance().getConfig().getInt("Settings.points.kill") * 4);
	        	RewardSummary.getInstance().addCoins(p.getKiller(), Main.getInstance().getConfig().getInt("Settings.points.kill") * 4);
	        	coins = Main.getInstance().getConfig().getInt("Settings.points.kill") * 4;
	        }else if(p.getKiller().hasPermission("skywars.coins.x3")){
	        	Stats.addCoins(p.getKiller(), Main.getInstance().getConfig().getInt("Settings.points.kill") * 3);
	        	RewardSummary.getInstance().addCoins(p.getKiller(), Main.getInstance().getConfig().getInt("Settings.points.kill") * 3);
	        	coins = Main.getInstance().getConfig().getInt("Settings.points.kill") * 3;
	        }else if(p.getKiller().hasPermission("skywars.coins.x2")){
	        	Stats.addCoins(p.getKiller(), Main.getInstance().getConfig().getInt("Settings.points.kill") * 2);
	        	RewardSummary.getInstance().addCoins(p.getKiller(), Main.getInstance().getConfig().getInt("Settings.points.kill") * 2);
	        	coins = Main.getInstance().getConfig().getInt("Settings.points.kill") * 2; 
	        }else{
	        	Stats.addCoins(p.getKiller(), Main.getInstance().getConfig().getInt("Settings.points.kill"));
	        	RewardSummary.getInstance().addCoins(p.getKiller(), Main.getInstance().getConfig().getInt("Settings.points.kill"));
	        	coins = Main.getInstance().getConfig().getInt("Settings.points.kill");
	        }
	        ActionBar.sendActionBar(p.getKiller(), "�e+" + coins + " coins," + " �b+" + souls + " souls");
	        p.getKiller().playSound(p.getLocation(), Main.NOTE_PLING, 4.0F, 4.0F);
	      }
	      
	      

	      SkyPlayer[] players2;
	      int length = (players2 = sw.getPlayers()).length;
	      for (int i = 0; i < length; i++)
	      {
	    	  
	        SkyPlayer players = players2[i];
	        if ((p.getKiller() instanceof Player))
	        {
	          if ((p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.PROJECTILE) && (p.getKiller() != null))
	          {
	            players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_PLAYER_ARROW.replace("<player>", p.getName()).replace("<killer>", p.getKiller().getName()));
	          }
	          if ((p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.VOID) && (p.getKiller() != null)) {
	            players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_PLAYER_ON_VOID.replace("<player>", p.getName()).replace("<killer>", p.getKiller().getName()));
	          }else if(p.getKiller() != null){
	        	  players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_PLAYER.replace("<player>", p.getName()).replace("<killer>", p.getKiller().getName()));
	          }
	          
	        }
	        else if (p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION)
	        {
	          players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_EXPLOSION.replace("<player>", p.getName()));
	        }
	        else if (p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.VOID)
	        {
	          players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_VOID.replace("<player>", p.getName()));
	        }
	        else if (p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.SUICIDE)
	        {
	          players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_SUICIDE.replace("<player>", p.getName()));
	        }
	        else if (p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.FALL)
	        {
	          players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_FALL.replace("<player>", p.getName()));
	        }
	        else if (p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.LAVA)
	        {
	          players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_LAVA.replace("<player>", p.getName()));
	        }
	        else if (p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.SUFFOCATION)
	        {
	          players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_SUFFOCATION.replace("<player>", p.getName()));
	        }
	        else if (p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.FALLING_BLOCK)
	        {
	          players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_FALLING_BLOCK.replace("<player>", p.getName()));
	        }
	        else if (p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.DROWNING)
	        {
	          players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_DROWNING.replace("<player>", p.getName()));
	        }
	        else if (p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.LIGHTNING)
	        {
	          players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_LIGHTNING.replace("<player>", p.getName()));
	        }
	        else if (p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.POISON)
	        {
	          players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_POISON.replace("<player>", p.getName()));
	        }
	        else if (p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.MAGIC)
	        {
	          players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_MAGIC.replace("<player>", p.getName()));
	        }
	        else if (p.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK)
	        {
	          players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_ENTITY.replace("<player>", p.getName()));
	        }
	        else
	        {
	          players.getPlayer().sendMessage(Messages.getInstance().SW_PLAYER_DEATH_BY_OUTHER.replace("<player>", p.getName()));
	        }
	      }
            e.setDroppedExp(e.getDroppedExp());
            for(ItemStack items: e.getDrops()){
            	p.getWorld().dropItem(p.getLocation(), items);
            }
            
            e.setKeepInventory(true);
            sw.spectate(p);
            
            int players = 0;
            SkyPlayer[] players21;
            for (int length1 = (players21 = sw.getPlayers()).length, i = 0; i < length1; ++i) {
                final SkyPlayer swp = players21[i];
                if (swp.isAlive()) {
                    ++players;
                }
            }
            
            
  	      for (SkyPlayer ps : sw.getPlayers())
  	      {
  	       ActionBar.sendActionBar(ps.getPlayer(), Messages.getInstance().RESTANT_PLAYERS.replace("<players>", String.valueOf(players)));	     
  	      }
  	     
  	      for(String list : Messages.getInstance().SKYWARS_REWARDS){
  	    	  list = ChatColor.translateAlternateColorCodes('&', list);
  	    	  p.sendMessage(list.replace("<coins>", String.valueOf(RewardSummary.getInstance().getCoins(p))).replace("<souls>", String.valueOf(RewardSummary.getInstance().getSouls(p))));
  	      }
  	      RewardSummary.getInstance().resetPlayer(p);
  	      RewardSummary.getInstance().resetPlayerSouls(p);
  	      
  	      Bukkit.dispatchCommand(Bukkit.getConsoleSender(), Main.extraconfig.getConfig().getString("Console-On-Game-Lose-Command").replace("%loser%", p.getName()));
	    	
          new BukkitRunnable() {
  			
  			@Override
  			public void run() {
  				final ItemStack compass = new ItemBuilder(Material.COMPASS, Messages.getInstance().SW_SPECT_COMPASS_DISPLAY).getItem();
  		        final ItemStack paper = new ItemBuilder(Material.PAPER, Messages.getInstance().SW_PAPER_PLAY_AGAIN_DISPLAY).getItem();
  		        final ItemStack bed = new ItemBuilder(Material.BED, Messages.getInstance().SW_BEDQUIT_DISPLAY).getItem();
  		        p.getInventory().setItem(0, compass);
  		        p.getInventory().setItem(4, paper);
  		        p.getInventory().setItem(8, bed);
  		        ChatController.runCommand(p, Messages.getInstance().CHAT_PLAY_AGAIN, "/sw playagain", Messages.getInstance().CHAT_PLAY_AGAIN_LORE);
  				
  			}
  		}.runTaskLater(Main.getPlugin(), 20*2);

	    }
	    

	    
	  }
		

    
    @EventHandler
    private void onStopClickEventOnSkyWarsArena(InventoryClickEvent e){
    	Player p = (Player) e.getWhoClicked();
    	SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
    	if(sw == null){
    		return;
    	}
    	
    	if(sw.getState() != GameState.WAITING){
    		return;
    	}
    	e.setCancelled(true);
    	
    }
    
    @EventHandler
    private void onMoveSkyWarsBorder(PlayerMoveEvent e){
    	Player p = e.getPlayer();
    	
    	SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
    	if(sw == null){
    		return;
    	}
    	
        if(!Main.getPlugin().getConfig().getBoolean("Arena-Border-System")){
        	return;
        }
        
        if(SkyWars.spectador.contains(p)){
        	return;
        }
    	
    	if(p.getLocation().getBlockX() > sw.getBounds().getXmax()){
    		p.setHealth(0);
    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
    	}
    	if(p.getLocation().getBlockX() < sw.getBounds().getXmin()){
    		p.setHealth(0);
    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
    	}
        if(p.getLocation().getBlockY() > sw.getBounds().getYmax()){
        	p.setHealth(0);
    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
    	}
        if(p.getLocation().getBlockY() < sw.getBounds().getYmin()){
        	p.setHealth(0);
    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
    	}
    	
        if(p.getLocation().getBlockZ() > sw.getBounds().getZmax()){
        	p.setHealth(0);
    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
    	}
    	if(p.getLocation().getBlockZ() < sw.getBounds().getZmin()){
    		p.setHealth(0);
    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
    	}
    	
    }
    
    
    @EventHandler
    private void onSpectMoveBorder(PlayerMoveEvent e){
    	Player p = e.getPlayer();
    	
    	SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
    	if(sw == null){
    		return;
    	}
    	
        if(!Main.getPlugin().getConfig().getBoolean("Arena-Border-System")){
        	return;
        }
        
    	if(!SkyWars.spectador.contains(p)){
    		return;
    	}
        
    	if(p.getLocation().getBlockX() > sw.getBounds().getXmax()){
    		p.teleport(sw.getIsland(p).getLocation());
    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
    	}
    	if(p.getLocation().getBlockX() < sw.getBounds().getXmin()){
    		p.teleport(sw.getIsland(p).getLocation());
    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
    	}
        if(p.getLocation().getBlockY() > sw.getBounds().getYmax()){
        	p.teleport(sw.getIsland(p).getLocation());
    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
    	}
        if(p.getLocation().getBlockY() < sw.getBounds().getYmin()){
        	p.teleport(sw.getIsland(p).getLocation());
    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
    	}
    	
        if(p.getLocation().getBlockZ() > sw.getBounds().getZmax()){
        	p.teleport(sw.getIsland(p).getLocation());
    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
    	}
    	if(p.getLocation().getBlockZ() < sw.getBounds().getZmin()){
    		p.teleport(sw.getIsland(p).getLocation());
    		p.sendMessage(Messages.getInstance().SKYWARS_BORDER_ULTRAPASSED);
    	}
    	
    }
    
    @EventHandler
    private void onPlayerInteract(final PlayerInteractEvent e) {
         Player p = e.getPlayer();
         boolean leader = false;
        final ItemStack item = e.getItem();
        if (item == null) {
            return;
        }
        if (SkyWarsManager.getInstance().getSkyWars(p) == null) {
            return;
        }
        if (SkyWarsManager.getInstance().getSkyWars(p).getState() == SkyWars.GameState.STARTED) {
            if (!SkyWarsManager.getInstance().getSkyWars(p).getPlayer(p).isAlive()) {
                if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) {
                    return;
                }
                e.setCancelled(true);
                if (item.getType() == Material.PAPER) {
                    final SkyWars highest = SignListeners.getOrganizedFromPlayers(SkyWarsManager.getInstance().getSkyWars(p).getMode(), SkyWarsManager.getInstance().getSkyWars(p).getChestType());
                    if (highest != null) {
                        PartyManager p1 = PartyManager.getParty(e.getPlayer());
                        SkyWars sw1 = SkyWarsManager.getInstance().getSkyWars(p);
                       
                        
                        if(p1 != null){
                        	if(p1.getOwner().getName().equalsIgnoreCase(e.getPlayer().getName())){
                        		 sw1.removePlayerSilent(p);
                        		highest.addPlayer(e.getPlayer());
                        		
                        		e.getPlayer().sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
                        		leader = true;
                        	}else{
                        		e.getPlayer().sendMessage(Messages.getInstance().PARTY_YOU_IS_NOT_LEADER);
                        		leader = false;
                        	}
                        }else{
                        	 sw1.removePlayerSilent(p);
                        	highest.addPlayer(e.getPlayer());
                        	e.getPlayer().sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
                        }
                        if(p1 == null){
                        	return;
                        }
                        for(Player member : p1.getMembers()){
                        	if(member != null){
                        		if(member != e.getPlayer()){
                        			if(leader){
                        				if(SkyWarsManager.getInstance().getSkyWars(member) != null){
                        					SkyWars sw = SkyWarsManager.getInstance().getSkyWars(member);
                        						sw.removePlayerSilent(member);
                        				}
                        				member.sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
                                		highest.addPlayer(member);
                        			}
                        		}
                        	}
                        }
                        
                    }
                    else {
                        e.getPlayer().sendMessage(Messages.getInstance().SW_SIGN_NOT_HAVEROOM_AVAIBLE);
                    }
                }
                else if (item.getType() == Material.BED) {
                    SkyWarsManager.getInstance().getSkyWars(p).removePlayerSilent(p);
                }
                else if (item.getType() == Material.COMPASS) {
                    Lobby.getInstance().getMenu("spect").registerItems(p);
                }
            }
            return;
        }
        if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            e.setCancelled(true);
            if (item.getType() == Material.BED) {
                e.setCancelled(true);
                SkyWarsManager.getInstance().getSkyWars(p).removePlayer(p);
            }
            else if (item.getType() == Material.BOW) {
                e.setCancelled(true);
                new KitMenu(p).o(p);
            }
            
           if(item.getType() == Material.BLAZE_POWDER){
        	   e.setCancelled(true);
        	   p.sendMessage(Messages.getInstance().MESSAGE_COMING_SOON);;
           }
        }
     

        
        
    }
      
 
    
    @SuppressWarnings("deprecation")
	@EventHandler
    private void onClickChest(BlockBreakEvent e){
     Player p = e.getPlayer();
     SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
     
     if(sw != null){
    	 return;
     }
     
    
		if (p.getItemInHand() == null) return;
		if (p.getItemInHand().getType() == Material.AIR) return;
		if (p.getItemInHand().getItemMeta().getDisplayName() == null) return;
     
     if(p.getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase("�aChest Normal")){
       
    	   final SkyWars sw1 = SkyWarsManager.getInstance().getSkyWars(p.getWorld().getName());
           if (sw1 != null) {
               final Block target = e.getBlock();
               if (target != null && target.getState() instanceof Chest || target != null && target.getState().getType() == Material.TRAPPED_CHEST) {
                   final Chest chest = (Chest)target.getState();
                   if (p.hasPermission("skywars.setchests")) {
                       final SettingsManager sm = sw1.getConfig();
                       if (!sm.contains("chests")) {
                           sm.createSection("chests");
                       }
                       sm.saveLocation(sm.createSection("chests." + sm.get("chests").getKeys(false).size()), chest.getLocation(), false, null);
                       sm.save();
                       p.sendMessage(Messages.getInstance().COMMAND_SWCHEST_SUCESS);
                       e.setCancelled(true);

                   }
                   else {
                       p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
                   }
               }
               else {
                   p.sendMessage(Messages.getInstance().COMMAND_SWCHEST_NOTCHEST);
                   e.setCancelled(true);
               }
           }
           else {
               p.sendMessage(Messages.getInstance().COMMAND_SW_NOTFOUND);
           }
       

      

     }
     
     if(p.getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase("�aChest Feast")){
      
       
          final SkyWars sw1 = SkyWarsManager.getInstance().getSkyWars(p.getWorld().getName());
          if (sw1 != null) {
              final Block target = e.getBlock();
              if (target != null && target.getState() instanceof Chest || target != null && target.getState().getType() == Material.TRAPPED_CHEST) {
                  final Chest chest = (Chest)target.getState();
                  if (p.hasPermission("skywars.setchests")) {

                      final SettingsManager sm = sw1.getConfig();
              
                      if (!sm.contains("feastchests")) {
                          sm.createSection("feastchests");
                      }
                      sm.saveLocation(sm.createSection("feastchests." + sm.get("feastchests").getKeys(false).size()), chest.getLocation(), false, null);
                      sm.save();
                      p.sendMessage(Messages.getInstance().COMMAND_SWCHEST_SUCESS);
                      e.setCancelled(true);
                  }
                  else {
                      p.sendMessage(Messages.getInstance().NOT_HAVE_PERMISSION);
                  }
              }
              else {
                  p.sendMessage(Messages.getInstance().COMMAND_SWCHEST_NOTCHEST);
                  e.setCancelled(true);
              }
          }
          else {
              p.sendMessage(Messages.getInstance().COMMAND_SW_NOTFOUND);
          }
       
      

     }
     
    }
    
    
    @EventHandler
    private void onPlayerQuit(final PlayerQuitEvent e) {
        final Player p = e.getPlayer();
        final SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
        if(sw==null){
        	return;
        }
        if(sw.hasPlayer(p)){
        	sw.removePlayer(p);
        }
    }
    
    @EventHandler
    private void onPlayerDropItem(final PlayerDropItemEvent e) {
        final Player p = e.getPlayer();
        final SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
        if (sw != null) {
            if (sw.getState() != SkyWars.GameState.STARTED) {
                e.setCancelled(true);
            }
        }
    }
    
    @EventHandler
    private void onPlayerChat(final AsyncPlayerChatEvent e) {
        final Player p = e.getPlayer();
        
        if(!Main.getInstance().getConfig().getBoolean("Custom-Chat-By-This-Plugin")){
        	return;
        }
        
        final SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
        if (sw == null && Lobby.getInstance().hasPlayer(p)) {
            e.setCancelled(true);
            LobbyPlayer[] players3;
            for (int length = (players3 = Lobby.getInstance().getPlayers()).length, i = 0; i < length; ++i) {
                final LobbyPlayer players = players3[i];
                players.getPlayer().sendMessage(Messages.getInstance().CHAT_FORMAT.replaceAll("<player>", p.getName()).replaceAll("<message>", e.getMessage().replaceAll("&", "�")));
            }
        }
        else if (sw != null) {
            e.setCancelled(true);
            SkyPlayer[] players4;
            for (int length2 = (players4 = sw.getPlayers()).length, j = 0; j < length2; ++j) {
                final SkyPlayer players2 = players4[j];
                players2.getPlayer().sendMessage(Messages.getInstance().CHAT_FORMAT.replaceAll("<player>", p.getName()).replaceAll("<message>", e.getMessage().replaceAll("&", "�")));
            }
        }
    }
    
        
    
    @EventHandler
    private void onBlockBreakChest(final BlockBreakEvent e){
    	Player p = e.getPlayer();
    	
        final SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
        if (sw == null) {
            return;
        }
        if (sw.getState() == SkyWars.GameState.WAITING) {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    private void onInteractStarting(final PlayerInteractEvent e) {
        final Player p = e.getPlayer();
        final SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
        if (sw == null) {
            return;
        }
        if (sw.getState() == SkyWars.GameState.WAITING) {
            e.setCancelled(true);
        }
    }
    

    
    @EventHandler
    private void onFoodChangee(final FoodLevelChangeEvent e) {
        final Player p = (Player) e.getEntity();
        final SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
        if (sw == null) {
            return;
        }
        if (sw.getState() == SkyWars.GameState.WAITING) {
            e.setCancelled(true);
            p.setFoodLevel(20);
            return;
        }
        if (!sw.getPlayer(p).isAlive()) {
            e.setCancelled(true);
            p.setFoodLevel(20);
        }
    }

    
    @EventHandler
    private void onBlockPlace(final BlockPlaceEvent e) {
        final Player p = e.getPlayer();
        final SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
        if (sw == null) {
            return;
        }
        if (sw.getState() == SkyWars.GameState.WAITING) {
            e.setCancelled(true);
            return;
        }
        if (!sw.getPlayer(p).isAlive()) {
            e.setCancelled(true);
        }
    }

    
    @EventHandler
    private void onEntityDamage(EntityDamageEvent e){
    	if(!(e.getEntity() instanceof Player)){
    		return;
    	}
    	Player p = (Player) e.getEntity();
    	SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
    	if(sw == null){
    		return;
    	}
    	if(sw.getState() == GameState.WAITING){
    		e.setCancelled(true);
    	}
    	if(SkyWars.invencible.contains(p)){
    		e.setCancelled(true);
    	}
    }
    
        
    @EventHandler
    private void onEntityDamageBySpect(EntityDamageByEntityEvent e){
    	if(!(e.getEntity()instanceof Player)){
    		return;
    	}
    	if(!(e.getDamager()instanceof Player)){
    		return;
    	}
    	Player d = (Player) e.getDamager();
    	if(SkyWars.spectador.contains(d)){
    		e.setCancelled(true);
    	}
    	
    }
    
    @EventHandler
    private void onEntityDamageEntity(final EntityDamageByEntityEvent e) {
    	if(!(e.getEntity() instanceof Player)){
    		return;
    	}
        if (e.getEntity() instanceof Player && e.getDamager() instanceof Player) {
            final Player p = (Player)e.getEntity();
            final Player d = (Player)e.getDamager();
            if (Lobby.getInstance().hasPlayer(p) || Lobby.getInstance().hasPlayer(d)) {
                return;
            }
            final SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
            if (sw != null && sw.getID().equalsIgnoreCase(SkyWarsManager.getInstance().getSkyWars(d).getID())) {
                if (sw.getIsland(p).equals(sw.getIsland(d)) || sw.getIsland(d).equals(p)) {
                   e.setCancelled(true);
                }
               
            }
        }
    }
}
