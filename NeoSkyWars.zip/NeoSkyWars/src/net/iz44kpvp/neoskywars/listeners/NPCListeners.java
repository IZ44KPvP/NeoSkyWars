package net.iz44kpvp.neoskywars.listeners;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;

import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.lobby.Lobby;
import net.iz44kpvp.neoskywars.managers.PartyManager;
import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.skywars.SkyWars;
import net.iz44kpvp.neoskywars.skywars.SkyWars.GameMode;

public class NPCListeners implements Listener{

	
	@EventHandler
	public void entitbiausdsan(EntityDamageEvent e) {
		if (e.getEntity() instanceof Villager) {
			Villager v = (Villager) e.getEntity();
			if (v.getCustomName().equalsIgnoreCase(Messages.getInstance().NPC_ARENAS_DISPLAY)) {
				e.setCancelled(true);
			}else if(v.getCustomName().equalsIgnoreCase(Messages.getInstance().NPC_PLAY_DISPLAY)){
				e.setCancelled(true);
			}
		}
	}

	@SuppressWarnings("deprecation")
	@EventHandler
	private void onKillNpc(EntityDamageByEntityEvent e){
		if(e.getEntity() instanceof Villager){
			Villager v = (Villager) e.getEntity();
			if(e.getDamager() instanceof Player){
				Player p = (Player) e.getDamager();
		      if(p.hasPermission("skywars.removenpc")){
			
				if (v.getCustomName().equalsIgnoreCase(Messages.getInstance().NPC_ARENAS_DISPLAY)) {
					if(p.getItemInHand().getType() != null && p.getItemInHand().getType() != org.bukkit.Material.AIR && p.getItemInHand().getType() == org.bukkit.Material.STICK){
						v.setHealth(0);
						p.sendMessage("�aNPC Removed Sucessfully");
					}
				}else if(v.getCustomName().equalsIgnoreCase(Messages.getInstance().NPC_PLAY_DISPLAY)){
					if(p.getItemInHand().getType() != null && p.getItemInHand().getType() != org.bukkit.Material.AIR && p.getItemInHand().getType() == org.bukkit.Material.STICK){
						v.setHealth(0);
						p.sendMessage("�aNPC Removed Sucessfully");
					}
				}
			  }
			}
		}
	}
	
	@EventHandler
	public void nsaioudnsa(PlayerInteractEntityEvent e) {
		boolean leader = false;
		if (e.getRightClicked() instanceof Villager) {
			Villager v = (Villager) e.getRightClicked();
			if (v.getCustomName().equalsIgnoreCase(Messages.getInstance().NPC_ARENAS_DISPLAY)) {
				e.setCancelled(true);
				Lobby.getInstance().getMenu("rooms").registerItems();
			    e.getPlayer().openInventory(Lobby.getInstance().getMenu("rooms").inv);
			}else if(v.getCustomName().equalsIgnoreCase(Messages.getInstance().NPC_PLAY_DISPLAY)){
				e.setCancelled(true);
				final SkyWars highest = getOrganizedFromPlayersOnSoloMode();
                if (highest == null) {
                	e.getPlayer().sendMessage(Messages.getInstance().SW_SIGN_NOT_HAVEROOM_AVAIBLE);
                	return;
                }
                PartyManager p = PartyManager.getParty(e.getPlayer());
                
                if(p != null){
                	if(p.getOwner().getName().equalsIgnoreCase(e.getPlayer().getName())){
                		highest.addPlayer(e.getPlayer());
                		e.getPlayer().sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
                		leader = true;
                	}else{
                		e.getPlayer().sendMessage(Messages.getInstance().PARTY_YOU_IS_NOT_LEADER);
                		leader = false;
                	}
                }else{
                	highest.addPlayer(e.getPlayer());
                	e.getPlayer().sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
                }
                if(p == null){
                	return;
                }
                for(Player member : p.getMembers()){
                	if(member != null){
                		if(member != e.getPlayer()){
                			if(leader){
                				if(SkyWarsManager.getInstance().getSkyWars(member) != null){
                					SkyWars sw = SkyWarsManager.getInstance().getSkyWars(member);
                						sw.removePlayerSilent(member);
                				}
                				member.sendMessage(Messages.getInstance().SKYWARS_CONECTING.replace("<skywars>", highest.getID()));
                        		highest.addPlayer(member);
                			}
                		}
                	}
                }
                
            }
			}
		}
	
	
public static SkyWars getOrganizedFromPlayersOnSoloMode() {
    try {
        final List<String> a = new ArrayList<String>();
        for (final SkyWars sw : SkyWarsManager.getInstance().getSkyWars()) {
            if(sw.getState() == SkyWars.GameState.WAITING && sw.getMode() == GameMode.SOLO && sw.getMaxPlayers() > sw.getPlayers().length && sw.getPlayers().length >= 1){
            	a.add(String.valueOf(sw.getID()));
            }else if(sw.getState() == SkyWars.GameState.WAITING && sw.getMode() == GameMode.SOLO && sw.getMaxPlayers() > sw.getPlayers().length) {
                a.add(String.valueOf(sw.getID()));
            }
        }
	
        return SkyWarsManager.getInstance().getSkyWars(a.get(0).split(" ")[0]);
       
    }
    catch (Exception e) {
        return null;
    }
}
	
}
