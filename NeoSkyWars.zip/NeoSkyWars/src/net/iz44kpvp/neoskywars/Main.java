package net.iz44kpvp.neoskywars;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import net.iz44kpvp.neoskywars.api.ConfigFile;
import net.iz44kpvp.neoskywars.api.ItemBuilder;
import net.iz44kpvp.neoskywars.api.LoadConfig;
import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.api.Mysql;
import net.iz44kpvp.neoskywars.commands.PartyCommand;
import net.iz44kpvp.neoskywars.commands.SkyWarsCommand;
import net.iz44kpvp.neoskywars.controllers.KitController;
import net.iz44kpvp.neoskywars.listeners.KitsListeners;
import net.iz44kpvp.neoskywars.listeners.LobbyListeners;
import net.iz44kpvp.neoskywars.listeners.NPCListeners;
import net.iz44kpvp.neoskywars.listeners.SignListeners;
import net.iz44kpvp.neoskywars.listeners.SkyWarsListeners;
import net.iz44kpvp.neoskywars.listeners.SpectatorListeners;
import net.iz44kpvp.neoskywars.lobby.GUIs.SpectatorGUI;
import net.iz44kpvp.neoskywars.lobby.GUIs.StatsGUI;
import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.reflection.Reflection;
import net.iz44kpvp.neoskywars.utils.ColoredTexts;

public class Main extends JavaPlugin implements ColoredTexts
{
    private static Main instance;
    private static Mysql mysqlManager;
    private static LoadConfig configManager;
    public boolean useConfig;
    public CommandSender consoleSender;
    public SignListeners signManager;
    private static String serverversion = Reflection.getVersion();
	public static Sound CLICK, NOTE_PLING, PORTAL_TRIGGER, CHEST_OPEN;
	public static ConfigFile kits, items, chests, extraconfig;
    
    public static boolean hasconnection = true;
    
	
    
    static {
        Main.mysqlManager = null;
        Main.configManager = null;
    }
    
    public Main() {
        this.useConfig = false;
        this.consoleSender = (CommandSender)Bukkit.getConsoleSender();
    }
    
    public static Main getInstance() {
        return Main.instance;
    }
    
    public static String getServerVersion(){
    	return serverversion;
    }
    
    public static Mysql getMysqlManager() {
        return Main.mysqlManager;
    }
    
    public static LoadConfig getConfigManager() {
        return Main.configManager;
    }
    
    
 
    
    @Override
    public void onEnable() {
        (Main.instance = this).saveDefaultConfig();
        Bukkit.getConsoleSender().sendMessage(green + " " + reset);
        Bukkit.getConsoleSender().sendMessage(green + "**************************************************" + reset);
        Bukkit.getConsoleSender().sendMessage(green + "----------------- NeoSkyWars ------------------" + reset);
        Bukkit.getConsoleSender().sendMessage(green + " " + reset);
        Bukkit.getConsoleSender().sendMessage(red + "   - Plugin Enabled!" + reset);
        Bukkit.getConsoleSender().sendMessage(red + "   - Developed by IZ44KPvP" + reset);
        Bukkit.getConsoleSender().sendMessage(red + "   - Copyright 2017 NeoSkyWars!" + reset);
        Bukkit.getConsoleSender().sendMessage(green + " " + reset);
        Bukkit.getConsoleSender().sendMessage(yellow + "You can get new versions with this link:" + reset);
        Bukkit.getConsoleSender().sendMessage(yellow + ">https://goo.gl/do2U1J" + reset);
        Bukkit.getConsoleSender().sendMessage(green + " " + reset);
        Bukkit.getConsoleSender().sendMessage(green + "---------------- SKYWARS LOGGER ----------------" + reset);
        {
        	
        	Bukkit.getConsoleSender().sendMessage("§aLoading Listeners and Signs...");
        	 getListenersAndEvents();
             registerListeners(this,
             new SpectatorListeners(),
             new SpectatorGUI(), new KitsListeners(), new NPCListeners());
             loadSounds();
        }
        getCommand("party").setExecutor(new PartyCommand());
        getCommand("skywars").setExecutor(new SkyWarsCommand());
        {
        	Bukkit.getConsoleSender().sendMessage(green + "Loading configs...");
        	Main.configManager = new LoadConfig(this);
        	kits = new ConfigFile(this, "kits");
        	items = new ConfigFile(this, "items");
        	chests = new ConfigFile(this, "chests");
        	extraconfig = new ConfigFile(this, "extraconfig");
        }
        {
        	Bukkit.getConsoleSender().sendMessage(green + "Loading Kits...");
        	CreateAllKits();
        }
        
        if (Messages.getInstance().problemTranslation) {
            consoleSender.sendMessage(red + "> Error ocurred on copy message to file messages.yml please contact the dev of Plugin." + reset);
        }
        
        
        {
        	Bukkit.getConsoleSender().sendMessage("§aLoading Mysql Information...");
        	Main.mysqlManager = new Mysql(this);
        }
        
        if (Main.mysqlManager.problem) {
            consoleSender.sendMessage(red + "> Error ocurred conecting to Database, please check your information or Internet Connection if Your Mysql is Hosted in Other Computer!" + reset);
        }
        Messages.getInstance().setup();
        SkyWarsManager.getInstance().setup();
        Collections.reverse(Messages.getInstance().SCOREBOARD_LOBBY);
        Collections.reverse(Messages.getInstance().SCOREBOARD_ROOM);
        Collections.reverse(Messages.getInstance().SCOREBOARD_WAIT);
        consoleSender.sendMessage(green + "**************************************************" + reset);
        consoleSender.sendMessage(green + " " + reset);
        this.CheckPiracy();
        
    }
    

	private void getListenersAndEvents() {
        Bukkit.getPluginManager().registerEvents((Listener)new LobbyListeners(), (Plugin)Main.getInstance());
        
        Bukkit.getPluginManager().registerEvents((Listener)new SkyWarsListeners(), (Plugin)Main.getInstance());
        Bukkit.getPluginManager().registerEvents((Listener)(Main.getInstance().signManager = new SignListeners()), (Plugin)Main.getInstance());
        
        Bukkit.getPluginManager().registerEvents((Listener)new StatsGUI(), (Plugin)Main.getInstance());
      
      
	}

	private void registerListeners(Plugin plugin, Listener... listeners) {
		for(Listener listener : listeners){
			Bukkit.getPluginManager().registerEvents(listener, plugin);
		}
		
	}

	public void onDisable() {
        Main.instance = null;
    }

	public static Main getPlugin() {
		
		return getPlugin(Main.class);
	}
	
		
	  
	  public static boolean is18()
	  {
	    String v11 = "v1_11_R1";
	    if (getServerVersion().equalsIgnoreCase(v11)) {
	      return false;
	    }
	    return true;
	  }
	
	

		private String id = "%%__USER__%%";
		protected boolean sts = true;

		
		private void CheckPiracy() {
			try {
			    final String line = new BufferedReader(new InputStreamReader(new URL("http://checkip.amazonaws.com/").openStream())).readLine();
			    final HashMap<String, String> hashMap = new HashMap<String, String>();
			    hashMap.put("user_id", "%%__USER__%%");
		        hashMap.put("plugin_id", "%%__RESOURCE__%%");
		        hashMap.put("ip", line);
		        hashMap.put("ver", "1");
				URLConnection localURLConnection = new URL("http://neoskywars.hol.es/blacklist.txt").openConnection();
				localURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
		        localURLConnection.connect();
		        
		        BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localURLConnection.getInputStream(), Charset.forName("UTF-8")));
		        
		        StringBuilder localStringBuilder = new StringBuilder();
		        String str1;
		        while ((str1 = localBufferedReader.readLine()) != null) {
		        	localStringBuilder.append(str1);
		         }
		        String str2 = localStringBuilder.toString();
		        if (str2.contains(String.valueOf(id))) {
		        	DesativarPorPirataria();
		        	return;
		         }
		        sts = true;
		       }
		       catch (IOException localIOException){
		    	   localIOException.printStackTrace();
		    	   hasconnection = false;
		    	   Bukkit.getConsoleSender().sendMessage("§7[WARN] [NeoSkyWars] §cServer not have Internet Connection!");
		    	   return;
		       }
		     }
		    
		     public void DesativarPorPirataria() {
		    	 Bukkit.broadcastMessage(ChatColor.RED + "§cPlugin Disabled Due for Leaking");
		    	 Bukkit.getPluginManager().disablePlugin(Main.getPlugin());
		    	 sts = false;
		     }
		    
		    
		 	private void loadSounds() {
				try {
					CLICK = Sound.valueOf("CLICK");
					NOTE_PLING = Sound.valueOf("NOTE_PLING");
					PORTAL_TRIGGER = Sound.valueOf("PORTAL_TRIGGER");
					CHEST_OPEN = Sound.valueOf("CHEST_OPEN");
				} catch (final IllegalArgumentException var2) {
					CLICK = Sound.valueOf("UI_BUTTON_CLICK");
					NOTE_PLING = Sound.valueOf("BLOCK_NOTE_PLING");
					PORTAL_TRIGGER = Sound.valueOf("BLOCK_PORTAL_TRIGGER");
					CHEST_OPEN = Sound.valueOf("BLOCK_CHEST_OPEN");
				}

			} 
		 	
		 	
			
			@SuppressWarnings("deprecation")
			public static void CreateAllKits(){
				ConfigurationSection config = kits.getConfig().getConfigurationSection("kits");
				for(String key : kits.getConfig().getConfigurationSection("kits").getKeys(false)){
					log("§aKit " + key+ " is now loading...");
					String name = ChatColor.translateAlternateColorCodes('&', config.getString(key+".name"));
					int slot = config.getInt(key+".slot");
					ItemStack icon = new ItemStack(config.getInt(key+".icon"));
					int cost = 0;
					ArrayList<String>desc =  new ArrayList<String>();			
					ArrayList<String> desc2 =  new ArrayList<String>();
					ItemStack[] items = null;
					
					
					if(config.contains(key+".price")){
					 cost = config.getInt(key+".price");
						
					}
					
					if(config.getStringList(key + ".items").isEmpty()){
						log("Kit " + key + " not have items!");
						return;
					}else {
						for(String resolver : config.getStringList(key+".items")){
							ItemStack added = ItemBuilder.toKit(resolver);
							items = new ItemStack[] {added};
						}
					}
					
					if(config.getStringList(key +".description.locked").isEmpty()||config.getStringList(key +".description.unlocked").isEmpty()){
						desc = null;
					    desc2 = null;
					}else {
						for(String added : config.getStringList(key +".description.locked")){
							desc.add(added.replaceAll("%cost", ""+cost));

						
						}
						for(String added : config.getStringList(key +".description.unlocked")){
							desc2.add(added);


							
						
						}
					}
					if(config.contains(key+".permission")&&config.contains(key+".price")){
						String permission = config.getString(key +".permission");
				
						new KitController(icon,key, name, permission, cost, slot, desc, desc2, items);
						log("§aLoad Kit  " + key + " success!");
					}else {
						new KitController(icon,key, name, slot,  desc, desc2, items);
						log("§aLoad Kit  " + key + " success!");
						
			
						
					}
				}
			}

			private static void log(String string) {
				Bukkit.getConsoleSender().sendMessage(string);
			}
	  
}
