package net.iz44kpvp.neoskywars.kits;

import java.util.Map.Entry;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.api.ItemBuilder;
import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.controllers.KitController;
import net.iz44kpvp.neoskywars.player.storage.Stats;


@SuppressWarnings("all")
public class KitMenu extends Menu implements Listener{

	public KitMenu(Player p) {
		super(Main.kits.get("menu_name"), Main.kits.getInt("menu_rows"));
		for(Entry<KitController, String> kits : KitController.getKits().entrySet()){
			KitController kit = kits.getKey();
			String _name = ChatColor.translateAlternateColorCodes('&', kit.getName());
		    if(kit.getCost() >= 1 && kit.getPermission()!= null){
				if(p.hasPermission(kit.getPermission())){
					s(kit.getSlot(), ItemBuilder.crearItem2(kit.getIcon().getTypeId(), 1, 0, _name, kit.getDesc2()));
				}else {
					s(kit.getSlot(), ItemBuilder.crearItem2(kit.getIcon().getTypeId(), 1, 0, _name, kit.getDesc()));
				}
			}else {
				s(kit.getSlot(), ItemBuilder.crearItem2(kit.getIcon().getTypeId(), 1, 0, _name, kit.getDesc2()));
			}
			
			
		}
	}



}
