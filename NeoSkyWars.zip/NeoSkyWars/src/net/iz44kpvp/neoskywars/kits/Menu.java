package net.iz44kpvp.neoskywars.kits;



import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import net.iz44kpvp.neoskywars.Main;


public abstract class Menu implements Listener {
	Inventory _inv;

	public Menu(String name, int rows){
		_inv = Bukkit.createInventory(null, 9 * rows, ChatColor.translateAlternateColorCodes('&', name));
		Bukkit.getPluginManager().registerEvents(this, Main.getPlugin());
	}
	
	public  void a(ItemStack stack){
		_inv.addItem(stack);
	}
	public void s(int i , ItemStack stack){
		_inv.setItem(i, stack);
	}
	public Inventory i(){
		return _inv;
	}
	public String n()
	{	
		return _inv.getName();
	}
	public void o(Player p){
		p.openInventory(_inv);
	}


	  @EventHandler
	    public void onInventoryClose(InventoryCloseEvent event) {
	        if (event.getInventory().equals(this.i()) && event.getPlayer() instanceof Player) {
	            this.onClose((Player) event.getPlayer());
	        }
	    }
	  public void onClose(Player player) {}
}
