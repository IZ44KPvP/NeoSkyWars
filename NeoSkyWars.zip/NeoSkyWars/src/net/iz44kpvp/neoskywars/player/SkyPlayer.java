package net.iz44kpvp.neoskywars.player;

import org.bukkit.entity.Player;

public class SkyPlayer
{
    private Player player;
    private boolean alive;
    private int kills;
    private boolean protect;
    
    public SkyPlayer(final Player p) {
        this.protect = true;
        this.player = p;
        this.alive = true;
        this.kills = 0;
    }
    
        
    public void setAlive(final boolean alive) {
        this.alive = alive;
    }
    
    public void setDead(final boolean dead) {
        this.alive = dead;
    }
    
    public void setProtect() {
        this.protect = false;
    }
    
    public void addKills() {
        ++this.kills;
    }
    
    
    public Player getPlayer() {
        return this.player;
    }
    
    
    public boolean isAlive() {
        return this.alive;
    }

    public boolean isProtected() {
        return this.protect;
    }
    
    public int getKills() {
        return this.kills;
    }
    
}
