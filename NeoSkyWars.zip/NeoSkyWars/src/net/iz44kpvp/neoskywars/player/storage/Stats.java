package net.iz44kpvp.neoskywars.player.storage;

import org.bukkit.entity.Player;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.skywars.SkyWars;

public class Stats
{
    public static void createAccount(final Player p) {
        if (Main.getInstance().useConfig) {
            Main.getMysqlManager().createAccount(p.getUniqueId(), p.getName());
            return;
        }
        if (getNick(p) != null) {
            return;
        }
        Main.getConfigManager().setValueString("nick", p.getUniqueId(), p.getName());
        Main.getConfigManager().setValueInt("kills", p.getUniqueId(), 0);
        Main.getConfigManager().setValueInt("deaths", p.getUniqueId(), 0);
        Main.getConfigManager().setValueInt("wins", p.getUniqueId(), 0);
        Main.getConfigManager().setValueInt("coins", p.getUniqueId(), 0);
        Main.getConfigManager().setValueInt("souls", p.getUniqueId(), 0);
        Main.getConfigManager().setValue("games", p.getUniqueId(), 0);
    }
    
    public static void addKills(final Player p, final int kills) {
    	SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
    	if(sw == null){
    		return;
    	}
        if (Main.getInstance().useConfig) {
            Main.getMysqlManager().setValueInt("kills", getKills(p) + kills, p.getUniqueId());
            return;
        }
        Main.getConfigManager().setValueInt("kills", p.getUniqueId(), getKills(p) + kills);
    }
    
    public static void addSouls(final Player p, final int souls) {
        if (Main.getInstance().useConfig) {
            Main.getMysqlManager().setValueInt("souls", getSouls(p) + souls, p.getUniqueId());
            return;
        }
        Main.getConfigManager().setValueInt("souls", p.getUniqueId(), getSouls(p) + souls);
    }
    
    
    public static void addGames(final Player p, final int games) {
    	SkyWars sw = SkyWarsManager.getInstance().getSkyWars(p);
    	if(sw == null){
    		return;
    	}
        if (Main.getInstance().useConfig) {
            Main.getMysqlManager().setValueInt("games", getGames(p) + games, p.getUniqueId());
            return;
        }
        Main.getConfigManager().setValueInt("games", p.getUniqueId(), getGames(p) + games);
    }
    
    public static void addDeaths(final Player p, final int deaths) {
        if (Main.getInstance().useConfig) {
            Main.getMysqlManager().setValueInt("deaths", getDeaths(p) + deaths, p.getUniqueId());
            return;
        }
        Main.getConfigManager().setValueInt("deaths", p.getUniqueId(), getDeaths(p) + deaths);
    }
    
    public static void addWins(final Player p, final int wins) {
    	
        if (Main.getInstance().useConfig) {
            Main.getMysqlManager().setValueInt("wins", getWins(p) + wins, p.getUniqueId());
            return;
        }
        Main.getConfigManager().setValueInt("wins", p.getUniqueId(), getWins(p) + wins);
    }
    
    public static void addCoins(final Player p, final int points) {
        if (Main.getInstance().useConfig) {
            Main.getMysqlManager().setValueInt("coins", getCoins(p) + points, p.getUniqueId());
            return;
        }
        Main.getConfigManager().setValueInt("coins", p.getUniqueId(), getCoins(p) + points);
    }
    
    public static void removeKills(final Player p, final int kills) {
        if (Main.getInstance().useConfig) {
            Main.getMysqlManager().setValueInt("kills", getKills(p) - kills, p.getUniqueId());
            return;
        }
        Main.getConfigManager().setValueInt("kills", p.getUniqueId(), getKills(p) - kills);
    }
    
    public static void removeDeaths(final Player p, final int deaths) {
        if (Main.getInstance().useConfig) {
            Main.getMysqlManager().setValueInt("deaths", getDeaths(p) - deaths, p.getUniqueId());
            return;
        }
        Main.getConfigManager().setValueInt("deaths", p.getUniqueId(), getDeaths(p) - deaths);
    }
    
    public static void removeWins(final Player p, final int wins) {
        if (Main.getInstance().useConfig) {
            Main.getMysqlManager().setValueInt("wins", getWins(p) - wins, p.getUniqueId());
            return;
        }
        Main.getConfigManager().setValueInt("wins", p.getUniqueId(), getWins(p) - wins);
    }
    
    public static void removeCoins(final Player p, final int points) {
        if (Main.getInstance().useConfig) {
            Main.getMysqlManager().setValueInt("coins", getCoins(p) - points, p.getUniqueId());
            return;
        }
        Main.getConfigManager().setValueInt("coins", p.getUniqueId(), getCoins(p) - points);
    }
    
    public static void removeSouls(final Player p, final int points) {
        if (Main.getInstance().useConfig) {
            Main.getMysqlManager().setValueInt("souls", getCoins(p) - points, p.getUniqueId());
            return;
        }
        Main.getConfigManager().setValueInt("souls", p.getUniqueId(), getCoins(p) - points);
    }
    
    public static String getNick(final Player p) {
        if (Main.getInstance().useConfig) {
            return Main.getMysqlManager().getValueString("name", p.getUniqueId());
        }
        return Main.getConfigManager().getValueString("nick", p.getUniqueId());
    }
    
    public static Integer getKills(final Player p) {
        if (Main.getInstance().useConfig) {
            return Main.getMysqlManager().getValueInt("kills", p.getUniqueId());
        }
        return (Main.getConfigManager().getValue("kills", p.getUniqueId()) != null) ? Main.getConfigManager().getValueInt("kills", p.getUniqueId()) : 0;
    }
    
    public static Integer getSouls(final Player p) {
        if (Main.getInstance().useConfig) {
            return Main.getMysqlManager().getValueInt("souls", p.getUniqueId());
        }
        return (Main.getConfigManager().getValue("souls", p.getUniqueId()) != null) ? Main.getConfigManager().getValueInt("souls", p.getUniqueId()) : 0;
    }
    
    public static Integer getGames(final Player p) {
        if (Main.getInstance().useConfig) {
            return Main.getMysqlManager().getValueInt("games", p.getUniqueId());
        }
        return (Main.getConfigManager().getValue("games", p.getUniqueId()) != null) ? Main.getConfigManager().getValueInt("games", p.getUniqueId()) : 0;
    }
    
    public static Integer getDeaths(final Player p) {
        if (Main.getInstance().useConfig) {
            return Main.getMysqlManager().getValueInt("deaths", p.getUniqueId());
        }
        return (Main.getConfigManager().getValue("deaths", p.getUniqueId()) != null) ? Main.getConfigManager().getValueInt("deaths", p.getUniqueId()) : 0;
    }
    
    public static Integer getWins(final Player p) {
        if (Main.getInstance().useConfig) {
            return Main.getMysqlManager().getValueInt("wins", p.getUniqueId());
        }
        return (Main.getConfigManager().getValue("wins", p.getUniqueId()) != null) ? Main.getConfigManager().getValueInt("wins", p.getUniqueId()) : 0;
    }
    
    public static Integer getCoins(final Player p) {
        if (Main.getInstance().useConfig) {
            return Main.getMysqlManager().getValueInt("coins", p.getUniqueId());
        }
        return (Main.getConfigManager().getValue("coins", p.getUniqueId()) != null) ? Main.getConfigManager().getValueInt("coins", p.getUniqueId()) : 0;
    }
}
