package net.iz44kpvp.neoskywars.managers;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.api.Messages;
import net.iz44kpvp.neoskywars.api.title.Title1_11;
import net.iz44kpvp.neoskywars.api.title.Title1_8;
import net.iz44kpvp.neoskywars.player.SkyPlayer;
import net.iz44kpvp.neoskywars.skywars.SkyWars;
import net.iz44kpvp.neoskywars.skywars.SkyWars.ChestType;
import net.iz44kpvp.neoskywars.skywars.SkyWars.GameMode;

public class TimerManager
{
    private SkyWars skywars;
    private BukkitTask task;
    private int time;
    private List<Integer> counting;
    
    public TimerManager(final SkyWars skywars, final int start, final int... counts) {
        this.counting = new ArrayList<Integer>();
        this.skywars = skywars;
        TimerManager.this.time = start;
        for (final int c : counts) {
            this.counting.add(c);
        }
    }
    
    public void start() {
        this.task = new BukkitRunnable() {
            public void run() {
                if (TimerManager.this.skywars.getState() == SkyWars.GameState.STARTED) {
                    this.cancel();
                    return;
                }
                if (TimerManager.this.skywars.getPlayers().length < Main.getPlugin().getConfig().getInt("Min-Players")) {
                    if (TimerManager.this.time != 15) {
                    	TimerManager.this.time = 15;
                    }
                    return;
                }
                if (TimerManager.this.time > 0 && TimerManager.this.counting.contains(TimerManager.this.time)) {
                    SkyPlayer[] players2;
                    for (int length = (players2 = TimerManager.this.skywars.getPlayers()).length, i = 0; i < length; ++i) {
                        final SkyPlayer players = players2[i];
                        players.getPlayer().sendMessage(Messages.getInstance().SKYWARS_STARTING.replace("<time>", String.valueOf(TimerManager.this.time)));
                        
                        if(Main.is18()){
                        	Title1_8 t = new Title1_8(Messages.getInstance().SKYWARS_TITLE_STARTING.replace("<time>", String.valueOf(TimerManager.this.time)), Messages.getInstance().SKYWARS_SUBTITLE_STARTING.replaceAll("<time>", String.valueOf(TimerManager.this.time)));
                            
                            t.send(players.getPlayer());
                        }else{
                        	
                        	
                        	Title1_11 t = new Title1_11(Messages.getInstance().SKYWARS_TITLE_STARTING.replace("<time>", String.valueOf(TimerManager.this.time)), Messages.getInstance().SKYWARS_SUBTITLE_STARTING.replaceAll("<time>", String.valueOf(TimerManager.this.time)));
                            
                            t.send(players.getPlayer());
                        	
                        }
                        
          
                        players.getPlayer().playSound(players.getPlayer().getLocation(), Main.CLICK, 7.0F, 7.0F);
                        
                    }
                }
                if (TimerManager.this.time == 0) {
                    if (TimerManager.this.skywars.getPlayers().length >= Main.getPlugin().getConfig().getInt("Min-Players")) {
                        SkyPlayer[] players3;
                        for (int length2 = (players3 = TimerManager.this.skywars.getPlayers()).length, j = 0; j < length2; ++j) {
                            final SkyPlayer players = players3[j];
                            
                            for(String list : Messages.getInstance().SKYWARS_START_INFO){
                            	list = ChatColor.translateAlternateColorCodes('&', list);
                            	players.getPlayer().sendMessage(list);
                            }
                            players.getPlayer().sendMessage(Messages.getInstance().SKYWARS_STARTED);
                            
                            if(skywars.getMode() == GameMode.SOLO){
                            	players.getPlayer().sendMessage(Messages.getInstance().SKYWARS_TEAM_NOT_ALLOWED);
                            }
                    
                            players.getPlayer().playSound(players.getPlayer().getLocation(), Main.NOTE_PLING, 1.0F, 1.0F);
                           SkyWars sw = SkyWarsManager.getInstance().getSkyWars(players.getPlayer());
                            if(sw.getChestType() == ChestType.INSANE){
                             
                            if(Main.is18()){
                            	Title1_8 t2 = new Title1_8(Messages.getInstance().SKYWARS_TITLE_STARTED_INSANEMODE, "");
                                
                                t2.send(players.getPlayer());
                            }else{
                                Title1_11 t2 = new Title1_11(Messages.getInstance().SKYWARS_TITLE_STARTED_INSANEMODE, "");
                                
                                t2.send(players.getPlayer());
                            }
                            
                            }
                            	
                        }
                        TimerManager.this.skywars.start();
                        this.cancel();
                        return;
                    }
                    TimerManager.this.time = 15;
                }
                
                TimerManager.this.time -= 1;
            }
        }.runTaskTimer((Plugin)Main.getInstance(), 0L, 20L);
    }
    
    public void cancel() {
        if (this.task != null) {
            this.task.cancel();
            this.task = null;
        }
    }
    
    public void setTime(final int newtime) {
        TimerManager.this.time = newtime;
    }
    
    public Integer getTime() {
        return time;
    }
    
    public BukkitTask getTask() {
        return this.task;
    }
	
    
}
