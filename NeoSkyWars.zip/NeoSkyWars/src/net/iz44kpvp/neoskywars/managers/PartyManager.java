package net.iz44kpvp.neoskywars.managers;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.api.Messages;

public class PartyManager{
	
	private List<Player>members=new ArrayList<>();
	private List<Player>invite=new ArrayList<>();
	private List<Player>chat=new ArrayList<>();
	
	public PartyManager(Player owner){
		this.members.add(owner);
	}
	
	public boolean addPlayer(Player p){
		members.add(p);
		return true;
	}
	
	public boolean removePlayer(Player p){
		members.remove(p);
		return true;
	}
	
	public boolean invitePlayer(final Player p, int expiresSeconds){
		invite.add(p);
		new BukkitRunnable(){
			String inviter=members.get(0).getName();
			public void run(){
				if(invite.contains(p)){
					invite.remove(p);
					p.sendMessage(Messages.getInstance().PARTY_REQUEST_EXPIRED.replace("<player>", inviter));
				}
			}
		}.runTaskLater(Main.getPlugin(), 20*expiresSeconds);
		return true;
	}
	
	public List<Player> getInvite(){
		   return invite;
		}
	
	public Player getOwner(){
		return members.get(0);
	}
	
	public boolean addChat(Player p){
		this.chat.add(p);
		return true;
	}
	
	public boolean removeChat(Player p){
		this.chat.remove(p);
		return true;
	}
	
	public boolean hasChat(Player p){
		if(this.chat.contains(p))
			return true;
		return false;
	}
	
	public List<Player> getMembers(){
		return members;
	}
	
	private static List<PartyManager>partys=new ArrayList<>();
	
	public static boolean createParty(Player p){
		partys.add(new PartyManager(p));
		return true;
	}
	
	public static boolean deleteParty(Player p){
		PartyManager party=getParty(p);
		partys.remove(party);
		for(Player p2:party.getMembers())
			if(p2!=p&&p2.getPlayer().isOnline())
				p2.sendMessage(Messages.getInstance().PARTY_DELETED.replace("<player>", p.getName()));
		return true;
	}
	
	public static PartyManager getParty(Player p){
		for(PartyManager pt:partys)
			if(pt.getMembers().contains(p))
				return pt;
		return null;
	}
	
	public static List<PartyManager> getPartys(){
		return partys;
	}
}
