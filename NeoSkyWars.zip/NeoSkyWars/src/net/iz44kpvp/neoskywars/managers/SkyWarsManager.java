package net.iz44kpvp.neoskywars.managers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import net.iz44kpvp.neoskywars.Main;
import net.iz44kpvp.neoskywars.skywars.SkyWars;


public class SkyWarsManager
{
    private static SkyWarsManager instance;
    private List<SkyWars> skywars;
    private FileConfiguration config;
    private HashMap<String, String> permission;
    private HashMap<String, List<ItemStack>> itens;
   
    
    static {
        SkyWarsManager.instance = new SkyWarsManager();
    }
    
    public SkyWarsManager() {
        this.skywars = new ArrayList<SkyWars>();
        this.permission = new HashMap<String, String>();
        this.itens = new HashMap<String, List<ItemStack>>();
    }
    
    
    public void setup() {
        
        this.skywars.clear();
        final File arenas = new File("plugins/NeoSkyWars/arenas");
        if (!arenas.exists()) {
            arenas.mkdir();
        }
        final File mapas = new File("plugins/NeoSkyWars/mapas");
        if (!mapas.exists()) {
            mapas.mkdir();
        }
        Main.getInstance().consoleSender.sendMessage("�aLoading Maps....");
        File[] listFiles;
        for (int length = (listFiles = arenas.listFiles()).length, i = 0; i < length; ++i) {
            final File f = listFiles[i];
            if (f.isFile() && !f.isDirectory()) {
                final String id = f.getName().replace(".yml", "");
                final FileConfiguration config = (FileConfiguration)YamlConfiguration.loadConfiguration(f);
                final File mapa = new File(String.valueOf(mapas.toString()) + "/" + id);
                if (!mapa.exists()) {
                    Main.getInstance().consoleSender.sendMessage("�cFailed on Load Map: " + id);
                    continue;
                }
                try {
                    if (Bukkit.getWorld(id) != null) {
                        Bukkit.unloadWorld(id, false);
                    }
                    this.deleteFolder(new File(id));
                    this.copyDir(mapa, new File(id));
                    final WorldCreator wc = new WorldCreator(id);
                    wc.generateStructures(false);
                    final World map = wc.createWorld();
                    map.setAutoSave(false);
                    map.setKeepSpawnInMemory(false);
                    map.setGameRuleValue("doMobSpawning", "false");
                    map.setGameRuleValue("doDaylightCycle", "false");
                    map.setGameRuleValue("mobGriefing", "false");
                    map.setTime(0L);
                }
                catch (Exception e) {
                    Main.getInstance().consoleSender.sendMessage("�cFailed on import this map");
                    e.printStackTrace();
                }
                final SkyWars sw = new SkyWars(id, SkyWars.GameMode.valueOf(config.getString("mode").toUpperCase()), SkyWars.ChestType.valueOf(config.getString("type").toUpperCase()));
                this.skywars.add(sw);
            }
            Main.getInstance().consoleSender.sendMessage("�aLoaded " + this.skywars.size() + " arena(s) SkyWars");
        }
    }
    
    public void copyDir(final File source, final File target) {
        if (source.isDirectory()) {
            if (!target.exists()) {
                target.mkdir();
            }
            final String[] files = source.list();
            String[] array;
            for (int length = (array = files).length, i = 0; i < length; ++i) {
                final String name = array[i];
                final File srcFile = new File(source, name);
                final File tarFile = new File(target, name);
                this.copyDir(srcFile, tarFile);
            }
        }
        else {
            try {
                this.copyFile(new FileInputStream(source), target);
            }
            catch (FileNotFoundException e) {
                Main.getInstance().consoleSender.sendMessage("�cFailed on copy file from " + source.getName() + " to " + target.getName());
                e.printStackTrace();
            }
        }
    }
    
    
    public void copyFolder(final File source, final File target) {
        try {
            final ArrayList<String> ignore = new ArrayList<String>(Arrays.asList("uid.dat", "session.dat"));
            if (!ignore.contains(source.getName())) {
                if (source.isDirectory()) {
                    if (!target.exists()) {
                        target.mkdirs();
                    }
                    final String[] files = source.list();
                    String[] array;
                    for (int length2 = (array = files).length, i = 0; i < length2; ++i) {
                        final String file = array[i];
                        final File srcFile = new File(source, file);
                        final File destFile = new File(target, file);
                        copyFolder(srcFile, destFile);
                    }
                }
                else {
                    final InputStream in = new FileInputStream(source);
                    final OutputStream out = new FileOutputStream(target);
                    final byte[] buffer = new byte[1024];
                    int length;
                    while ((length = in.read(buffer)) > 0) {
                        out.write(buffer, 0, length);
                    }
                    in.close();
                    out.close();
                }
            }
        }
        catch (IOException ex) {}
    }
    
    
    public void deleteFolder(final File f) {
        if (f.isDirectory()) {
            if (f.list().length == 0) {
                f.delete();
            }
            else {
                final String[] files = f.list();
                String[] array;
                for (int length = (array = files).length, i = 0; i < length; ++i) {
                    final String name = array[i];
                    final File file = new File(f, name);
                    this.deleteFolder(file);
                }
                f.delete();
            }
        }
        else {
            f.delete();
        }
    }
  
    
  
    

    public void copyFile(final InputStream i, final File config) {
        try {
            final OutputStream out = new FileOutputStream(config);
            final byte[] buf = new byte[710];
            int len;
            while ((len = i.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            out.close();
            i.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public SkyWars getSkyWars(final String swID) {
        for (final SkyWars sw : this.skywars) {
            if (sw.getID().equals(swID)) {
                return sw;
            }
        }
        return null;
    }
    
    public SkyWars getSkyWars(final Player p) {
        for (final SkyWars sw : this.skywars) {
            if (sw.hasPlayer(p)) {
                return sw;
            }
        }
        return null;
    }
    
    public static SkyWarsManager getInstance() {
        return SkyWarsManager.instance;
    }
    
    public List<SkyWars> getSkyWars() {
        return this.skywars;
    }
    
    public FileConfiguration getConfig() {
        return this.config;
    }
    
    
    public HashMap<String, String> getPermission() {
        return this.permission;
    }
    
    public HashMap<String, List<ItemStack>> getItens() {
        return this.itens;
    }
    
    public String id = "%%__USER__%%";
}
