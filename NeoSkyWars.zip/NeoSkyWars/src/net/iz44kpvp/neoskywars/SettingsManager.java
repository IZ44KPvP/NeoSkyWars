package net.iz44kpvp.neoskywars;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import net.iz44kpvp.neoskywars.skywars.SkyWars;

public class SettingsManager
{
    private static final Map<String, SettingsManager> arenas;
    private static final SettingsManager lobby;
    private static final SettingsManager signs;
    private File file;
    private FileConfiguration config;
    
    static {
        arenas = new HashMap<String, SettingsManager>();
        lobby = new SettingsManager("lobbys");
        signs = new SettingsManager("signs");
    }
    
    public static SettingsManager getSkywars(final String name) {
        if (SettingsManager.arenas.containsKey(name)) {
            return SettingsManager.arenas.get(name);
        }
        SettingsManager.arenas.put(name, new SettingsManager(name));
        return SettingsManager.arenas.get(name);
    }
    
    public static SettingsManager getLobby() {
        return SettingsManager.lobby;
    }
    
    public static SettingsManager getSigns() {
        return SettingsManager.signs;   
    }
    
    public Location loadLocation(final ConfigurationSection section) {
        return new Location(Bukkit.getServer().getWorld(section.getString("world")), section.getDouble("x"), section.getDouble("y"), section.getDouble("z"));
    }
    
    public void saveLocation(final ConfigurationSection section, final Location location, final boolean skywarsboolean, final SkyWars skywars) {
        section.set("location.world", (Object)location.getWorld().getName());
        section.set("location.x", (Object)location.getX());
        section.set("location.y", (Object)location.getY());
        section.set("location.z", (Object)location.getZ());
        if (skywarsboolean) {
            section.set("arena", (Object)skywars.getID());
        }
        this.save();
    }
    
    public void saveLocation(final ConfigurationSection section, final Location location, final SkyWars.GameMode mode, final SkyWars.ChestType type) {
        if (mode != null) {
            section.set("mode", (Object)mode.name().toUpperCase());
        }
        if (type != null) {
            section.set("type", (Object)type.name().toUpperCase());
        }
        section.set("location.world", (Object)location.getWorld().getName());
        section.set("location.x", (Object)location.getX());
        section.set("location.y", (Object)location.getY());
        section.set("location.z", (Object)location.getZ());
        this.save();
    }
    
    public FileConfiguration getFile() {
        return this.config;
    }
    
    private SettingsManager(final String fileName) {
        if (fileName.equals("lobbys") || fileName.equals("signs")) {
            this.file = new File(Main.getInstance().getDataFolder(), String.valueOf(fileName) + ".yml");
        }
        else {
            this.file = new File(String.valueOf(Main.getInstance().getDataFolder().toString()) + "/arenas", String.valueOf(fileName) + ".yml");
        }
        if (!this.file.exists()) {
            try {
                this.file.getParentFile().mkdir();
                this.file.createNewFile();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        this.config = (FileConfiguration)YamlConfiguration.loadConfiguration(this.file);
    }
    
    public ConfigurationSection get(final String path) {
        return this.config.getConfigurationSection(path);
    }
    
    public Set<String> getKeys() {
        return (Set<String>)this.config.getKeys(false);
    }
    
    public Set<String> getKeys(final String path) {
        if (this.config.getConfigurationSection(path) == null) {
            this.createSection(path);
        }
        return (Set<String>)this.config.getConfigurationSection(path).getKeys(false);
    }
    
    public void set(final String path, final Object value) {
        this.config.set(path, value);
        this.save();
    }
    
    public boolean contains(final String path) {
        return this.config.contains(path);
    }
    
    public ConfigurationSection createSection(final String path) {
        final ConfigurationSection section = this.config.createSection(path);
        this.save();
        return section;
    }
    
	     
    
    public void save() {
        try {
            this.config.save(this.file);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
