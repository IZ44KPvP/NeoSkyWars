package net.iz44kpvp.neoskywars.controllers;

import org.bukkit.entity.Player;

import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;

public class ChatController
{
    public static void openUrl(Player player, String text, String cmd, String lore) {
        TextComponent textComponent = new TextComponent();
        textComponent.setText(text);
        textComponent.setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, cmd));
        textComponent.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder(lore).create()));
        player.spigot().sendMessage((BaseComponent)textComponent);
    }
    
    public static void runCommand(Player player, String text, String cmd, String lore) {
        TextComponent textComponent = new TextComponent();
        textComponent.setText(text);
        textComponent.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, cmd));
        textComponent.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder(lore).create()));
        player.spigot().sendMessage((BaseComponent)textComponent);
    }
    
    
    public static void completArgs(Player player, String text, String cmd, String lore) {
        TextComponent textComponent = new TextComponent();
        textComponent.setText(text);
        textComponent.setClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, cmd));
        textComponent.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder(lore).create()));
        player.spigot().sendMessage((BaseComponent)textComponent);
    }
    
    
    public static void openFile(Player player, String text, String cmd, String lore) {
        TextComponent textComponent = new TextComponent();
        textComponent.setText(text);
        textComponent.setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_FILE, cmd));
        textComponent.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder(lore).create()));
        player.spigot().sendMessage((BaseComponent)textComponent);
    }
    
}
