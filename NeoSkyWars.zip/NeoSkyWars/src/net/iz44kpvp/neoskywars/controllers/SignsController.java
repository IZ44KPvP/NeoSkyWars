package net.iz44kpvp.neoskywars.controllers;

import org.bukkit.Location;
import org.bukkit.block.Sign;

import net.iz44kpvp.neoskywars.managers.SkyWarsManager;
import net.iz44kpvp.neoskywars.skywars.SkyWars;

public class SignsController
{
    private Location loc;
    private Sign sign;
    private SkyWars.GameMode mode;
    private SkyWars.ChestType chestType;
    
    public SignsController(final Location loc, final SkyWars.GameMode mode, final SkyWars.ChestType type) {
        this.loc = loc;
        this.sign = (Sign)loc.getBlock().getState();
        this.mode = mode;
        this.chestType = type;
    }

    
    public Location getLocation() {
        return this.loc;
    }
    
    public Sign getSign() {
        return this.sign;
    }
    
    public SkyWars.GameMode getMode() {
        return this.mode;
    }
    
    public SkyWars.ChestType getType() {
        return this.chestType;
    }
    
    
    public void update() {
        final String skywar = "�1�l[Join]";
        final String i = "�l" + this.mode.toString();
        String mode = null;
        if (this.chestType == SkyWars.ChestType.NORMAL) {
            mode = "�9" + this.chestType.toString().substring(0, 1).toUpperCase() + this.chestType.toString().substring(1).toLowerCase() + " Mode";
        }else if(this.chestType == SkyWars.ChestType.MEGA){
        	mode = "�1Mega Mode";
        }
        else {
            mode = "�c" + this.chestType.toString().substring(0, 1).toUpperCase() + this.chestType.toString().substring(1).toLowerCase() + " Mode";
        }
        int a = 0;
        for (final SkyWars sky : SkyWarsManager.getInstance().getSkyWars()) {
            if (sky.getMode().equals(this.getMode()) && sky.getChestType().equals(this.getType()) && sky.getState() == SkyWars.GameState.WAITING) {
                a += sky.getPlayers().length;
            }
        }
        final String queue = "In Queue " + a;
        this.sign.setLine(0, skywar);
        this.sign.setLine(1, i);
        this.sign.setLine(2, queue);
        this.sign.setLine(3, mode);
        this.sign.update();
    }
}
